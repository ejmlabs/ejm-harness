#!/usr/bin/env python3
"""Supplement frozen helper evidence using SDK read-only counters and fixtures."""

import ctypes
import datetime
import errno
import fcntl
import hashlib
import json
import os
import pathlib
import resource
import shutil
import sqlite3
import stat
import subprocess
import time
import traceback
import uuid


ROOT = pathlib.Path('/Users/everettmorgan/Desktop/ejm-harness')
SMOKE = pathlib.Path('/private/tmp/ejm-native-staged-release-smoke-20261020/20261020T171623Z-e14b9e1d/native_owner_smoke.release')
SMOKE_SHA = '67f1841051c62222c3967a76390b7ca6eb111d0b6a797dedb091eaea885d33c5'
BENCH = pathlib.Path('/private/tmp/ejm-capacity-zombie-aware-release-20261020/ejm-harness-bench')
BENCH_SHA = '66618eed04f6887b2c4eba21ed85401130936a47ef7891bf4c58a36458ad2f22'
C_SOURCE = pathlib.Path('/private/tmp/ejm-native-helper-complement-20261020.c')
OUTPUT = pathlib.Path('/private/tmp/ejm-native-helper-complement-20261020')
FLOOR = 10 * 1024**3
FIELDS = ('start_abstime start_seconds start_microseconds parent_pid rss_bytes footprint_bytes '
          'footprint_lifetime_max_bytes mach_rss_bytes mach_rss_lifetime_max_bytes user_time_ns '
          'system_time_ns task_name_result task_info_result task_info_count '
          'task_name_deallocate_result sample_errno').split()


class Observation(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in FIELDS]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def disk(report, phase):
    free = shutil.disk_usage(OUTPUT).free
    report['disk'].append({'phase': phase, 'free_bytes': free, 'utc': now()})
    check(free >= FLOOR, f'free disk below 10 GiB floor at {phase}: {free}')


def observe(probe, pid, expected=None, parent=None):
    value = Observation()
    result = probe(pid, ctypes.byref(value))
    record = {key: getattr(value, key) for key in FIELDS}
    record.update(pid=pid, result=result)
    check(result == 0, f'PID {pid} observation failed: {record}')
    check(record['start_abstime'] > 0, f'PID {pid} lacks birth identity')
    if expected is not None:
        check(record['start_abstime'] == expected, f'PID {pid} changed birth identity')
    if parent is not None:
        check(record['parent_pid'] == parent, f'PID {pid} changed expected parent')
    check(record['footprint_lifetime_max_bytes'] >= record['footprint_bytes'], 'invalid physical-footprint maximum')
    if record['task_name_result'] == 0:
        check(record['task_name_deallocate_result'] == 0, 'task-name port deallocation failed')
    if record['task_name_result'] == 0 and record['task_info_result'] == 0:
        check(record['mach_rss_lifetime_max_bytes'] >= record['mach_rss_bytes'], 'invalid Mach RSS maximum')
    return record


def endpoint(path):
    value = json.loads(path.read_text())
    check(type(value.get('pid')) is int and 0 < value['pid'] < 2**31, 'invalid helper PID')
    # Never log the endpoint capability or port.
    return {'pid': value['pid'], 'generation': str(uuid.UUID(value['epoch'])),
            'domain': value['domain'], 'protocol': value['protocol'],
            'accounted': value.get('accounted', False)}


def witness(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    metadata = os.fstat(fd)
    check(stat.S_ISREG(metadata.st_mode) and metadata.st_uid == os.getuid() and metadata.st_nlink == 1,
          'invalid witness file')
    check(held(fd), 'helper witness is not held')
    return fd


def held(fd):
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as error:
        if error.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
            return True
        raise
    fcntl.flock(fd, fcntl.LOCK_UN)
    return False


def start(command, directory, env=None, nofile=None):
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    child_env = {key: value for key, value in os.environ.items() if not key.startswith('EJM_FIXTURE_')}
    child_env.update(env or {})
    def limit():
        _, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        resource.setrlimit(resource.RLIMIT_NOFILE, (nofile, hard))
    with (directory / 'stdout').open('xb') as out, (directory / 'stderr').open('xb') as err:
        process = subprocess.Popen(command, cwd=directory, env=child_env, stdin=subprocess.DEVNULL,
                                   stdout=out, stderr=err, start_new_session=True,
                                   preexec_fn=limit if nofile is not None else None)
    return {'process': process, 'directory': directory, 'command': command, 'nofile': nofile}


def command_record(item):
    return {'pid': item['process'].pid, 'command': item['command'], 'nofile_soft': item['nofile'],
            'stdout': str(item['directory'] / 'stdout'), 'stderr': str(item['directory'] / 'stderr')}


def terminate_client(item):
    process = item['process']
    requested = process.poll() is None
    if requested:
        process.terminate()
    try:
        process.wait(timeout=5)
        escalated = False
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
        escalated = True
    return {'pid': process.pid, 'returncode': process.returncode, 'sigterm_requested': requested,
            'sigkill_required': escalated, 'reaped': True}


def helper_cleanup(item, probe):
    deadline = time.monotonic() + 12
    identity, fd = item.get('identity'), item.get('witness')
    result = {'pid': identity['pid'] if identity else item.get('helper_pid')}
    pid = result['pid']
    while pid is not None and time.monotonic() < deadline:
        value = Observation()
        code = probe(pid, ctypes.byref(value))
        # ESRCH plus the exact stable witness becoming available proves exit.
        absent = code != 0 and value.sample_errno == errno.ESRCH
        replaced = code == 0 and value.start_abstime != item.get('helper_birth')
        released = fd is not None and not held(fd)
        if (absent or replaced) and released:
            result.update(identity_ended=True, witness_available=True, utc=now())
            break
        time.sleep(0.05)
    if not result.get('identity_ended'):
        result.update(identity_ended=False, witness_available=fd is not None and not held(fd))
    if fd is not None:
        os.close(fd)
        item['witness'] = None
    return result


def save(report, evidence):
    (evidence / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def startup_trial(index, evidence, probe, report):
    directory = evidence / f'startup-{index}'
    marker = directory / 'pre-dispatch.pid'
    item = start([str(SMOKE), 'witness-client', str(directory / 'state'), str(directory / 'unused')],
                 directory, {'EJM_FIXTURE_NATIVE_PRE_DISPATCH': str(marker)})
    result = {'index': index, 'started_utc': now(), 'client': command_record(item), 'samples': []}
    report['startup_trials'].append(result)
    try:
        deadline = time.monotonic() + 5
        while not marker.exists():
            check(item['process'].poll() is None, 'witness client exited before pre-dispatch barrier')
            check(time.monotonic() < deadline, 'pre-dispatch marker deadline')
            time.sleep(0.002)
        pid = int(marker.read_text())
        item['helper_pid'] = pid
        item['endpoint'] = directory / 'state/native/fixture/endpoint.json'
        item['witness'] = witness(item['endpoint'].with_name('owner.lock'))
        first = observe(probe, pid, parent=item['process'].pid)
        item['helper_birth'] = first['start_abstime']
        result['before_dispatch'] = first
        start_time = time.monotonic()
        result['resume_utc'] = now()
        marker.with_suffix('.resume').write_bytes(b'')
        next_at = start_time
        while time.monotonic() < start_time + 6:
            if next_at > time.monotonic():
                time.sleep(next_at - time.monotonic())
            check(item['process'].poll() is None, 'witness client exited in command-free window')
            if item['endpoint'].exists():
                identity = endpoint(item['endpoint'])
                check(identity['pid'] == pid, 'advertised helper PID changed')
                if 'identity' not in item:
                    item['identity'] = identity
                    result['advertisement_first_seen_seconds'] = time.monotonic() - start_time
                check(identity == item['identity'], 'advertised helper generation changed')
            sample = observe(probe, pid, expected=item['helper_birth'], parent=item['process'].pid)
            sample['offset_seconds'] = time.monotonic() - start_time
            result['samples'].append(sample)
            check(held(item['witness']), 'witness released in command-free window')
            next_at = time.monotonic() + (0.002 if sample['offset_seconds'] < 0.25 else 0.1)
        check('identity' in item, 'helper did not advertise within command-free window')
        result['identity'] = item['identity']
        result['actual_window_seconds'] = time.monotonic() - start_time
        result['rss_sampled_high_water_bytes'] = max(row['rss_bytes'] for row in result['samples'])
        mach = [row for row in result['samples'] if row['task_name_result'] == 0 and row['task_info_result'] == 0]
        result['mach_success_samples'] = len(mach)
        result['rss_kernel_lifetime_peak_bytes'] = max((row['mach_rss_lifetime_max_bytes'] for row in mach), default=None)
        result['physical_footprint_kernel_lifetime_peak_bytes'] = max(row['footprint_lifetime_max_bytes'] for row in result['samples'])
        result['status'] = 'passed'
    except Exception as error:
        result.update(status='failed', error=str(error))
        raise
    finally:
        result['client_cleanup'] = terminate_client(item)
        if item.get('helper_pid') is not None:
            result['helper_cleanup'] = helper_cleanup(item, probe)
            check(result['helper_cleanup']['identity_ended'], 'startup helper did not drain')
        result['finished_utc'] = now()
        save(report, evidence)


def registry_snapshot(root):
    with sqlite3.connect(f'file:{root / "capacity.sqlite3"}?mode=ro', uri=True, timeout=0.1) as connection:
        helpers = [{'generation': generation, 'domain': domain, 'committed': bool(committed)}
                   for generation, domain, committed in connection.execute(
                       'SELECT generation,domain_key,committed FROM native_helpers ORDER BY domain_key')]
        allocations = [{'generation': generation, 'ancestor': domain, 'budget': json.loads(budget)}
                       for generation, domain, budget in connection.execute(
                           'SELECT generation,domain,budget FROM native_helper_allocations ORDER BY domain,generation')]
    return {'helpers': helpers, 'occupied': len(helpers), 'committed': sum(row['committed'] for row in helpers),
            'allocations': allocations}


def benchmark_command(root, directory, agents, park_ms):
    return [str(BENCH), '--agents', str(agents), '--rounds', '8' if agents == 100 else '1',
            '--park-ms', str(park_ms), '--model-requests', '1', '--jobs', '1', '--capacity', 'fixed',
            '--capacity-root', str(root), '--state-dir', str(directory / 'state')]


def pool_trial(evidence, probe, report):
    root = evidence / 'shared-pool'
    pool = report['shared_pool'] = {'started_utc': now(), 'clients': [], 'samples': [],
                                  'native_commands_per_successful_participant': 800}
    clients, helpers = [], []
    ninth = None
    try:
        # Return unused initial native CPU before each later registration.
        # Align the eight real work gates without pausing a registry writer.
        release_time = time.monotonic() + 12
        pool['setup'] = {'registration_stagger_seconds': 1, 'first_eight_gate_offset_seconds': 12,
                         'ninth_gate_offset_seconds': 15,
                         'reason': 'The first attempt exhausted default 2000-millis initial CPU grants before coordinators could return unused parked capacity.'}
        for index in range(8):
            directory = evidence / f'pool-client-{index + 1}'
            park_ms = max(1000, int((release_time - time.monotonic()) * 1000))
            item = start(benchmark_command(root, directory, 100, park_ms), directory, nofile=4096 + 128 * index)
            clients.append(item)
            pool['clients'].append(command_record(item))
            time.sleep(1)
        directory = evidence / 'pool-client-9'
        park_ms = max(1000, int((release_time + 3 - time.monotonic()) * 1000))
        ninth = start(benchmark_command(root, directory, 1, park_ms), directory, nofile=5120)
        pool['ninth'] = command_record(ninth)
        deadline = time.monotonic() + 25
        seen = {}
        while len(seen) < 8:
            for item in clients:
                check(item['process'].poll() is None, f'pool client {item["process"].pid} exited before saturation')
            for path in root.glob('native/*/endpoint.json'):
                identity = endpoint(path)
                if identity['generation'] not in seen:
                    sample = observe(probe, identity['pid'])
                    check(sample['parent_pid'] in {item['process'].pid for item in clients}, 'helper parent outside created fixture clients')
                    item = {'identity': identity, 'endpoint': path, 'helper_birth': sample['start_abstime'],
                            'witness': witness(path.with_name('owner.lock')), 'parent_pid': sample['parent_pid']}
                    seen[identity['generation']] = item
                    helpers.append(item)
            check(time.monotonic() < deadline, 'eight actual helpers did not appear before deadline')
            time.sleep(0.005)
        pool['registry_before_ninth'] = registry_snapshot(root)
        check(pool['registry_before_ninth']['occupied'] == 8 and pool['registry_before_ninth']['committed'] == 8,
              'registry did not contain eight committed generations')
        check(all(item['identity']['accounted'] for item in helpers), 'unaccounted helper in pool')
        check({item['identity']['generation'] for item in helpers} ==
              {item['generation'] for item in pool['registry_before_ninth']['helpers']},
              'registry generations differ from running helpers')
        allocation_totals = {}
        allocation_generations = {}
        expected_generations = {item['identity']['generation'] for item in helpers}
        for row in pool['registry_before_ninth']['allocations']:
            check(row['budget']['memory'] == 32 * 1024**2 and row['budget']['processes'] == 1,
                  'helper coarse commitment differs from the frozen macOS allowance')
            total = allocation_totals.setdefault(row['ancestor'], {'generations': 0, 'memory_bytes': 0, 'processes': 0})
            total['generations'] += 1
            total['memory_bytes'] += row['budget']['memory']
            total['processes'] += row['budget']['processes']
            allocation_generations.setdefault(row['ancestor'], set()).add(row['generation'])
        check(allocation_totals and all(total['generations'] == 8 for total in allocation_totals.values()), 'ancestor lacks exactly eight helper commitments')
        check(all(generations == expected_generations for generations in allocation_generations.values()),
              'ancestor helper commitments differ from the exact eight live generations')
        pool['coarse_commitments_per_ancestor'] = allocation_totals
        pool['saturated_utc'] = now()
        started = time.monotonic()
        next_at = started
        while next_at < started + 5:
            if next_at > time.monotonic():
                time.sleep(next_at - time.monotonic())
            rows = []
            for item in helpers:
                check(endpoint(item['endpoint']) == item['identity'], 'pool endpoint changed during saturation')
                check(held(item['witness']), 'pool witness released during saturation')
                rows.append(observe(probe, item['identity']['pid'], expected=item['helper_birth'], parent=item['parent_pid']))
            parent_rows = []
            for item in clients:
                check(item['process'].poll() is None, 'participant exited before saturated sample window ended')
                parent_rows.append(observe(probe, item['process'].pid, parent=os.getpid()))
            snapshot = registry_snapshot(root)
            check(snapshot['occupied'] == 8 and snapshot['committed'] == 8, 'registry lost eight-slot saturation')
            pool['samples'].append({'offset_seconds': time.monotonic() - started, 'helpers': rows, 'clients': parent_rows,
                                    'registry_occupied': snapshot['occupied'], 'registry_committed': snapshot['committed'],
                                    'helper_aggregate_rss_bytes': sum(row['rss_bytes'] for row in rows),
                                    'client_aggregate_rss_bytes': sum(row['rss_bytes'] for row in parent_rows)})
            next_at += 0.25
        pool['actual_window_seconds'] = time.monotonic() - started
        ninth['process'].wait(timeout=12)
        ninth_out = (ninth['directory'] / 'stdout').read_text()
        ninth_err = (ninth['directory'] / 'stderr').read_text()
        pool['ninth'].update(returncode=ninth['process'].returncode, stdout=ninth_out, stderr=ninth_err)
        check('shared native helper pool is full' in ninth_out + ninth_err, 'ninth claimant did not report actual helper pool rejection')
        pool['registry_after_ninth'] = registry_snapshot(root)
        check(pool['registry_after_ninth']['occupied'] == 8 and pool['registry_after_ninth']['committed'] == 8,
              'ninth claimant changed registry occupancy')
        check(len(list(root.glob('native/*/endpoint.json'))) == 8, 'ninth claimant advertised an extra helper')
        pool['sampled_helper_aggregate_high_water_rss_bytes'] = max(row['helper_aggregate_rss_bytes'] for row in pool['samples'])
        pool['sampled_client_aggregate_high_water_rss_bytes'] = max(row['client_aggregate_rss_bytes'] for row in pool['samples'])
        pool['sampled_combined_aggregate_high_water_rss_bytes'] = max(row['helper_aggregate_rss_bytes'] + row['client_aggregate_rss_bytes'] for row in pool['samples'])
        pool['per_helper_kernel_lifetime_peak_rss_bytes'] = {
            str(item['identity']['pid']): max((row['mach_rss_lifetime_max_bytes'] for sample in pool['samples'] for row in sample['helpers']
                                              if row['pid'] == item['identity']['pid'] and row['task_name_result'] == 0 and row['task_info_result'] == 0), default=None)
            for item in helpers}
        print('SATURATED_POOL_WINDOW_FINISHED', flush=True)
        deadline = time.monotonic() + 180
        next_disk = time.monotonic()
        while any(item['process'].poll() is None for item in clients):
            check(time.monotonic() < deadline, 'pool benchmarks exceeded completion deadline')
            if time.monotonic() >= next_disk:
                disk(report, 'waiting_for_pool_completion')
                next_disk = time.monotonic() + 10
            time.sleep(0.25)
        pool['completed_participants'] = []
        for item in clients:
            check(item['process'].returncode == 0, 'pool benchmark participant failed')
            data = json.loads((item['directory'] / 'stdout').read_text())
            check(data['status'] == 'completed' and data['commands_completed'] == 800, 'pool benchmark did not finish all fixture commands')
            pool['completed_participants'].append(data)
        pool['status'] = 'passed'
    except Exception as error:
        pool.update(status='failed', error=str(error))
        raise
    finally:
        pool['client_cleanup'] = [terminate_client(item) for item in clients]
        if ninth is not None:
            pool['ninth_cleanup'] = terminate_client(ninth)
        pool['helper_cleanup'] = [helper_cleanup(item, probe) for item in helpers]
        pool['discovered_helper_cleanup_complete'] = all(item['identity_ended'] for item in pool['helper_cleanup'])
        if pool.get('status') == 'passed':
            check(len(helpers) == 8 and pool['discovered_helper_cleanup_complete'], 'pool helper cleanup did not prove all eight exits')
        pool['finished_utc'] = now()
        save(report, evidence)


def main():
    OUTPUT.mkdir(exist_ok=True)
    evidence = OUTPUT / (datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8])
    evidence.mkdir(mode=0o700)
    report = {'schema': 1, 'started_utc': now(), 'status': 'waiting', 'disk_floor_bytes': FLOOR, 'disk': [],
              'runner': str(pathlib.Path(__file__)), 'runner_sha256': sha(pathlib.Path(__file__)),
              'counter_adapter_source': str(C_SOURCE), 'counter_adapter_sha256': sha(C_SOURCE),
              'binaries': {'smoke': {'path': str(SMOKE), 'sha256': SMOKE_SHA}, 'bench': {'path': str(BENCH), 'sha256': BENCH_SHA}},
              'startup_trials': [],
              'semantics': {
                  'rss_kernel_peak': 'SDK MACH_TASK_BASIC_INFO.resident_size_max, bytes, kernel lifetime maximum through the read, obtained with task_name_for_pid and deallocated task-name port; no debugger or full task port.',
                  'startup_window': 'Existing helper fixture pre-dispatch barrier through six seconds with no native commands. Kernel lifetime counter covers birth including time before barrier, startup and the later idle window, not an exact Ready-boundary trace.',
                  'rss_samples': 'proc_pid_rusage V4 ri_resident_size, bytes. Each aggregate is a sequential scan sum, not a simultaneous snapshot; sampled high-water can miss peaks and can double-count shared pages.',
                  'physical_footprint_peak': 'proc_pid_rusage V4 ri_lifetime_max_phys_footprint, bytes. Different memory ledger from RSS; do not substitute for RSS peak.',
                  'shared_pool': 'Eight real benchmark helper generations with real distinct inherited RLIMIT_NOFILE soft limits and one protected isolated core registry; ninth distinct-domain claimant attempts actual admission.',
                  'identity': 'PID start_abstime read before and after each task query, pinned across samples; parent relationship and exact endpoint generation checked; held stable owner.lock checked.',
              },
              'limits': ['The smoke executable predates final sampler diagnostics and exit-progress handling; the benchmark is the final frozen sampler checkpoint.',
                         'A fixture pre-dispatch marker/resume barrier adds startup work. No production probe or runtime code is changed.',
                         'The six-second command-free lifetime RSS peak is a conservative startup bound for this fixture binary, not an exact Ready-boundary peak for every embedding executable.',
                         'Saturated registry occupancy and active helper overhead do not prove MAX_SCOPES, MAX_READY_CLIENTS, MAX_COMPLETED, or handshake-table saturation.',
                         'Shared pool workloads use lower inherited descriptor limits to produce real distinct domains. They are not a sweep or an ordinary single-domain idle pool.',
                         'No Linux or Windows startup calibration, automatic-default activation, or cross-image 32 MiB calibration is claimed.',
                         'Unrelated host activity is uncontrolled; the advisory lock excludes compliant test/build workloads only.']}
    print('EVIDENCE_DIRECTORY=' + str(evidence), flush=True)
    print('WAITING_FOR_GLOBAL_LOCK', flush=True)
    with open('/tmp/ejm-capacity-cargo.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        print('GLOBAL_LOCK_ACQUIRED', flush=True)
        try:
            disk(report, 'before_compile')
            check(sha(SMOKE) == SMOKE_SHA and sha(BENCH) == BENCH_SHA, 'frozen executable changed')
            report['host'] = {name: subprocess.check_output(command, text=True).strip() for name, command in [
                ('sw_vers', ['sw_vers']), ('uname', ['uname', '-a']), ('hardware', ['sysctl', '-n', 'hw.model', 'hw.ncpu', 'hw.memsize'])]}
            dylib = evidence / 'observe.dylib'
            command = ['cc', '-dynamiclib', '-O2', '-Wall', '-Wextra', '-Werror', str(C_SOURCE), '-o', str(dylib)]
            compiled = subprocess.run(command, capture_output=True, text=True, timeout=30)
            report['compile'] = {'command': command, 'returncode': compiled.returncode, 'stdout': compiled.stdout, 'stderr': compiled.stderr}
            check(compiled.returncode == 0, 'SDK counter adapter failed to compile')
            report['counter_adapter_binary_sha256'] = sha(dylib)
            library = ctypes.CDLL(str(dylib))
            probe = library.ejm_observe
            probe.argtypes = [ctypes.c_int, ctypes.POINTER(Observation)]
            probe.restype = ctypes.c_int
            report['status'] = 'started'
            report['reuses_startup_evidence'] = '/private/tmp/ejm-native-helper-complement-20261020/20261020T193825Z-8e2a10de/report.json'
            disk(report, 'before_shared_pool')
            print('SHARED_POOL_TRIAL', flush=True)
            pool_trial(evidence, probe, report)
            check(sha(SMOKE) == SMOKE_SHA and sha(BENCH) == BENCH_SHA, 'frozen executable changed after measurement')
            disk(report, 'after_measurements')
            report['status'] = 'passed'
        except Exception as error:
            report.update(status='failed', error=str(error), traceback=traceback.format_exc())
        finally:
            report['finished_utc'] = now()
            save(report, evidence)
            print(json.dumps({'status': report['status'], 'error': report.get('error'), 'report': str(evidence / 'report.json')}), flush=True)
    print('GLOBAL_LOCK_RELEASED', flush=True)
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
