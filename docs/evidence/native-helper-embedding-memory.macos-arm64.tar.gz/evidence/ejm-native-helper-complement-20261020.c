#include <errno.h>
#include <libproc.h>
#include <mach/mach.h>
#include <mach/mach_traps.h>
#include <stdint.h>
#include <string.h>
#include <sys/proc_info.h>
#include <sys/resource.h>

/* A scratch adapter over SDK-declared read-only APIs, not product code. */
struct ejm_observation {
    uint64_t start_abstime;
    uint64_t start_seconds;
    uint64_t start_microseconds;
    uint64_t parent_pid;
    uint64_t rss_bytes;
    uint64_t footprint_bytes;
    uint64_t footprint_lifetime_max_bytes;
    uint64_t mach_rss_bytes;
    uint64_t mach_rss_lifetime_max_bytes;
    uint64_t user_time_ns;
    uint64_t system_time_ns;
    uint64_t task_name_result;
    uint64_t task_info_result;
    uint64_t task_info_count;
    uint64_t task_name_deallocate_result;
    uint64_t sample_errno;
};

int ejm_observe(int pid, struct ejm_observation *out) {
    struct rusage_info_v4 before;
    struct rusage_info_v4 after;
    struct proc_bsdinfo bsd;
    mach_task_basic_info_data_t basic;
    mach_msg_type_number_t count = MACH_TASK_BASIC_INFO_COUNT;
    mach_port_name_t name = MACH_PORT_NULL;
    memset(out, 0, sizeof(*out));
    memset(&before, 0, sizeof(before));
    memset(&after, 0, sizeof(after));
    memset(&bsd, 0, sizeof(bsd));
    memset(&basic, 0, sizeof(basic));
    if (proc_pid_rusage(pid, RUSAGE_INFO_V4, (rusage_info_t *)&before) != 0) {
        out->sample_errno = (uint64_t)errno;
        return 1;
    }
    if (before.ri_proc_start_abstime == 0 || before.ri_proc_exit_abstime != 0) {
        return 2;
    }
    if (proc_pidinfo(pid, PROC_PIDTBSDINFO, 1, &bsd, sizeof(bsd)) != (int)sizeof(bsd)) {
        out->sample_errno = (uint64_t)errno;
        return 3;
    }
    out->task_name_result = (uint64_t)task_name_for_pid(mach_task_self(), pid, &name);
    out->task_info_result = (uint64_t)KERN_INVALID_NAME;
    if (out->task_name_result == KERN_SUCCESS) {
        out->task_info_result = (uint64_t)task_info(
            name, MACH_TASK_BASIC_INFO, (task_info_t)&basic, &count);
        out->task_info_count = (uint64_t)count;
        out->task_name_deallocate_result = (uint64_t)mach_port_deallocate(mach_task_self(), name);
    }
    if (proc_pid_rusage(pid, RUSAGE_INFO_V4, (rusage_info_t *)&after) != 0) {
        out->sample_errno = (uint64_t)errno;
        return 4;
    }
    if (before.ri_proc_start_abstime != after.ri_proc_start_abstime ||
        after.ri_proc_exit_abstime != 0) {
        return 5;
    }
    out->start_abstime = after.ri_proc_start_abstime;
    out->start_seconds = bsd.pbi_start_tvsec;
    out->start_microseconds = bsd.pbi_start_tvusec;
    out->parent_pid = bsd.pbi_ppid;
    out->rss_bytes = after.ri_resident_size;
    out->footprint_bytes = after.ri_phys_footprint;
    out->footprint_lifetime_max_bytes = after.ri_lifetime_max_phys_footprint;
    out->user_time_ns = after.ri_user_time;
    out->system_time_ns = after.ri_system_time;
    if (out->task_info_result == KERN_SUCCESS) {
        out->mach_rss_bytes = basic.resident_size;
        out->mach_rss_lifetime_max_bytes = basic.resident_size_max;
    }
    return 0;
}
