#!/usr/bin/env python3
"""Run existing executor contracts after reducing control-link buffer slack."""

import datetime as dt
import fcntl
import hashlib
import importlib.util
import signal
from pathlib import Path
import uuid

UTILITY = Path('/private/tmp/ejm-cli-capacity-fixture-checks-20261020/run.v4.py')
UTILITY_SHA = '732c998103c2c6e8f42245f38e407a438317526c2fb75de75d98f8a3dc21ab8a'
ROOT = Path('/Users/everettmorgan/Desktop/ejm-harness')
BASE = Path('/private/tmp/ejm-capacity-buffer-gate-20261020')


def main():
    if hashlib.sha256(UTILITY.read_bytes()).hexdigest() != UTILITY_SHA:
        raise RuntimeError('Bounded command utility changed')
    spec = importlib.util.spec_from_file_location('buffer_gate_commands', UTILITY)
    utility = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(utility)
    utility.CLI = ROOT
    directory = BASE / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8])
    directory.mkdir(mode=0o700, parents=True)
    run = utility.Run(directory)
    run.report['limits'] = [
        'Existing macOS executor contracts and lint checks only; no cross-platform or scale acceptance.',
        'Two Cargo jobs, offline dependencies, no incremental output, 10 GiB free-space floor.',
    ]
    run.report['runner'] = utility.receipt(Path(__file__))
    run.report['utility'] = utility.receipt(UTILITY)
    signal.signal(signal.SIGINT, run.interrupt)
    signal.signal(signal.SIGTERM, run.interrupt)
    print('GATE_DIRECTORY=' + str(directory), flush=True)
    with utility.LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            before = utility.source_state(ROOT)
            utility.write(directory / 'source-before.json', before)
            run.command('executor_format', ['cargo', 'fmt', '-p', 'ejm-harness-exec', '--', '--check'], timeout=30)
            common = ['--locked', '--offline', '--jobs', '2', '-p', 'ejm-harness-exec']
            run.command('executor_contracts', ['cargo', 'test', *common, '--lib', '--tests', '--', '--test-threads=2'], timeout=600)
            run.command('executor_clippy', ['cargo', 'clippy', *common, '--all-targets', '--', '-D', 'warnings'], timeout=180)
            after = utility.source_state(ROOT)
            utility.write(directory / 'source-after.json', after)
            run.report['source_unchanged'] = before == after
            utility.check(before == after, 'Source changed during executor checks')
            utility.check(not run.report.get('remaining_work_requires_audit'), 'Command cleanup needs audit')
            run.report['status'] = 'passed'
        except BaseException as error:
            run.report.update(status='failed', error=f'{type(error).__name__}: {error}')
            raise
        finally:
            run.report['finished_utc'] = utility.now()
            run.save()
    print('REPORT=' + str(directory / 'report.json'), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
