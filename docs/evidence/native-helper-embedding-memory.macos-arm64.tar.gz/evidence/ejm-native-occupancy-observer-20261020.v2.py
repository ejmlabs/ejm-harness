#!/usr/bin/env python3
"""Check frozen occupancy inputs by default; --run starts bounded native trials."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import selectors
import signal
import stat
import subprocess
import sys
import time
import types
import uuid


ADAPTER = Path('/private/tmp/ejm-capacity-real-helper-calibration-20261020.v2.py')
ADAPTER_SHA = '8e69892479e1967f2c5d9662769463c167964a16142ab60f080ad12e9bf74a5a'
BASE = Path('/private/tmp/ejm-native-occupancy-observer-20261020')
TEST = 'native::tests::occupancy::real_helper_control_state_saturation'
TRIAL_SECONDS, CLEANUP_SECONDS, MAX_SAMPLES = 60, 12, 1000
LOG_BYTES, LINE_BYTES, SAMPLE_SECONDS = 1024**2, 16 * 1024, 0.05
STAGES = ('descriptor_preflight', 'started', 'completed_full',
          'completed_eviction_proven', 'readiness_full_and_reused', 'scopes_full',
          'handshake_connections_pending', 'handshake_overflow_disconnected',
          'handshake_limit_proven', 'scope_slot_reused', 'scopes_drained',
          'fresh_control_usable', 'links_dropped', 'helper_exit_proven')
_ADAPTERS = None


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def adapters():
    global _ADAPTERS
    if _ADAPTERS is None:
        value = ADAPTER.lstat()
        require(stat.S_ISREG(value.st_mode) and value.st_uid == os.getuid() and value.st_nlink == 1,
                'observer adapters must be an owned regular single-link file')
        data = ADAPTER.read_bytes()
        require(len(data) <= 128 * 1024 and hashlib.sha256(data).hexdigest() == ADAPTER_SHA,
                'observer adapter hash changed')
        module = types.ModuleType('_ejm_occupancy_calibration_adapters')
        module.__file__ = str(ADAPTER)
        exec(compile(data, str(ADAPTER), 'exec'), module.__dict__)
        _ADAPTERS = module
    return _ADAPTERS


def check_inputs(path, directory):
    a = adapters()
    original = a._pin({'path': str(path.absolute()), 'sha256': a._sha(path)})
    value = a._json(path)
    require(value.get('schema') == 1 and set(value['binaries']) ==
            {'smoke', 'cli', 'worker', 'occupancy_libtest'}, 'four pinned build inputs are required')
    # The pinned calibration validator accepts exactly its original three images.
    projection = directory / 'calibration-inputs-projection.json'
    a._write(projection, {'schema': 1, 'binaries': {
        name: value['binaries'][name] for name in ('smoke', 'cli', 'worker')}})
    checked, states = a._inputs(projection)
    requested = value['binaries']['occupancy_libtest']
    binary, receipt = a._pin(requested, executable=True), a._pin(requested['build_receipt'])
    build = a._json(receipt['path'])
    require(build.get('schema') == 1 and a._pin(build['copied_binary'], executable=True) == binary,
            'occupancy libtest copied image receipt mismatch')
    phase = build['build']
    command = phase['command']
    require(isinstance(command, list) and command[:2] == ['cargo', 'test'] and
            all(flag in command for flag in ('--release', '--no-run', '--lib', 'ejm-harness-exec')) and
            phase['profile'] == 'release' and phase['target'] == 'aarch64-apple-darwin' and
            phase['returncode'] == 0 and phase['started_utc'] and phase['finished_utc'],
            'occupancy libtest needs a successful native release cargo test --lib --no-run receipt')
    output = phase['output']
    require(Path(output['path']).is_absolute() and output['sha256'] == binary['sha256'] and
            output['bytes'] == binary['bytes'], 'occupancy build output mismatch')
    for stream in ('stdout', 'stderr'):
        a._pin(phase[stream])
    require(len(build['sources']) == 1 and build['sources'][0]['root'] == str(a.HARNESS),
            'occupancy libtest needs exactly the harness source root')
    source = build['sources'][0]
    before_pin, after_pin = a._pin(source['before']), a._pin(source['after'])
    before, after = a._json(before_pin['path']), a._json(after_pin['path'])
    require(before['root'] == before['top_level'] == str(a.HARNESS) and before['files'] and
            a._source_key(before) == a._source_key(after) == a._source_key(states[str(a.HARNESS)]),
            'occupancy source changed during build or differs from frozen helper sources')
    checked['original_input'] = original
    checked['binaries']['occupancy_libtest'] = binary | {
        'build_receipt': receipt, 'build': phase, 'sources': [source]}
    return checked, states


def witness_inode(witness, allow_unlinked):
    descriptor = os.fstat(witness['fd'])
    require(not os.get_inheritable(witness['fd']), 'witness descriptor became inheritable')
    require(stat.S_ISREG(descriptor.st_mode) and descriptor.st_uid == os.getuid() and
            (descriptor.st_dev, descriptor.st_ino) == (witness['device'], witness['inode']),
            'retained witness type, owner or identity changed')
    try:
        path = os.lstat(witness['path'])
    except FileNotFoundError:
        require(allow_unlinked and descriptor.st_nlink == 0,
                'unlinked witness needs successful fixture exit and terminal stage')
        return 'unlinked_original'
    require(stat.S_ISREG(path.st_mode) and path.st_uid == os.getuid() and
            path.st_nlink == descriptor.st_nlink == 1 and
            (path.st_dev, path.st_ino) == (witness['device'], witness['inode']),
            'witness path was replaced or changed type, owner or link count')
    return 'linked_original'


def cleanup_audit(a, probe, helper, witness, client, terminal_seen):
    result = {'identity_only': None, 'witness_stable': False, 'witness_available': False,
              'unlink_aware_test_cleanup_proved': False, 'audit_required': True, 'errors': []}
    try:
        require(helper is not None and witness is not None and helper.get('held_verified_at_attach'),
                'helper identity and held original witness were not attached')
        identity = a.helper_end_state(probe, {**helper, 'witness': None})
        result['identity_only'] = identity
        allowed = client.get('reaped') and client.get('returncode') == 0 and terminal_seen
        before = witness_inode(witness, allow_unlinked=allowed)
        available = not a._util().held(witness['fd'])
        after = witness_inode(witness, allow_unlinked=allowed)
        require(before == after, 'witness linkage changed during final audit')
        result.update(witness_stable=True, witness_state=after, witness_available=available)
        result['unlink_aware_test_cleanup_proved'] = bool(
            identity['identity_ended'] and not identity['errors'] and available)
        result['audit_required'] = not result['unlink_aware_test_cleanup_proved']
    except Exception as error:
        result['errors'].append(f'{type(error).__name__}: {error}'[:1024])
    return result


def stage_line(line, result, client_pid):
    require(len(line) <= LINE_BYTES, 'stdout line exceeds 16 KiB')
    if b'"native_owner_occupancy"' not in line:
        return None
    offset = line.find(b'{')
    prefix = line[:offset].decode('utf-8')
    require(prefix.strip() in ('', f'test {TEST} ...'), 'unexpected libtest stage prefix')
    row = json.loads(line[offset:])
    name = row['native_owner_occupancy']
    require(len(result['stages']) < len(STAGES) and name == STAGES[len(result['stages'])],
            'missing, duplicate or reordered occupancy stage')
    require(type(row['client_pid']) is int and row['client_pid'] == client_pid, 'stage client PID mismatch')
    if name == 'descriptor_preflight':
        require(row['required_descriptors'] == row['open_descriptor_entries'] + 1312 + 128 and
                (row['descriptor_soft_limit'] is None or
                 row['descriptor_soft_limit'] >= row['required_descriptors']), 'descriptor preflight mismatch')
    else:
        identity = (row['helper_pid'], str(uuid.UUID(row['epoch'])), row['helper_birth_native'])
        require(type(identity[0]) is int and identity[0] > 0 and type(identity[2]) is int and identity[2] > 0,
                'stage lacks helper birth identity')
        if 'stage_identity' not in result:
            result['stage_identity'] = identity
        require(tuple(result['stage_identity']) == identity, 'helper identity changed between stages')
        for field, maximum in (('ready_clients', 256), ('prepared_scopes', 1024),
                               ('completed_capacity_verified', 256), ('stalled_connections', 32),
                               ('proven_handshakes', 32)):
            require(type(row[field]) is int and 0 <= row[field] <= maximum, 'invalid stage count: ' + field)
        if name in ('handshake_overflow_disconnected', 'handshake_limit_proven'):
            require(row['ready_clients'] == row['completed_capacity_verified'] == 256 and
                    row['prepared_scopes'] == 1024, 'full control state was not retained')
            require(row['stalled_connections'] == (32 if name == 'handshake_overflow_disconnected' else 0)
                    and row['proven_handshakes'] == (32 if name == 'handshake_limit_proven' else 0),
                    'handshake capacity proof mismatch')
    row['decoded_monotonic'] = time.monotonic()
    result['stages'].append(row)
    return name


def mach_ok(row):
    return all(row.get(name) == 0 for name in
               ('task_name_result', 'task_info_result', 'task_name_deallocate_result')) and (
                   row.get('mach_rss_lifetime_max_bytes', -1) >= row.get('mach_rss_bytes', 0))


def trial(a, probe, inputs, evidence, image, index, report, interrupted):
    directory = evidence / f'{image}-{index}'
    directory.mkdir(mode=0o700)
    temporary = directory / 'tmp'
    temporary.mkdir(mode=0o700)
    command = [inputs['binaries']['occupancy_libtest']['path'], TEST,
               '--ignored', '--exact', '--nocapture', '--test-threads=1']
    result = {'image': image, 'index': index, 'command': command, 'started_utc': a._now(),
              'stages': [], 'samples': [], 'sample_errors': [], 'audit_required': True,
              'stdout': str(directory / 'stdout'), 'stderr': str(directory / 'stderr'),
              'temporary_state': str(temporary), 'measurement_status': 'running'}
    report['trials'].append(result)
    a._write(evidence / 'report.json', report)
    process = helper = witness = None
    client = {'reaped': False, 'audit_required': True}
    started = time.monotonic()
    next_sample, next_disk = started, started
    attempts = 0

    def discover():
        nonlocal helper, witness, attempts
        if helper is not None or 'stage_identity' not in result:
            return
        endpoints = list(temporary.glob('*/capacity/native/occupancy/endpoint.json'))
        require(len(endpoints) <= 1, 'multiple helper advertisements in private trial TMPDIR')
        if not endpoints:
            return
        require(attempts < MAX_SAMPLES, 'observer sample count bound exceeded')
        attempts += 1
        witness = a.open_witness(endpoints[0].with_name('owner.lock'))
        before = time.monotonic()
        helper = a.attach_helper(probe, endpoints[0], process.pid, witness=witness,
                                 expected_domain='occupancy', expected_accounted=False)
        after = time.monotonic()
        pid, epoch, native_birth = result['stage_identity']
        observed = helper['first_observation']
        require(helper['identity']['pid'] == pid and helper['identity']['generation'] == epoch and
                observed['start_seconds'] * 1_000_000 + observed['start_microseconds'] == native_birth,
                'attached helper does not match stage PID, epoch and native birth')
        helper['held_verified_at_attach'] = True
        result.update(identity=helper['identity'], birth=helper['birth'],
                      witness={key: value for key, value in witness.items() if key != 'fd'})
        result['samples'].append(observed | {'before_monotonic': before, 'after_monotonic': after,
                                             'phase': 'attachment'})

    def sample(phase):
        nonlocal attempts, next_sample
        if helper is None:
            return
        require(attempts < MAX_SAMPLES, 'observer sample count bound exceeded')
        attempts += 1
        before = time.monotonic()
        try:
            row = a.sample_helper(probe, helper)
            result['samples'].append(row | {'before_monotonic': before,
                                             'after_monotonic': time.monotonic(), 'phase': phase})
        except Exception as error:
            if len(result['sample_errors']) < 8:
                result['sample_errors'].append({'before_monotonic': before,
                    'after_monotonic': time.monotonic(), 'phase': phase,
                    'error': f'{type(error).__name__}: {error}'[:1024]})
        next_sample = time.monotonic() + SAMPLE_SECONDS

    try:
        for name in (image, 'occupancy_libtest'):
            a._pin(inputs['binaries'][name], executable=True)
        a._disk(report, f'before_{image}_{index}')
        environment = {key: value for key, value in os.environ.items()
                       if not key.startswith(('EJM_', 'OPENAI_', 'ANTHROPIC_', 'CLAUDE_')) and key != 'CLAUDECODE'}
        environment.update(TMPDIR=str(temporary), EJM_NATIVE_OCCUPANCY_HELPER=inputs['binaries'][image]['path'])
        with selectors.DefaultSelector() as selector, (directory / 'stdout').open('xb') as out, (directory / 'stderr').open('xb') as err:
            process = subprocess.Popen(command, cwd=directory, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            result['client_pid'] = process.pid
            for stream, name, log in ((process.stdout, 'stdout', out), (process.stderr, 'stderr', err)):
                os.set_blocking(stream.fileno(), False)
                selector.register(stream, selectors.EVENT_READ, (name, log))
            counts, pending, exit_state = {'stdout': 0, 'stderr': 0}, b'', None
            while True:
                require(interrupted() is None, 'occupancy runner interrupted')
                current = time.monotonic()
                require(current - started < TRIAL_SECONDS, 'occupancy trial deadline exceeded')
                if current >= next_disk:
                    a._disk(report, f'{image}_{index}_observation')
                    next_disk = current + 1
                for key, _ in selector.select(timeout=0.01):
                    name, log = key.data
                    chunk = os.read(key.fileobj.fileno(), 16 * 1024)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        key.fileobj.close()
                        if name == 'stdout' and pending:
                            stage_line(pending, result, process.pid)
                            pending = b''
                        continue
                    room = LOG_BYTES - counts[name]
                    log.write(chunk[:max(0, room)])
                    counts[name] += len(chunk)
                    require(counts[name] <= LOG_BYTES, name + ' log exceeds 1 MiB')
                    if name == 'stdout':
                        pending += chunk
                        while b'\n' in pending:
                            line, pending = pending.split(b'\n', 1)
                            stage = stage_line(line, result, process.pid)
                            if stage:
                                discover()
                                sample('after_' + stage)
                        require(len(pending) <= LINE_BYTES, 'unterminated stdout line exceeds 16 KiB')
                discover()
                if current >= next_sample and not any(row['native_owner_occupancy'] == 'links_dropped' for row in result['stages']):
                    sample('periodic')
                # WNOWAIT observes exit without freeing the PID before any later signals.
                exit_state = os.waitid(os.P_PID, process.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                if exit_state is not None and not selector.get_map():
                    break
            client = {'reaped': True, 'returncode': process.wait(timeout=3), 'signals': [], 'audit_required': False}
            result['log_bytes'] = counts
        require(client['returncode'] == 0, 'occupancy libtest failed')
        require(len(result['stages']) == len(STAGES), 'occupancy terminal stage missing')
        boundary = next(row['decoded_monotonic'] for row in result['stages']
                        if row['native_owner_occupancy'] == 'handshake_limit_proven')
        qualifying = [row for row in result['samples'] if row['before_monotonic'] >= boundary and mach_ok(row)]
        require(qualifying, 'no successful Mach lifetime RSS read after handshake_limit_proven')
        result.update(measurement_status='passed', qualifying_mach_reads=len(qualifying),
                      rss_kernel_lifetime_peak_bytes=max(row['mach_rss_lifetime_max_bytes'] for row in qualifying))
    except BaseException as error:
        result.update(measurement_status='failed', error=f'{type(error).__name__}: {error}'[:2048])
    finally:
        if process is not None and process.returncode is None:
            try:
                # The reused stop adapter sends both signals before wait(). No poll() occurs above.
                client = a._stop_client(process)
            except BaseException as error:
                client = {'reaped': process.returncode is not None, 'returncode': process.returncode,
                          'audit_required': True, 'error': f'{type(error).__name__}: {error}'[:1024]}
        if process is not None:
            for stream in (process.stdout, process.stderr):
                if stream is not None:
                    stream.close()
        result['client_cleanup'] = client
        deadline = time.monotonic() + CLEANUP_SECONDS
        terminal = len(result['stages']) == len(STAGES)
        while True:
            cleanup = cleanup_audit(a, probe, helper, witness, client, terminal)
            if not cleanup['audit_required'] or cleanup['errors'] or time.monotonic() >= deadline:
                break
            time.sleep(0.05)
        result['helper_cleanup'] = cleanup
        result['audit_required'] = client.get('audit_required', True) or cleanup['audit_required']
        if process is None:
            result['audit_required'] = False
            result['helper_cleanup'] = {'not_started': True, 'audit_required': False}
        if witness is not None:
            try:
                os.close(witness['fd'])
            except OSError as error:
                result.update(audit_required=True, witness_close_error=str(error)[:1024])
        result['occupancy_status'] = ('passed' if result['measurement_status'] == 'passed' and
                                      not result['audit_required'] else 'incomplete')
        result.update(finished_utc=a._now(), sample_attempts=attempts, temporary_state_retained=True)
        a._write(evidence / 'report.json', report)
    require(not result['audit_required'], 'uncertain helper/client cleanup; stop and audit retained state')
    require(result['occupancy_status'] == 'passed', 'occupancy evidence incomplete; stop subsequent trials')
    a._disk(report, f'after_{image}_{index}')


def execute(path, run, repetitions):
    a = adapters()
    require(not run or (sys.platform == 'darwin' and platform.machine() == 'arm64'), 'native arm64 macOS is required')
    if run:
        for name in ('waitid', 'WNOWAIT', 'P_PID', 'WEXITED', 'WNOHANG'):
            require(hasattr(os, name), 'safe unreaped client lifecycle requires os.' + name)
    descriptor = a._lock()
    evidence = None
    report = {'schema': 1, 'status': 'preparing', 'started_utc': a._now(), 'trials': [],
              'runner': {'path': str(Path(__file__).absolute()), 'sha256': a._sha(__file__)},
              'adapters': {'path': str(ADAPTER), 'sha256': ADAPTER_SHA},
              'host': {'platform': platform.platform(), 'python': sys.version,
                       'nofile': list(resource.getrlimit(resource.RLIMIT_NOFILE))},
              'bounds': {'trial_seconds': TRIAL_SECONDS, 'cleanup_seconds': CLEANUP_SECONDS,
                         'sample_attempts': MAX_SAMPLES, 'log_bytes_per_stream': LOG_BYTES,
                         'line_bytes': LINE_BYTES, 'sample_seconds': SAMPLE_SECONDS,
                         'repetitions_per_image': repetitions, 'disk_floor_bytes': a.FLOOR},
              'semantics': {'rss': 'Mach resident_size_max is a helper kernel lifetime RSS maximum through a successful post-handshake proof read, including startup. It is not exact instantaneous occupancy RSS or a process-tree maximum.',
                            'cleanup': 'Independent exact birth exit plus original witness availability. A removed fixture path needs retained inode nlink zero, exit zero and validated terminal stage. A timeout proves nothing.'}}
    interrupted, handlers = [None], {}
    def interrupt(number, _frame):
        interrupted[0] = number  # No exception can skip child capture or interrupt cleanup.
    try:
        if run:
            for number in (signal.SIGINT, signal.SIGTERM):
                handlers[number] = signal.signal(number, interrupt)
        a._disk(report, 'before_input_check')
        BASE.mkdir(mode=0o700, exist_ok=True)
        value = BASE.lstat()
        require(stat.S_ISDIR(value.st_mode) and value.st_uid == os.getuid() and value.st_mode & 0o077 == 0,
                'evidence base must be an owned private directory')
        evidence = BASE / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ-') + uuid.uuid4().hex[:8])
        evidence.mkdir(mode=0o700)
        report['evidence'] = str(evidence)
        inputs, before = check_inputs(path, evidence)
        report['inputs'] = inputs
        a._write(evidence / 'report.json', report)
        if run:
            require(interrupted[0] is None, 'interrupted before observer load')
            a._disk(report, 'before_observer_load')
            probe = a.load_probe()
            report['status'] = 'running'
            for image in ('cli', 'worker'):
                for index in range(1, repetitions + 1):
                    require(interrupted[0] is None, 'interrupted before another trial')
                    trial(a, probe, inputs, evidence, image, index, report, lambda: interrupted[0])
        a.record_source_observations(report, evidence, before)
        for image in inputs['binaries'].values():
            a._pin(image, executable=True)
        a._pin(inputs['original_input'])
        report.update(status='passed' if run else 'inputs_checked', source_unchanged_after_check=True,
                      native_code_loaded=run, helpers_started=bool(report['trials']))
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}'[:4096])
    finally:
        report.update(finished_utc=a._now(), interrupt_signal=interrupted[0],
                      audit_required=any(row.get('audit_required', True) for row in report['trials']))
        if evidence is not None:
            a._write(evidence / 'report.json', report)
        for number, handler in handlers.items():
            signal.signal(number, handler)
        os.close(descriptor)
    print(json.dumps({key: report.get(key) for key in ('status', 'evidence', 'audit_required', 'error')}, indent=2))
    return 0 if report['status'] in ('passed', 'inputs_checked') else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, help='calibration schema 1 inputs plus binaries.occupancy_libtest')
    parser.add_argument('--run', action='store_true', help='explicitly load observer and run native occupancy trials')
    parser.add_argument('--repetitions', type=int, choices=(2, 3), default=3, help='fresh trials per CLI and worker image')
    args = parser.parse_args()
    if args.inputs is None:
        if args.run:
            parser.error('--run requires --inputs')
        print(json.dumps({'status': 'prepared_only', 'native_code_loaded': False, 'helpers_started': False,
                          'inputs': 'calibration schema 1 plus binaries.occupancy_libtest with build_receipt',
                          'next_step': 'Check --inputs first; add --run only after review and workload slot authorization.'}, indent=2))
        return 0
    return execute(args.inputs, args.run, args.repetitions)


if __name__ == '__main__':
    sys.exit(main())
