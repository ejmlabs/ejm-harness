#!/usr/bin/env python3
"""Run the approved focused CLI checks and two small shared-budget smoke cases."""

from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import fcntl
import hashlib
import importlib.util
import json
import os
import platform
import shutil
import signal
import sqlite3
import subprocess
import sys
import time
import traceback
import uuid
from pathlib import Path

CLI = Path('/Users/everettmorgan/Desktop/ejm-cli')
HARNESS = Path('/Users/everettmorgan/Desktop/ejm-harness')
BASE = Path('/private/tmp/ejm-cli-capacity-fixture-checks-20261020')
LOCK = Path('/tmp/ejm-capacity-cargo.lock')
NODE = '/opt/homebrew/opt/node@26/bin'
NATIVE_RUNNER = Path('/private/tmp/ejm-capacity-startup-floor-simultaneous-20261020.v2.py')
NATIVE_UTIL = Path('/private/tmp/ejm-native-helper-complement-20261020.v2.py')
NATIVE_C = Path('/private/tmp/ejm-native-helper-complement-20261020.c')
FLOOR = 10 * 1024**3
OVERALL_SECONDS = 900
FIXTURE_INPUTS = {
    'crates/ejm-cli/src/ui/capacity_fixture.rs': '792dc10da6d14bf629848aa5ec51bffcf69f499eae6304b89d324185d1c7a3e4',
    'scripts/check_terminal.py': 'd912e286bbdb472beef6940579a5ea7d5bf10ecb2fd2f4ee0e7dbefddebe7e9d',
    'docs/benchmarks.md': '2d8d6578de1dacc6bd36dee99dfd71e335ef4ce9073d51f545099c37f7844dd3',
}


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def receipt(path):
    path = Path(path)
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def git(root, *arguments):
    return subprocess.check_output(
        ['git', *arguments], cwd=root,
        env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}, text=True,
    )


def source_state(root):
    names = sorted(set(filter(None, git(root, 'ls-files', '-co', '--exclude-standard', '-z').split('\0'))))
    index = Path(git(root, 'rev-parse', '--git-path', 'index').strip())
    if not index.is_absolute():
        index = root / index
    return {
        'root': str(root), 'top_level': git(root, 'rev-parse', '--show-toplevel').strip(),
        'head': git(root, 'rev-parse', 'HEAD').strip(),
        'status': git(root, 'status', '--short', '--untracked-files=all'),
        'index': receipt(index),
        'files': {name: sha(root / name) for name in names if (root / name).is_file()},
        'symlinks': {name: {'target': os.readlink(root / name), 'resolved': str((root / name).resolve())}
                     for name in names if (root / name).is_symlink()},
    }


def source_changes(before, after):
    return {key: sorted(name for name in before[key].keys() | after[key].keys()
                        if before[key].get(name) != after[key].get(name))
            for key in ('files', 'symlinks')}


def environment():
    value = {key: item for key, item in os.environ.items()
             if not key.startswith(('EJM_CLI_', 'EJM_REMOTE_', 'ANTHROPIC_', 'CLAUDE_'))
             and key not in {'OPENAI_API_KEY', 'OPENAI_BASE_URL', 'CLAUDECODE'}}
    value.update({
        'PATH': NODE + os.pathsep + value.get('PATH', ''),
        'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0', 'CARGO_NET_OFFLINE': 'true',
        'CARGO_TARGET_DIR': str(CLI / 'target'), 'PYTHONDONTWRITEBYTECODE': '1',
    })
    return value


def bounded_error(errors, phase, error):
    if len(errors) < 32:
        errors.append({'phase': phase, 'utc': now(), 'error': str(error)[:2048]})


def stop_group(process, row):
    """Keep the group leader unreaped until all group signals have finished."""
    check(process.returncode is None, 'cleanup requires an unreaped group leader')
    row['cleanup_signals'] = []
    row['cleanup_signal_errors'] = []
    row['cleanup_wait_errors'] = []
    row['group_leader_reaping_deferred_until_after_signals'] = True

    def send(signum):
        try:
            os.killpg(process.pid, signum)
            row['cleanup_signals'].append(signum.name)
        except ProcessLookupError:
            pass
        except OSError as error:
            bounded_error(row['cleanup_signal_errors'], signum.name, error)

    try:
        try:
            send(signal.SIGTERM)
            time.sleep(5)
        finally:
            send(signal.SIGKILL)
    except BaseException as error:
        row['cleanup_interrupted'] = True
        bounded_error(row['cleanup_signal_errors'], 'signal_sequence_interrupted', error)
    finally:
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            row['cleanup_wait_timed_out'] = True
        except BaseException as error:
            bounded_error(row['cleanup_wait_errors'], 'wait_after_group_signals', error)
        row['reaped'] = process.returncode is not None and not row['cleanup_wait_errors']
        row['returncode'] = process.returncode
        row['cleanup_requires_audit'] = (not row['reaped'] or bool(row['cleanup_signal_errors']))


class Run:
    def __init__(self, directory):
        self.directory = directory
        self.deadline = time.monotonic() + OVERALL_SECONDS
        self.env = environment()
        self.report = {
            'schema': 1, 'status': 'running', 'started_utc': now(),
            'cwd': str(CLI), 'shell': False, 'required_shell_login': False,
            'global_lock': str(LOCK), 'disk_floor_bytes': FLOOR,
            'overall_deadline_seconds': OVERALL_SECONDS, 'phases': [], 'cases': [], 'disk': [],
            'environment': {key: self.env[key] for key in ('PATH', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
                                                         'CARGO_NET_OFFLINE', 'CARGO_TARGET_DIR',
                                                         'PYTHONDONTWRITEBYTECODE')},
            'limits': [
                'Focused local macOS fixture checks only; task 7.4 remains incomplete.',
                'Two participants per mode, 100 agents each, five seconds requested work; no broad matrix.',
                'Registry and endpoint discovery are sampled. No arbitrary detached-descendant containment claim.',
                'Native counter code is reused only for stable identities and witness cleanup, not memory acceptance.',
                'Source hashes cover Git-listed files, including untracked nonignored files; ignored caches and external dependencies are not frozen.',
                'Work completion and cleanup have separate verdicts. A process exit code alone cannot pass a workload.',
                'No paid calls, installs, downloads, source-format writes, commits, default activation or publication.',
            ],
        }

    def save(self):
        write(self.directory / 'report.json', self.report)

    def guard(self, phase):
        free = shutil.disk_usage(self.directory).free
        self.report['disk'].append({'phase': phase, 'utc': now(), 'free_bytes': free})
        check(free >= FLOOR, f'free disk below 10 GiB during {phase}: {free}')
        check(time.monotonic() < self.deadline, f'overall deadline during {phase}')

    def command(self, name, command, timeout=60, expected=(0,)):
        self.guard('before_' + name)
        row = {'name': name, 'command': command, 'cwd': str(CLI), 'started_utc': now(),
               'timeout_seconds': timeout, 'expected_returncodes': list(expected)}
        self.report['phases'].append(row)
        out = self.directory / (name + '.stdout')
        err = self.directory / (name + '.stderr')
        started = time.monotonic()
        process = None
        print('START ' + name, flush=True)
        self.save()
        try:
            with out.open('xb') as stdout, err.open('xb') as stderr:
                process = subprocess.Popen(command, cwd=CLI, env=self.env, stdin=subprocess.DEVNULL,
                                           stdout=stdout, stderr=stderr, start_new_session=True)
                row['pid'] = process.pid
                next_guard = started
                while process.poll() is None:
                    current = time.monotonic()
                    check(current - started < timeout, name + ' exceeded its deadline')
                    if current >= next_guard:
                        self.guard('during_' + name)
                        check(out.stat().st_size + err.stat().st_size <= 64 * 1024**2,
                              name + ' exceeded its 64 MiB log bound')
                        next_guard = current + 1
                    time.sleep(0.1)
                row['returncode'] = process.wait()
                check(row['returncode'] in expected, name + ' returned ' + str(row['returncode']))
                row['status'] = 'passed'
        except BaseException as error:
            row.update(status='failed', error=f'{type(error).__name__}: {error}')
            raise
        finally:
            if process is not None and process.poll() is None:
                stop_group(process, row)
                row['terminated_after_failure'] = True
                row['returncode'] = process.returncode
            row.update(finished_utc=now(), duration_seconds=time.monotonic() - started,
                       stdout=receipt(out), stderr=receipt(err))
            row['reaped'] = process is None or row.get('reaped', process.returncode is not None)
            row['logs_final'] = row['reaped'] and not (row.get('cleanup_signal_errors')
                                                      or row.get('cleanup_wait_errors'))
            if process is not None and not row['reaped']:
                self.report.setdefault('unreaped_command_pids', []).append(process.pid)
            if not row['logs_final'] or row.get('cleanup_requires_audit'):
                self.report['remaining_work_requires_audit'] = True
            self.save()
            print('END ' + name + ': ' + str(row.get('status')), flush=True)
        return out


def load_native(run):
    copies = {}
    for source in (Path(__file__), NATIVE_RUNNER, NATIVE_UTIL, NATIVE_C):
        copied = run.directory / source.name
        shutil.copy2(source, copied)
        copies[str(source)] = {**receipt(source), 'retained_copy': str(copied)}
    run.report['runner_inputs'] = copies
    spec = importlib.util.spec_from_file_location('retained_native_cleanup', NATIVE_RUNNER)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    dylib = run.directory / 'observe.dylib'
    run.command('native_observer_build', ['cc', '-dynamiclib', '-O2', '-Wall', '-Wextra', '-Werror',
                                         str(run.directory / NATIVE_C.name), '-o', str(dylib)], timeout=30)
    library = ctypes.CDLL(str(dylib))
    probe = library.ejm_observe
    probe.argtypes = [ctypes.c_int, ctypes.POINTER(native.UTIL.Observation)]
    probe.restype = ctypes.c_int
    run.report['native_observer_binary'] = receipt(dylib)
    return native, library, probe


def build_and_check(run):
    run.command('rustfmt_fixture', ['rustfmt', '--edition', '2024', '--check',
                                  'crates/ejm-cli/src/ui/capacity_fixture.rs'], timeout=30)
    run.command('python_syntax', [sys.executable, '-B', '-c',
                                 "from pathlib import Path; p=Path('scripts/check_terminal.py'); compile(p.read_text(), str(p), 'exec')"], timeout=10)
    run.command('measurement_verdict_tests', [sys.executable, '-B', '-m', 'unittest',
                                             'scripts.tests.test_terminal_measurement'], timeout=30)
    run.command('live_parser_help', [sys.executable, '-B', 'scripts/check_terminal.py', '--measure-live', '--help'], timeout=10)
    for name, option, value in (
        ('mode', '--capacity', 'invalid'), ('models_zero', '--model-requests', '0'),
        ('models_large', '--model-requests', '257'), ('jobs_zero', '--jobs', '0'),
        ('jobs_large', '--jobs', '129'),
    ):
        fixture = run.directory / ('rejected-' + name)
        run.command('parser_rejects_' + name,
                    [sys.executable, '-B', 'scripts/check_terminal.py', '--measure-live', '/usr/bin/true',
                     '--helper', '/usr/bin/true', '--fixture-root', str(fixture),
                     '--output', str(run.directory / ('rejected-' + name + '.json')), option, value],
                    timeout=10, expected=(2,))
        check(not fixture.exists(), name + ' parser rejection created fixture state')
    cargo = ['cargo']
    common = ['--release', '--locked', '--offline', '-p', 'ejm-cli', '--bin', 'ejm-cli', '--jobs', '2']
    run.command('strict_cli_clippy', cargo + ['clippy', *common, '--tests', '--', '-D', 'warnings'], timeout=360)
    helper_output = run.command('release_helper_build', cargo + ['build', *common, '--message-format=json'], timeout=360)
    test_output = run.command('release_fixture_build', cargo + ['test', *common, '--no-run', '--message-format=json'], timeout=360)

    def executable(output, test):
        candidates = []
        for line in output.read_text().splitlines():
            value = json.loads(line)
            if (value.get('reason') == 'compiler-artifact' and value.get('executable')
                    and value.get('target', {}).get('name') == 'ejm-cli'
                    and value.get('profile', {}).get('test') is test):
                candidates.append(Path(value['executable']))
        check(len(set(candidates)) == 1, 'expected one CLI executable in ' + str(output))
        return candidates[0]

    binaries = run.directory / 'bin'
    binaries.mkdir()
    frozen = {}
    for name, source in (('helper', executable(helper_output, False)), ('fixture', executable(test_output, True))):
        destination = binaries / ('ejm-cli-' + name)
        check(shutil.disk_usage(run.directory).free >= FLOOR + source.stat().st_size,
              'free disk cannot retain a frozen ' + name + ' above the 10 GiB floor')
        shutil.copy2(source, destination)
        frozen[name] = destination
        run.report.setdefault('binaries', {})[name] = {**receipt(destination), 'built_path': str(source)}
    output = run.command('configuration_compatibility_test',
                         [str(frozen['fixture']), '--exact',
                          'ui::capacity_fixture::capacity_configuration_preserves_defaults_and_explicit_shared_policy',
                          '--nocapture', '--test-threads=1'], timeout=30)
    check('test result: ok. 1 passed; 0 failed;' in output.read_text(),
          'The focused configuration test did not execute exactly once')
    return frozen


def run_case(run, native, probe, mode, binaries):
    directory = run.directory / mode
    directory.mkdir(mode=0o700)
    root = directory / 'shared-capacity'
    result = {'mode': mode, 'started_utc': now(), 'completion_status': 'pending', 'cleanup_status': 'pending',
              'participants': [], 'registry_snapshots': [], 'discovery_errors': [], 'cleanup_errors': [],
              'requested_work_seconds': 5, 'models_per_participant': 2, 'jobs_per_participant': 1,
              'completion_deadline_seconds': 150, 'helper_cleanup_deadline_seconds': 12,
              'capacity_root': str(root), 'required_participant_overlap': 2, 'overlap_observed': False}
    run.report['cases'].append(result)
    observers, helpers, witnesses, clients = [], {}, {}, {}
    started = time.monotonic()
    next_snapshot = started

    def observe():
        nonlocal next_snapshot
        native.discover_helpers(root, helpers, probe, result['discovery_errors'])
        native.remember_witnesses(root, witnesses)
        current = time.monotonic()
        if current < next_snapshot:
            return
        if len(observers) != 2 or not all((item['fixture'] / 'ready.json').is_file() for item in observers):
            return
        result.setdefault('sqlite_reads_ready_utc', now())
        result.setdefault('sqlite_reads_ready_reason', 'both participant ready.json files published')
        try:
            state = native.snapshot(root)
            if state is not None:
                result['registry_snapshots'].append({'utc': now(), 'elapsed_seconds': current - started, 'state': state})
                active = []
                for owner in state['owners']:
                    pid = owner['pid']
                    expected = clients[pid]['birth'] if pid in clients else None
                    observation = native.observe_identity(probe, pid, expected=expected)
                    check(observation['parent_pid'] in {item['process'].pid for item in observers},
                          'Shared registry owner is not a live fixture child of an observer')
                    if pid not in clients:
                        clients[pid] = {'pid': pid, 'birth': observation['start_abstime'],
                                        'owner': owner['id'], 'first_seen': observation}
                    active.append(owner['id'])
                if len(active) == 2:
                    common = None
                    for owner in active:
                        domains = {row['domain'] for row in state['allocations'] if row['owner'] == owner}
                        common = domains if common is None else common & domains
                    if common:
                        result['overlap_observed'] = True
                        result.setdefault('first_overlap', {'utc': now(), 'owners': active, 'common_domains': sorted(common)})
        except (sqlite3.Error, ProcessLookupError, RuntimeError) as error:
            bounded_error(result['discovery_errors'], 'registry_snapshot', error)
        next_snapshot = current + 0.1

    try:
        run.guard('before_' + mode)
        for index in range(2):
            fixture = directory / ('participant-' + str(index + 1))
            report_path = directory / ('participant-' + str(index + 1) + '.json')
            command = [sys.executable, '-B', str(CLI / 'scripts/check_terminal.py'), '--measure-live',
                       str(binaries['fixture']), '--helper', str(binaries['helper']),
                       '--fixture-root', str(fixture), '--capacity-root', str(root), '--capacity', mode,
                       '--model-requests', '2', '--jobs', '1', '--agents', '100', '--seconds', '5',
                       '--samples', '1', '--idle-seconds', '0', '--slow-reader-ms', '0', '--headless',
                       '--output', str(report_path)]
            stdout = directory / ('observer-' + str(index + 1) + '.stdout')
            stderr = directory / ('observer-' + str(index + 1) + '.stderr')
            with stdout.open('xb') as out, stderr.open('xb') as err:
                process = subprocess.Popen(command, cwd=CLI, env=run.env, stdin=subprocess.DEVNULL,
                                           stdout=out, stderr=err, start_new_session=True)
            item = {'process': process, 'birth': None, 'fixture': fixture,
                    'stdout': stdout, 'stderr': stderr, 'report': report_path}
            observers.append(item)
            observation = native.observe_identity(probe, process.pid, parent=os.getpid())
            item['birth'] = observation['start_abstime']
            result['participants'].append({'command': command, 'cwd': str(CLI), 'observer_pid': process.pid,
                                           'observer_birth': observation['start_abstime'], 'report': str(report_path)})
        print('START shared-root smoke ' + mode, flush=True)
        next_guard = time.monotonic()
        while any(item['process'].poll() is None for item in observers):
            observe()
            current = time.monotonic()
            check(current - started < 150, mode + ' completion deadline exceeded')
            if current >= next_guard:
                run.guard('during_smoke_' + mode)
                run.save()
                next_guard = current + 1
            time.sleep(0.02)
        observe()
        for item, row in zip(observers, result['participants']):
            row['returncode'] = item['process'].wait()
            row['stdout'], row['stderr'] = receipt(item['stdout']), receipt(item['stderr'])
            check(item['report'].is_file(), mode + ' participant did not retain its JSON report')
            data = json.loads(item['report'].read_text())
            row['measurement_report'] = receipt(item['report'])
            fixture = data['fixture']
            row['json_completion'] = {key: fixture[key] for key in
                                      ('completed', 'completed_tools', 'failed', 'drain_failed',
                                       'drain_completed', 'drain_cancelled', 'capacity_policy', 'capacity_root')}
            check(row['returncode'] == 0 and data.get('workload_status') == 'passed', mode + ' observer verdict failed')
            check(fixture['failed'] == 0 and fixture['drain_failed'] == 0
                  and fixture['completed'] > 0 and fixture['completed_tools'] > 0,
                  mode + ' JSON did not establish successful useful work')
            check(data['capacity'] == mode and data['model_requests'] == 2 and data['jobs'] == 1
                  and data['capacity_root'] == str(root), mode + ' observer settings were not retained')
            policy = fixture['capacity_policy']
            check(policy['mode'] == mode and policy['max_sessions'] == 100
                  and policy['max_model_requests'] == 2 and policy['max_jobs'] == 1
                  and fixture['capacity_root'] == str(root), mode + ' native fixture settings were not forwarded')
        check(result['overlap_observed'] and len(clients) == 2,
              mode + ' lacked two observed participants with one shared ancestor budget')
        result['completion_status'] = 'passed'
    except Exception as error:
        result.update(completion_status='failed', completion_error=str(error), traceback=traceback.format_exc())
    finally:
        cleanup_started = time.monotonic()
        attempt = lambda phase, operation, fallback=None: native.cleanup_step(result, phase, operation, fallback)
        # Stop files request normal drain first. Signals are only a failed-run bound.
        for item in observers:
            if item['fixture'].is_dir() and item['process'].poll() is None:
                attempt('request_stop_' + str(item['process'].pid), lambda item=item: (item['fixture'] / 'stop').touch())
        try:
            while any(item['process'].poll() is None for item in observers) and time.monotonic() - cleanup_started < 10:
                attempt('observe_draining', observe)
                time.sleep(0.05)

            def stop_observer(item):
                process = item['process']
                if process.poll() is None:
                    cleanup = {'pid': process.pid}
                    stop_group(process, cleanup)
                    result.setdefault('forced_observer_cleanup', []).append(cleanup)
                    result.setdefault('forced_observer_shutdown', []).append(process.pid)
                else:
                    process.wait()

            for item in observers:
                attempt('reap_observer_' + str(item['process'].pid), lambda item=item: stop_observer(item))

            def stop_client(item):
                if native.identity_ended(probe, item['pid'], item['birth']):
                    return
                native.observe_identity(probe, item['pid'], expected=item['birth'])
                try:
                    os.kill(item['pid'], signal.SIGTERM)
                except ProcessLookupError:
                    pass
                result.setdefault('forced_client_shutdown', []).append(item['pid'])

            for item in clients.values():
                attempt('stop_client_' + str(item['pid']), lambda item=item: stop_client(item))

            def client_ended(item):
                return attempt('client_identity_' + str(item['pid']),
                               lambda: native.identity_ended(probe, item['pid'], item['birth']), False)

            def helper_ended(item):
                return attempt('helper_identity_' + item['identity']['generation'],
                               lambda: native.identity_ended(probe, item['identity']['pid'], item['helper_birth']), False)

            def helper_released(item):
                return attempt('helper_witness_' + item['identity']['generation'],
                               lambda: native.witness_available(item['witness'], item['witness_record']), False)

            def participant_released(fd, record):
                return attempt('participant_witness_' + record['path'],
                               lambda: native.witness_available(fd, record), False)

            deadline = time.monotonic() + 12
            while True:
                attempt('observe_cleanup', observe)
                ended = all([client_ended(item) for item in clients.values()])
                ended = all([helper_ended(item) and helper_released(item) for item in helpers.values()]) and ended
                released = all([participant_released(fd, record) for fd, record in witnesses.values()])
                if ended and released or time.monotonic() >= deadline:
                    break
                time.sleep(0.025)
            result['client_cleanup'] = [{**item, 'identity_ended': client_ended(item)}
                                        for item in clients.values()]
            result['unresolved_client_identities'] = [row for row in result['client_cleanup'] if not row['identity_ended']]
            result['observer_cleanup'] = [{'pid': item['process'].pid, 'reaped': item['process'].returncode is not None,
                                           'identity_ended': item['birth'] is not None and
                                                             attempt('observer_identity_' + str(item['process'].pid),
                                                                     lambda item=item: native.identity_ended(probe, item['process'].pid, item['birth']), False)}
                                          for item in observers]
            result['helper_cleanup'] = [{**{key: value for key, value in item.items() if key != 'witness'},
                                         'identity_ended': helper_ended(item),
                                         'witness_available': helper_released(item)}
                                        for item in helpers.values()]
            result['unresolved_helper_identities'] = [row for row in result['helper_cleanup']
                                                       if not (row['identity_ended'] and row['witness_available'])]
            result['participant_witness_cleanup'] = [{**record, 'available': participant_released(fd, record)}
                                                     for fd, record in witnesses.values()]
            generations = {row['generation'] for sample in result['registry_snapshots']
                           for row in sample['state']['native_helpers'] if row['committed']}
            result['sampled_committed_generations'] = sorted(generations)
            result['helper_membership_proved'] = (bool(generations) and generations <= helpers.keys()
                                                  and all(item['identity']['accounted'] for item in helpers.values()))
            all_ended = (all(row['identity_ended'] for row in result['client_cleanup'])
                         and all(row['identity_ended'] and row['reaped'] for row in result['observer_cleanup'])
                         and all(row['identity_ended'] and row['witness_available'] for row in result['helper_cleanup'])
                         and all(row['available'] for row in result['participant_witness_cleanup']))
            result['cleanup_status'] = 'passed' if (len(clients) == 2 and helpers and witnesses and all_ended
                                                    and result['helper_membership_proved']
                                                    and not result.get('forced_observer_shutdown')
                                                    and not result.get('forced_client_shutdown')) else 'failed'
        except Exception as error:
            result['cleanup_status'] = 'failed'
            bounded_error(result['cleanup_errors'], 'cleanup', error)
        finally:
            for item in helpers.values():
                attempt('close_helper_witness_' + item['identity']['generation'], lambda item=item: os.close(item['witness']))
            for fd, _ in witnesses.values():
                attempt('close_participant_witness_' + str(fd), lambda fd=fd: os.close(fd))
            if result['cleanup_errors']:
                result['cleanup_status'] = 'failed'
            result['cleanup_elapsed_seconds'] = time.monotonic() - cleanup_started
            result['finished_utc'] = now()
            result['status'] = 'passed' if (result['completion_status'] == result['cleanup_status'] == 'passed') else 'failed'
            run.save()
            print('END shared-root smoke ' + mode + ': ' + result['status'], flush=True)
    return result['status'] == 'passed'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', required=True,
                        help='execute only after the root agent releases the workload hold')
    parser.parse_args()
    check(platform.system() == 'Darwin', 'This scratch runner requires native macOS evidence APIs')
    directory = BASE / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8])
    directory.mkdir(mode=0o700, parents=True)
    run = Run(directory)
    print('EVIDENCE_DIRECTORY=' + str(directory), flush=True)
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        run.report['lock_acquired_utc'] = now()
        print('GLOBAL_LOCK_ACQUIRED', flush=True)
        before = {}
        try:
            run.guard('before_checks')
            for name, expected in FIXTURE_INPUTS.items():
                check(sha(CLI / name) == expected, 'Prepared CLI fixture checkpoint changed: ' + name)
            for label, root in (('cli', CLI), ('harness', HARNESS)):
                before[label] = source_state(root)
                write(directory / (label + '-source-before.json'), before[label])
            run.report['host'] = {'platform': platform.platform(), 'machine': platform.machine(), 'logical_cpus': os.cpu_count()}
            run.command('tool_versions', [sys.executable, '-B', '-c',
                        "import json,subprocess; print(json.dumps({name:subprocess.check_output(command,text=True).strip() for name,command in [('rustc',['rustc','--version']),('cargo',['cargo','--version']),('node',['node','--version']),('python',['python3','--version'])]}))"], timeout=20)
            binaries = build_and_check(run)
            native, library, probe = load_native(run)
            check(library is not None, 'Native observation library must remain loaded')
            outcomes = []
            for mode in ('fixed', 'auto'):
                outcomes.append(run_case(run, native, probe, mode, binaries))
                if run.report['cases'][-1]['cleanup_status'] != 'passed':
                    break
            run.report['status'] = 'passed' if len(outcomes) == 2 and all(outcomes) else 'failed'
        except BaseException as error:
            run.report.update(status='failed', error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
        finally:
            for label, root in (('cli', CLI), ('harness', HARNESS)):
                try:
                    after = source_state(root)
                    write(directory / (label + '-source-after.json'), after)
                    if label in before:
                        delta = source_changes(before[label], after)
                        stable = (not any(delta.values()) and before[label]['head'] == after['head']
                                  and before[label]['index']['sha256'] == after['index']['sha256'])
                        run.report[label + '_source_stability'] = {'stable': stable, 'changes': delta}
                        if not stable:
                            run.report['status'] = 'failed'
                except Exception as error:
                    run.report['status'] = 'failed'
                    run.report[label + '_source_receipt_error'] = str(error)
            for name, item in run.report.get('runner_inputs', {}).items():
                try:
                    stable = sha(Path(name)) == item['sha256']
                except OSError:
                    stable = False
                if not stable:
                    run.report['status'] = 'failed'
                    run.report.setdefault('runner_input_changes', []).append(name)
            for name, item in run.report.get('binaries', {}).items():
                try:
                    stable = sha(Path(item['path'])) == item['sha256']
                except OSError:
                    stable = False
                if not stable:
                    run.report['status'] = 'failed'
                    run.report.setdefault('binary_changes', []).append(name)
            run.report['all_commands_reaped'] = not run.report.get('unreaped_command_pids')
            if (not run.report['all_commands_reaped']
                    or run.report.get('remaining_work_requires_audit')
                    or any(case['cleanup_status'] != 'passed' for case in run.report['cases'])):
                run.report['status'] = 'failed'
                run.report['remaining_work_requires_audit'] = True
            run.report['finished_utc'] = now()
            run.report['evidence_files'] = {str(path.relative_to(directory)): receipt(path) for path in directory.rglob('*')
                                            if path.is_file() and path.name != 'report.json'
                                            and path.suffix not in {'.sqlite3', '.sqlite3-wal', '.sqlite3-shm'}
                                            and 'shared-capacity' not in path.parts
                                            and not any(part.startswith('participant-') for part in path.relative_to(directory).parts[:-1])}
            run.save()
            print(json.dumps({'status': run.report['status'], 'error': run.report.get('error'),
                              'report': str(directory / 'report.json')}), flush=True)
    print('GLOBAL_LOCK_RELEASED', flush=True)
    return 0 if run.report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
