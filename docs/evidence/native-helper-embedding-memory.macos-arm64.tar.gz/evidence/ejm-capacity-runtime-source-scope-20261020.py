"""Compare complete source receipts while recording unrelated site edits."""

EXCLUDED_FILES = frozenset({
    'docs/contributing.md',
    '.agents/skills/harness-site/SKILL.md',
    '.agents/skills/ejm-cli-site/SKILL.md',
})


def excluded(name):
    return name.startswith('site/') or name in EXCLUDED_FILES


def source_key(value):
    return {
        'root': value['root'],
        'top_level': value['top_level'],
        'head': value['head'],
        'index_sha256': value['index']['sha256'],
        'status': '\n'.join(line for line in value['status'].splitlines()
                            if not excluded(line[3:])),
        'files': {name: data for name, data in value['files'].items() if not excluded(name)},
        'symlinks': {name: data for name, data in value['symlinks'].items() if not excluded(name)},
    }


def excluded_changes(before, after):
    return {
        key: {name: {'before': before[key].get(name), 'after': after[key].get(name)}
              for name in sorted(before[key].keys() | after[key].keys())
              if excluded(name) and before[key].get(name) != after[key].get(name)}
        for key in ('files', 'symlinks')
    }


POLICY = {
    'excluded_prefixes': ['site/'],
    'excluded_files': sorted(EXCLUDED_FILES),
    'frozen': 'Every other file, symlink and Git status entry, plus HEAD and index SHA256.',
    'evidence': 'Full before/after manifests and excluded path hash deltas are retained.',
    'reason': 'Concurrent site maintenance does not affect these Rust helper images or native measurement fixtures.',
}
