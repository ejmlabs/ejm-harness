#!/usr/bin/env python3
"""Prepare or run six bounded real-image helper startup observations on macOS.

Importing this module and the default CLI mode never load a dylib or start a
helper. The five public observer adapters are also usable by the occupancy
wrapper. This scratch runner uses only the standard library and the pinned
existing observer. It is not product code or a second sampling framework.
"""

from __future__ import annotations

import argparse
import ctypes
import datetime as dt
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import signal
import stat
import subprocess
import sys
import time
import types
import uuid


BASE = Path('/private/tmp/ejm-capacity-real-helper-calibration-20261020')
TEMPLATE = Path(str(BASE) + '.inputs.example.json')
LOCK = Path('/tmp/ejm-capacity-cargo.lock')
UTIL_PATH = Path('/private/tmp/ejm-native-helper-complement-20261020.v2.py')
UTIL_SHA = 'd294aff417622df8d12b67f013b53a1d51491ecd9615bc1d2ae6c3a1e8f568b7'
C_PATH = Path('/private/tmp/ejm-native-helper-complement-20261020.c')
C_SHA = '6a9318397f60481a6e81050873a0357e211472183c07a1c9397beed1cc58f482'
OBSERVER_REPORT = Path('/private/tmp/ejm-native-helper-complement-20261020/20261020T194654Z-4f678154/report.json')
OBSERVER_REPORT_SHA = '6e045ea07be882df0051c43e752a8ca2e08b08d03bb724d425aabe1c90767627'
DYLIB_PATH = OBSERVER_REPORT.with_name('observe.dylib')
DYLIB_SHA = 'f4c153bc4be5ebb966a9e4d4210d49163159d5a59a1f118f9545570724818333'
HARNESS = Path('/Users/everettmorgan/Desktop/ejm-harness')
CLI = Path('/Users/everettmorgan/Desktop/ejm-cli')
FLOOR = 10 * 1024**3
STARTUP_SECONDS = 10
WINDOW_SECONDS = 6
CLEANUP_SECONDS = 12
OVERALL_SECONDS = 240
SAMPLE_SECONDS = 0.05
MAX_SAMPLES = 400
LOG_BYTES = 1024**2
JSON_BYTES = 32 * 1024**2
_UTIL = None
_SCOPE = None
SOURCE_SCOPE_PATH = Path('/private/tmp/ejm-capacity-runtime-source-scope-20261020.py')
SOURCE_SCOPE_SHA = '866814f868c901e5bf64bcf688379d80db498da3992496b80046c4e33938fef0'


def _check(condition, message):
    if not condition:
        raise RuntimeError(message)


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024**2), b''):
            value.update(chunk)
    return value.hexdigest()


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _regular(path, executable=False):
    path = Path(path)
    _check(path.is_absolute(), 'input path must be absolute')
    value = path.lstat()
    _check(stat.S_ISREG(value.st_mode) and value.st_uid == os.getuid() and value.st_nlink == 1,
           f'input must be an owned regular single-link file: {path}')
    _check(not executable or value.st_mode & 0o111, f'input is not executable: {path}')
    return value


def _bytes(path, limit=JSON_BYTES):
    _regular(path)
    with Path(path).open('rb') as stream:
        value = stream.read(limit + 1)
    _check(len(value) <= limit, f'input exceeds size bound: {path}')
    return value


def _json(path, limit=JSON_BYTES):
    try:
        return json.loads(_bytes(path, limit))
    except (ValueError, UnicodeError) as error:
        raise RuntimeError(f'invalid JSON in {path}: {type(error).__name__}') from None


def _pin(value, executable=False):
    path = Path(value['path'])
    metadata = _regular(path, executable)
    expected = value['sha256']
    _check(isinstance(expected, str) and len(expected) == 64 and
           all(c in '0123456789abcdef' for c in expected), f'invalid SHA256 for {path}')
    _check(_sha(path) == expected, f'input hash changed: {path}')
    if 'bytes' in value:
        _check(value['bytes'] == metadata.st_size, f'input size changed: {path}')
    return {'path': str(path), 'sha256': expected, 'bytes': metadata.st_size}


def _util():
    global _UTIL
    if _UTIL is None:
        _pin({'path': str(UTIL_PATH), 'sha256': UTIL_SHA})
        module = types.ModuleType('_ejm_frozen_helper_observer_v2')
        module.__file__ = str(UTIL_PATH)
        exec(compile(_bytes(UTIL_PATH, 128 * 1024), str(UTIL_PATH), 'exec'), module.__dict__)
        _check(len(module.FIELDS) == 16 and ctypes.sizeof(module.Observation) == 128,
               'unexpected frozen observer ABI')
        _UTIL = module
    return _UTIL


def load_probe(path=DYLIB_PATH, sha256=DYLIB_SHA):
    """Explicitly load a pinned existing SDK observer. Import alone does not load it."""
    _check(sys.platform == 'darwin', 'the pinned observer supports macOS only')
    _pin({'path': str(C_PATH), 'sha256': C_SHA})
    _pin({'path': str(path), 'sha256': sha256})
    utility = _util()
    library = ctypes.CDLL(str(path))
    probe = library.ejm_observe
    probe.argtypes = [ctypes.c_int, ctypes.POINTER(utility.Observation)]
    probe.restype = ctypes.c_int
    probe._ejm_library = library
    return probe


def _witness_state(witness, check_held=True):
    descriptor = os.fstat(witness['fd'])
    path = Path(witness['path']).lstat()
    for value in (descriptor, path):
        _check(stat.S_ISREG(value.st_mode) and value.st_uid == os.getuid() and value.st_nlink == 1,
               'lifetime witness file changed type, owner or link count')
        _check((value.st_dev, value.st_ino) == (witness['device'], witness['inode']),
               'lifetime witness identity changed')
    return {'stable': True, 'held': _util().held(witness['fd']) if check_held else None}


def open_witness(path, require_held=True):
    """Open an independent, noninherited descriptor for the stable lifetime witness.

    The caller owns this descriptor and must close it after its cleanup audit.
    Set require_held=False only for early discovery before transfer to the helper.
    """
    path = Path(path)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        metadata = os.fstat(descriptor)
        result = {'fd': descriptor, 'path': str(path), 'device': metadata.st_dev,
                  'inode': metadata.st_ino}
        # Do not race the launcher's first exclusive lock during early discovery.
        state = _witness_state(result, check_held=require_held)
        _check(not require_held or state['held'], 'lifetime witness is not held')
        return result
    except BaseException:
        os.close(descriptor)
        raise


def _endpoint(path):
    # Pass the bounded captured text through the existing redacting parser.
    raw = _bytes(path, 4096).decode('utf-8')
    text = types.SimpleNamespace(read_text=lambda: raw)
    try:
        return _util().endpoint(text)
    except (ValueError, KeyError, TypeError, UnicodeError) as error:
        raise RuntimeError(f'invalid helper advertisement: {type(error).__name__}') from None


def attach_helper(probe, endpoint_path, expected_parent, witness=None,
                  expected_domain=None, expected_accounted=False, require_held=True):
    """Pin advertised generation, exact kernel birth, expected parent and witness.

    A caller-supplied witness remains caller-owned even if attachment fails.
    With no witness argument, this function closes its own descriptor on failure.
    """
    _check(type(expected_parent) is int and expected_parent > 0, 'expected parent PID is required')
    identity = _endpoint(endpoint_path)
    _check(identity['protocol'] == 2, 'unexpected helper protocol')
    _check(expected_domain is None or identity['domain'] == expected_domain, 'unexpected helper domain')
    _check(identity['accounted'] is expected_accounted, 'unexpected helper accounting mode')
    own_witness = witness is None
    if own_witness:
        witness = open_witness(Path(endpoint_path).with_name('owner.lock'), require_held=require_held)
    try:
        first = _util().observe(probe, identity['pid'], parent=expected_parent)
        held = _witness_state(witness, check_held=require_held)['held']
        _check(not require_held or held, 'helper lifetime witness is not held')
        _check(_endpoint(endpoint_path) == identity, 'helper advertisement changed during attach')
        return {'identity': identity, 'birth': first['start_abstime'],
                'expected_parent': expected_parent, 'witness': witness,
                'endpoint_path': str(endpoint_path), 'first_observation': first}
    except BaseException:
        if own_witness:
            os.close(witness['fd'])
        raise


def sample_helper(probe, helper, require_held=True):
    """Read the frozen observer ABI, preserving exact identity and witness checks."""
    _check(_endpoint(helper['endpoint_path']) == helper['identity'], 'helper generation changed')
    before = _witness_state(helper['witness'], check_held=require_held)
    _check(not require_held or before['held'], 'helper lifetime witness was released')
    result = _util().observe(probe, helper['identity']['pid'], expected=helper['birth'],
                             parent=helper['expected_parent'])
    after = _witness_state(helper['witness'], check_held=require_held)
    _check(not require_held or after['held'], 'helper lifetime witness released during sample')
    return result


def helper_end_state(probe, helper, witness=None):
    """Return a nonblocking cleanup audit. A timeout never proves exit.

    Exit is proved only by ESRCH or a different exact birth, plus availability of
    the same stable witness. An unknown helper identity remains uncertain.
    """
    witness = witness if witness is not None else (helper or {}).get('witness')
    result = {'identity_known': helper is not None, 'identity_ended': False,
              'witness_stable': False, 'witness_available': False, 'errors': []}
    if witness is not None:
        try:
            state = _witness_state(witness)
            result.update(witness_stable=True, witness_available=not state['held'])
        except Exception as error:
            result['errors'].append(str(error)[:1024])
    if helper is not None:
        try:
            utility = _util()
            observation = utility.Observation()
            code = probe(helper['identity']['pid'], ctypes.byref(observation))
            absent = code != 0 and observation.sample_errno == errno.ESRCH
            replaced = code == 0 and observation.start_abstime > 0 and observation.start_abstime != helper['birth']
            result.update(pid=helper['identity']['pid'], result=code,
                          sample_errno=observation.sample_errno,
                          observed_birth=observation.start_abstime,
                          identity_ended=bool(absent or replaced),
                          exit_evidence='ESRCH' if absent else ('different_birth' if replaced else None))
        except Exception as error:
            result['errors'].append(str(error)[:1024])
    result['proved'] = (result['identity_ended'] and result['witness_stable'] and
                        result['witness_available'] and not result['errors'])
    result['audit_required'] = not result['proved']
    return result


def _git(root, *arguments):
    result = subprocess.run(['git', *arguments], cwd=root, capture_output=True, timeout=10,
                            env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    _check(result.returncode == 0, f'read-only git query failed: {arguments[0]}')
    _check(len(result.stdout) <= 4 * 1024**2 and len(result.stderr) <= 4096,
           'read-only git output exceeds bound')
    return result.stdout.decode('utf-8')


def _source_state(root):
    names = sorted(set(filter(None, _git(root, 'ls-files', '-co', '--exclude-standard', '-z').split('\0'))))
    _check(len(names) <= 20000, 'source manifest exceeds file count bound')
    index = Path(_git(root, 'rev-parse', '--git-path', 'index').strip())
    if not index.is_absolute():
        index = root / index
    return {
        'root': str(root), 'top_level': _git(root, 'rev-parse', '--show-toplevel').strip(),
        'head': _git(root, 'rev-parse', 'HEAD').strip(),
        'status': _git(root, 'status', '--short', '--untracked-files=all'),
        'index': {'path': str(index), 'sha256': _sha(index), 'bytes': index.stat().st_size},
        'files': {name: _sha(root / name) for name in names if (root / name).is_file()},
        'symlinks': {name: {'target': os.readlink(root / name), 'resolved': str((root / name).resolve())}
                     for name in names if (root / name).is_symlink()},
    }


def _source_scope():
    global _SCOPE
    if _SCOPE is None:
        _pin({'path': str(SOURCE_SCOPE_PATH), 'sha256': SOURCE_SCOPE_SHA})
        module = types.ModuleType('_ejm_capacity_runtime_source_scope')
        exec(compile(_bytes(SOURCE_SCOPE_PATH, 16 * 1024), str(SOURCE_SCOPE_PATH), 'exec'), module.__dict__)
        _SCOPE = module
    return _SCOPE


def _source_key(value):
    return _source_scope().source_key(value)


def record_source_observations(report, evidence, before):
    scope = _source_scope()
    report['source_scope'] = {'policy': scope.POLICY, 'module': {
        'path': str(SOURCE_SCOPE_PATH), 'sha256': SOURCE_SCOPE_SHA}}
    rows = report.setdefault('source_observations', [])
    for root, state in before.items():
        after = _source_state(Path(root))
        paths = []
        for suffix, value in [('before', state), ('after', after)]:
            path = evidence / (Path(root).name + '-observation-source-' + suffix + '.json')
            _write(path, value)
            paths.append({'path': str(path), 'sha256': _sha(path)})
        rows.append({'root': root, 'before': paths[0], 'after': paths[1],
                     'excluded_changes': scope.excluded_changes(state, after)})
        _check(_source_key(state) == _source_key(after), 'runtime source changed: ' + root)


def _inputs(path):
    input_receipt = {'path': str(Path(path).absolute()), 'sha256': _sha(path)}
    value = _json(path)
    _check(value.get('schema') == 1, 'unsupported calibration input schema')
    observer = _pin({'path': str(OBSERVER_REPORT), 'sha256': OBSERVER_REPORT_SHA})
    observer_report = _json(OBSERVER_REPORT)
    _check(observer_report['counter_adapter_sha256'] == C_SHA and
           observer_report['counter_adapter_binary_sha256'] == DYLIB_SHA and
           observer_report['compile']['returncode'] == 0, 'observer compile receipt mismatch')
    utility = _pin({'path': str(UTIL_PATH), 'sha256': UTIL_SHA})
    source = _pin({'path': str(C_PATH), 'sha256': C_SHA})
    dylib = _pin({'path': str(DYLIB_PATH), 'sha256': DYLIB_SHA})
    _check(set(value['binaries']) == {'smoke', 'cli', 'worker'}, 'exactly smoke, cli and worker inputs are required')
    binaries, states = {}, {}
    for name in ('smoke', 'cli', 'worker'):
        requested = value['binaries'][name]
        binary = _pin(requested, executable=True)
        build_receipt = _pin(requested['build_receipt'])
        build = _json(build_receipt['path'])
        _check(build.get('schema') == 1, f'unsupported {name} build receipt schema')
        _check(_pin(build['copied_binary'], executable=True) == binary, f'{name} copied image receipt mismatch')
        compilation = build['build']
        output = compilation['output']
        _check(compilation['returncode'] == 0 and compilation['command'] and
               compilation['profile'] == 'release' and compilation['target'] == 'aarch64-apple-darwin' and
               compilation['started_utc'] and compilation['finished_utc'], f'incomplete successful {name} build record')
        _check(output['sha256'] == binary['sha256'] and output['bytes'] == binary['bytes'] and
               Path(output['path']).is_absolute(), f'{name} build output does not match copied image')
        for stream in ('stdout', 'stderr'):
            _pin(compilation[stream])
        roots = {entry['root'] for entry in build['sources']}
        expected_roots = {str(HARNESS), str(CLI)} if name == 'cli' else {str(HARNESS)}
        _check(roots == expected_roots and len(roots) == len(build['sources']), f'wrong source roots for {name}')
        sources = []
        for entry in build['sources']:
            root = Path(entry['root'])
            before_pin, after_pin = _pin(entry['before']), _pin(entry['after'])
            before, after = _json(before_pin['path']), _json(after_pin['path'])
            _check(before['root'] == str(root) and before['top_level'] == str(root), 'source manifest root mismatch')
            _check(before['files'] and _source_key(before) == _source_key(after),
                   f'source changed during {name} build: {root}')
            if str(root) not in states:
                states[str(root)] = _source_state(root)
            _check(_source_key(after) == _source_key(states[str(root)]), f'current source differs from {name} build: {root}')
            sources.append({'root': str(root), 'before': before_pin, 'after': after_pin,
                            'head': after['head'], 'source_digest': _digest(_source_key(after)),
                            'files': len(after['files']), 'symlinks': len(after['symlinks'])})
        binaries[name] = binary | {'build_receipt': build_receipt, 'build': compilation, 'sources': sources}
    return {'input': input_receipt, 'binaries': binaries,
            'observer': {'utility': utility, 'source': source, 'dylib': dylib, 'compile_receipt': observer}}, states


def _disk(report, phase):
    available = os.statvfs(BASE.parent)
    free = available.f_bavail * available.f_frsize
    report.setdefault('disk', []).append({'phase': phase, 'free_bytes': free, 'utc': _now()})
    _check(free >= FLOOR, f'free disk below 10 GiB floor at {phase}: {free}')


def _write(path, value):
    temporary = path.with_suffix('.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    temporary.replace(path)


def _start(command, directory):
    # Single-threaded standalone runner. Bound inherited log writes for both images.
    def limits():
        _, hard = resource.getrlimit(resource.RLIMIT_FSIZE)
        resource.setrlimit(resource.RLIMIT_FSIZE, (min(LOG_BYTES, hard) if hard != resource.RLIM_INFINITY else LOG_BYTES, hard))
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(('EJM_', 'OPENAI_', 'ANTHROPIC_', 'CLAUDE_')) and key != 'CLAUDECODE'}
    with (directory / 'stdout').open('xb') as out, (directory / 'stderr').open('xb') as err:
        return subprocess.Popen(command, cwd=directory, env=environment, stdin=subprocess.DEVNULL,
                                stdout=out, stderr=err, start_new_session=True, preexec_fn=limits)


def _stop_client(process):
    result = {'pid': process.pid, 'signals': [], 'errors': [], 'reaped': False}
    if process.returncode is not None:
        result.update(reaped=True, returncode=process.returncode, audit_required=False)
        return result

    def send(requested):
        try:
            # This direct child stays unreaped until both signals finish, so its
            # PID cannot be recycled between TERM and KILL. Never signal a helper.
            os.kill(process.pid, requested)
            result['signals'].append(requested.name)
        except ProcessLookupError:
            pass
        except OSError as error:
            result['errors'].append(f'{requested.name}: {type(error).__name__}: {error}'[:1024])

    try:
        try:
            send(signal.SIGTERM)
            time.sleep(1)
        finally:
            send(signal.SIGKILL)
    except BaseException as error:
        result['errors'].append(f'signal_sequence: {type(error).__name__}: {error}'[:1024])
    finally:
        try:
            process.wait(timeout=3)
        except BaseException as error:
            result['errors'].append(f'wait: {type(error).__name__}: {error}'[:1024])
    result.update(reaped=process.returncode is not None, returncode=process.returncode)
    result['audit_required'] = not result['reaped'] or bool(result['errors'])
    return result


def _summary(samples, window_end):
    mach = [row for row in samples if row['task_name_result'] == 0 and row['task_info_result'] == 0]
    complete = window_end is not None and window_end in mach
    return {
        'samples': len(samples), 'mach_success_samples': len(mach),
        'mach_unavailable_samples': len(samples) - len(mach),
        'rss_sampled_high_water_bytes': max((row['rss_bytes'] for row in samples), default=None),
        'rss_kernel_lifetime_peak_bytes': max((row['mach_rss_lifetime_max_bytes'] for row in mach), default=None),
        'rss_kernel_peak_status': 'covers_window_end' if complete else ('partial' if mach else 'unavailable'),
        'rss_kernel_peak_last_read_offset_seconds': mach[-1]['offset_seconds'] if mach else None,
        'physical_footprint_kernel_lifetime_peak_bytes': max((row['footprint_lifetime_max_bytes'] for row in samples), default=None),
        'physical_footprint_peak_status': 'covers_window_end' if window_end is not None else ('partial' if samples else 'unavailable'),
    }


def _trial(name, index, evidence, probe, inputs, report, overall_deadline):
    directory = evidence / f'{name}-{index}'
    directory.mkdir(mode=0o700)
    state, ready = directory / 'state', directory / 'ready.json'
    endpoint = state / 'native/fixture/endpoint.json'
    witness_path = endpoint.with_name('owner.lock')
    command = [inputs['binaries']['smoke']['path'], 'witness-client', str(state),
               str(ready), inputs['binaries'][name]['path']]
    result = {'image': name, 'index': index, 'started_utc': _now(), 'command': command,
              'stdout': str(directory / 'stdout'), 'stderr': str(directory / 'stderr'),
              'measurement_status': 'running', 'audit_required': True, 'samples': []}
    report['trials'].append(result)
    _write(evidence / 'report.json', report)
    process = helper = witness = window_end = None
    start = time.monotonic()
    ready_at = None
    next_sample, next_disk = start, start
    caught = None
    try:
        _check(overall_deadline - start >= STARTUP_SECONDS + WINDOW_SECONDS + CLEANUP_SECONDS + 7,
               'insufficient overall time remains for another safe trial')
        for image in ('smoke', name):
            _pin(inputs['binaries'][image], executable=True)
        _disk(report, f'before_{name}_{index}')
        process = _start(command, directory)
        result['client_pid'] = process.pid
        while True:
            current = time.monotonic()
            _check(current < overall_deadline, 'overall observation deadline')
            _check(process.poll() is None, 'witness client exited before observation completed')
            if current >= next_disk:
                _disk(report, f'{name}_{index}_observation')
                next_disk = current + 1
            if witness is None and witness_path.exists():
                witness = open_witness(witness_path, require_held=False)
                result['witness'] = {key: value for key, value in witness.items() if key != 'fd'}
            if helper is None and endpoint.exists():
                helper = attach_helper(probe, endpoint, process.pid, witness,
                                       expected_domain='fixture', require_held=False)
                witness = helper['witness']
                result.update(identity=helper['identity'], birth=helper['birth'],
                              advertisement_first_seen_offset_seconds=time.monotonic() - start)
                result['samples'].append(helper['first_observation'] | {
                    'offset_seconds': time.monotonic() - start, 'phase': 'startup_discovery'})
                next_sample = time.monotonic() + SAMPLE_SECONDS
            if helper is not None and ready_at is None and ready.exists():
                try:
                    marker = json.loads(_bytes(ready, 4096))
                except (ValueError, UnicodeError):
                    # std::fs::write can expose a partial file. Retry only JSON
                    # incompleteness under the original startup deadline.
                    marker = None
                if marker is not None:
                    _check(type(marker) is dict and set(marker) == {'pid', 'generation'}, 'invalid readiness marker')
                    _check(type(marker['pid']) is int and marker['pid'] == helper['identity']['pid'] and
                           str(uuid.UUID(marker['generation'])) == helper['identity']['generation'],
                           'readiness marker does not match the exact helper generation')
                    _check(_witness_state(witness)['held'], 'ready helper lifetime witness is not held')
                    ready_at = time.monotonic()
                    result.update(readiness=marker, ready_observed_utc=_now(),
                                  ready_observed_offset_seconds=ready_at - start,
                                  witness_verified_held_at_readiness=True)
                    next_sample = ready_at
            if helper is not None and (current >= next_sample or
                                       (ready_at is not None and current >= ready_at + WINDOW_SECONDS)):
                end_requested = ready_at is not None and current >= ready_at + WINDOW_SECONDS
                _check(len(result['samples']) < MAX_SAMPLES, 'sample count bound exceeded')
                sample = sample_helper(probe, helper, require_held=ready_at is not None)
                sample.update(offset_seconds=time.monotonic() - start,
                              phase='startup' if ready_at is None else 'ready_window')
                result['samples'].append(sample)
                next_sample = time.monotonic() + SAMPLE_SECONDS
                if end_requested:
                    sample['phase'] = 'window_end'
                    window_end = sample
                    result['actual_command_free_window_seconds'] = time.monotonic() - ready_at
                    break
            _check(ready_at is not None or current < start + STARTUP_SECONDS,
                   'helper discovery or authenticated readiness deadline')
            time.sleep(0.01)
        result['measurement_status'] = 'passed'
    except BaseException as error:
        caught = error
        result.update(measurement_status='failed', error=f'{type(error).__name__}: {error}'[:2048])
    finally:
        try:
            result['client_cleanup'] = _stop_client(process) if process is not None else {
                'not_started': True, 'reaped': True, 'audit_required': False}
        except BaseException as error:
            result['client_cleanup'] = {'reaped': False, 'audit_required': True,
                                        'error': f'{type(error).__name__}: {error}'[:2048]}
        # Always audit the helper, even if client signaling or observation failed.
        cleanup_deadline = time.monotonic() + CLEANUP_SECONDS
        try:
            while True:
                cleanup = helper_end_state(probe, helper, witness)
                if cleanup['proved'] or time.monotonic() >= cleanup_deadline or cleanup['errors'] or helper is None:
                    break
                time.sleep(0.05)
        except BaseException as error:
            cleanup = {'proved': False, 'audit_required': True,
                       'error': f'{type(error).__name__}: {error}'[:2048]}
        result['helper_cleanup'] = cleanup
        result['audit_required'] = (result['client_cleanup']['audit_required'] or not cleanup['proved'])
        if process is None:
            result['helper_cleanup'] = {'not_started': True, 'proved': True, 'audit_required': False}
            result['audit_required'] = False
        if witness is not None:
            try:
                os.close(witness['fd'])
            except OSError as error:
                result['audit_required'] = True
                result['witness_close_error'] = str(error)[:1024]
        # Counter summaries are optional evidence. Finish process cleanup and
        # witness auditing before summary work can fail or receive a first signal.
        try:
            result['counters'] = _summary(result['samples'], window_end)
        except BaseException as error:
            result['summary_error'] = f'{type(error).__name__}: {error}'[:2048]
            result['measurement_status'] = 'failed'
            result['counters'] = {'rss_kernel_peak_status': 'unavailable',
                                  'physical_footprint_peak_status': 'unavailable'}
            if caught is None:
                caught = error
        result['finished_utc'] = _now()
        result['calibration_status'] = ('passed' if result['measurement_status'] == 'passed' and
                                        result['counters']['rss_kernel_peak_status'] == 'covers_window_end' and
                                        not result['audit_required'] else 'incomplete')
        _write(evidence / 'report.json', report)
    if caught is not None:
        raise caught
    _check(not result['audit_required'], 'helper or client cleanup remains uncertain; stop native work and audit retained state')
    _disk(report, f'after_{name}_{index}')


def _lock():
    descriptor = os.open(LOCK, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        value = os.fstat(descriptor)
        _check(stat.S_ISREG(value.st_mode) and value.st_uid == os.getuid() and value.st_nlink == 1,
               'shared workload lock is not an owned regular single-link file')
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _run(input_path):
    _check(sys.platform == 'darwin' and platform.machine() == 'arm64', 'this runner is calibrated only for native arm64 macOS')
    report = {'schema': 1, 'status': 'preparing', 'started_utc': _now(), 'trials': [],
              'runner': {'path': str(Path(__file__).absolute()), 'sha256': _sha(__file__)},
              'host': {'platform': platform.platform(), 'machine': platform.machine(),
                       'python': sys.version, 'nofile': list(resource.getrlimit(resource.RLIMIT_NOFILE))},
              'bounds': {'disk_floor_bytes': FLOOR, 'startup_seconds': STARTUP_SECONDS,
                         'ready_window_seconds': WINDOW_SECONDS, 'helper_cleanup_seconds': CLEANUP_SECONDS,
                         'client_term_grace_seconds': 1, 'client_reap_seconds': 3,
                         'overall_seconds': OVERALL_SECONDS, 'sample_interval_seconds': SAMPLE_SECONDS,
                         'samples_per_trial': MAX_SAMPLES, 'log_bytes_per_stream': LOG_BYTES},
              'semantics': {
                  'window': 'Three fresh trials per real CLI and SDK worker image. Command-free means witness-client calls ready and holds that authenticated connection without submitting a NativeCommand.',
                  'readiness': 'Marker pid and generation are written only after authenticated Hold. Six full seconds follow the observer seeing this marker.',
                  'rss_peak': 'SDK MACH_TASK_BASIC_INFO.resident_size_max is a kernel lifetime RSS maximum through a successful read. It covers birth before discovery and later idle time, not an exact Ready-boundary trace.',
                  'footprint_peak': 'proc_pid_rusage V4 ri_lifetime_max_phys_footprint is a separate kernel physical-footprint ledger and never substitutes for RSS.',
                  'cleanup': 'Only a changed exact birth or ESRCH plus availability of the original stable witness proves helper exit. Unknown identity or a timeout remains uncertain.',
              },
              'limits': [
                  'This is a conservative startup plus idle bound for these exact images on this host, not a cross-platform baseline or activation of automatic defaults.',
                  'The reused observer compile receipt lacks compiler and SDK identity; its exact source, image and recorded successful compile are pinned.',
                  'Full source manifests are retained. The pinned source_scope excludes site/ and the named site guidance files from runtime equality; every other source, HEAD and index stays frozen. Ignored external packages, compiler, SDK, cached dependencies and tool inputs are not covered.',
                  'Unrelated host activity is uncontrolled. The advisory lock excludes only cooperating workloads.',
                  'No per-job ledger, provider request, shell command or package workload is part of these observations.',
              ]}
    descriptor = _lock()
    evidence = None
    original_handlers = {}
    overall_deadline = time.monotonic() + OVERALL_SECONDS
    def interrupted(number, frame):
        for signum in (signal.SIGINT, signal.SIGTERM):
            signal.signal(signum, signal.SIG_IGN)
        raise KeyboardInterrupt(f'interrupted by {signal.Signals(number).name}')
    try:
        for signum in (signal.SIGINT, signal.SIGTERM):
            original_handlers[signum] = signal.signal(signum, interrupted)
        _disk(report, 'before_input_verification')
        inputs, before = _inputs(input_path)
        report['inputs'] = inputs
        _disk(report, 'before_native_load')
        BASE.mkdir(mode=0o700, exist_ok=True)
        evidence = BASE / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ-') + uuid.uuid4().hex[:8])
        evidence.mkdir(mode=0o700)
        report['evidence'] = str(evidence)
        _write(evidence / 'report.json', report)
        probe = load_probe()
        report['status'] = 'running'
        for image in ('cli', 'worker'):
            for index in range(1, 4):
                _trial(image, index, evidence, probe, inputs, report, overall_deadline)
        record_source_observations(report, evidence, before)
        for image in inputs['binaries'].values():
            _pin(image, executable=True)
        report['source_unchanged_after_run'] = True
        _disk(report, 'after_all_trials')
        report['status'] = 'passed' if all(row['calibration_status'] == 'passed' for row in report['trials']) else 'incomplete'
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}'[:4096])
    finally:
        report['finished_utc'] = _now()
        report['audit_required'] = any(row.get('audit_required', True) for row in report['trials'])
        if evidence is not None:
            _write(evidence / 'report.json', report)
        for signum, handler in original_handlers.items():
            signal.signal(signum, handler)
        os.close(descriptor)
    print(json.dumps({'status': report['status'], 'evidence': str(evidence) if evidence else None,
                      'audit_required': report['audit_required'], 'error': report.get('error')}, indent=2))
    return 0 if report['status'] == 'passed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, help='completed input template with pinned fresh build receipts')
    parser.add_argument('--run', action='store_true', help='explicitly load the observer and run six native helper trials')
    args = parser.parse_args()
    if args.run:
        if args.inputs is None:
            parser.error('--run requires --inputs')
        return _run(args.inputs)
    if args.inputs is None:
        print(json.dumps({'status': 'prepared_only', 'input_template': str(TEMPLATE),
                          'native_code_loaded': False, 'helpers_started': False,
                          'next_step': 'Supply fresh copied release binaries and successful build receipts, then use --inputs to check them. Explicit --run is required for observation.'}, indent=2))
        return 0
    inputs, _ = _inputs(args.inputs)
    print(json.dumps({'status': 'inputs_checked', 'native_code_loaded': False,
                      'helpers_started': False, 'inputs': inputs}, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
