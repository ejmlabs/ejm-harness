#!/usr/bin/env python3
"""Run the existing release native-owner duplex and lifecycle smoke fixture."""

import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import uuid

UTILITY = Path('/private/tmp/ejm-cli-capacity-fixture-checks-20261020/run.v4.py')
UTILITY_SHA = '732c998103c2c6e8f42245f38e407a438317526c2fb75de75d98f8a3dc21ab8a'
ROOT = Path('/Users/everettmorgan/Desktop/ejm-harness')
BASE = Path('/private/tmp/ejm-capacity-duplex-smoke-20261020')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', required=True, type=Path)
    args = parser.parse_args()
    if hashlib.sha256(UTILITY.read_bytes()).hexdigest() != UTILITY_SHA:
        raise RuntimeError('Bounded command utility changed')
    spec = importlib.util.spec_from_file_location('duplex_smoke_commands', UTILITY)
    utility = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(utility)
    utility.CLI = ROOT
    scope_path = Path('/private/tmp/ejm-capacity-runtime-source-scope-20261020.py')
    if utility.sha(scope_path) != '866814f868c901e5bf64bcf688379d80db498da3992496b80046c4e33938fef0':
        raise RuntimeError('Source scope changed')
    scope_spec = importlib.util.spec_from_file_location('duplex_runtime_scope', scope_path)
    scope = importlib.util.module_from_spec(scope_spec)
    scope_spec.loader.exec_module(scope)
    directory = BASE / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8])
    directory.mkdir(mode=0o700, parents=True)
    run = utility.Run(directory)
    run.report['runner'] = utility.receipt(Path(__file__))
    run.report['utility'] = utility.receipt(UTILITY)
    run.report['source_scope'] = {'policy': scope.POLICY, 'module': utility.receipt(scope_path)}
    run.report['limits'] = [
        'Existing release native-owner smoke on macOS only, including 2 MiB duplex input/output.',
        'Fixture lifecycle assertions are functional evidence, not saturated-memory or cross-platform acceptance.',
    ]
    signal.signal(signal.SIGINT, run.interrupt)
    signal.signal(signal.SIGTERM, run.interrupt)
    print('SMOKE_DIRECTORY=' + str(directory), flush=True)
    with utility.LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            before = utility.source_state(ROOT)
            utility.write(directory / 'source-before.json', before)
            inputs = json.loads(args.inputs.read_text())
            image = inputs['binaries']['smoke']
            utility.check(utility.receipt(image['path']) == {key: image[key] for key in ('path', 'sha256', 'bytes')}, 'Smoke image changed')
            run.report['image'] = image
            output = run.command('release_duplex_smoke', [image['path']], timeout=60)
            run.report['fixture_result'] = json.loads(output.read_text().splitlines()[-1])
            after = utility.source_state(ROOT)
            utility.write(directory / 'source-after.json', after)
            run.report['excluded_source_changes'] = scope.excluded_changes(before, after)
            utility.check(scope.source_key(before) == scope.source_key(after), 'Runtime source changed during native smoke')
            utility.check(not run.report.get('remaining_work_requires_audit'), 'Command cleanup needs audit')
            run.report.update(status='passed', runtime_source_unchanged=True)
        except BaseException as error:
            run.report.update(status='failed', error=f'{type(error).__name__}: {error}')
            raise
        finally:
            run.report['finished_utc'] = utility.now()
            run.save()
    print('REPORT=' + str(directory / 'report.json'), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
