#!/usr/bin/env python3
"""Build and freeze the existing capacity measurement images with source receipts."""

from pathlib import Path
import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import subprocess
import time
import uuid


UTILITY = Path('/private/tmp/ejm-cli-capacity-fixture-checks-20261020/run.v3.py')
BASE = Path('/private/tmp/ejm-capacity-release-images-20261020')
HARNESS = Path('/Users/everettmorgan/Desktop/ejm-harness')
CLI = Path('/Users/everettmorgan/Desktop/ejm-cli')
LOCK = Path('/tmp/ejm-capacity-cargo.lock')
FLOOR = 10 * 1024**3


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    scope_path = Path('/private/tmp/ejm-capacity-runtime-source-scope-20261020.py')
    if hashlib.sha256(scope_path.read_bytes()).hexdigest() != '866814f868c901e5bf64bcf688379d80db498da3992496b80046c4e33938fef0':
        raise RuntimeError('Source scope changed')
    scope_spec = importlib.util.spec_from_file_location('capacity_runtime_source_scope', scope_path)
    scope = importlib.util.module_from_spec(scope_spec)
    scope_spec.loader.exec_module(scope)
    if not args.run:
        print('Preparation only. --run builds smoke, worker, benchmark and CLI release images.')
        return 0
    interrupted = None

    def interrupt(signum, _frame):
        nonlocal interrupted
        interrupted = signum

    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    for name in ('waitid', 'WNOWAIT', 'CLD_EXITED', 'P_PID'):
        if not hasattr(os, name):
            raise RuntimeError('Build cleanup requires os.' + name)
    spec = importlib.util.spec_from_file_location('capacity_source_receipts', UTILITY)
    utility = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(utility)
    tag = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    directory = BASE / tag
    directory.mkdir(mode=0o700, parents=True)
    print('BUILD_DIRECTORY=' + str(directory), flush=True)
    report = {'schema': 1, 'status': 'running', 'started_utc': utility.now(),
              'runner': utility.receipt(Path(__file__)), 'utility': utility.receipt(UTILITY),
              'images': {}, 'limits': [
                  'Full Git-listed manifests are retained; the pinned scope excludes site/ and named site guidance from equality. All other source, HEAD and index are frozen. Ignored caches, external dependencies and compiler bytes are not.',
                  'Host-native release builds reuse existing Cargo outputs; these builds do not establish runtime acceptance.',
              ]}
    report['source_scope'] = {'policy': scope.POLICY, 'module': utility.receipt(scope_path)}
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(('EJM_', 'OPENAI_', 'ANTHROPIC_', 'CLAUDE_')) and key != 'CLAUDECODE'}
    environment.update(CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
                       PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
    for key in ('CARGO_BUILD_TARGET', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'):
        utility.check(not environment.get(key), 'Unsupported ambient build override: ' + key)
    report['rustc'] = subprocess.check_output(['rustc', '-vV'], text=True, timeout=15)
    utility.check('host: aarch64-apple-darwin' in report['rustc'], 'Native arm64 macOS compiler required')
    report['cargo'] = subprocess.check_output(['cargo', '--version'], text=True, timeout=15).strip()
    images = [('smoke', HARNESS, 'ejm-harness-exec', '--example', 'native_owner_smoke'),
              ('worker', HARNESS, 'ejm-harness-worker', '--bin', 'ejm-harness-worker'),
              ('bench', HARNESS, 'ejm-harness-bench', '--bin', 'ejm-harness-bench'),
              ('cli', CLI, 'ejm-cli', '--bin', 'ejm-cli')]
    with LOCK.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            for name, root, package, selector, target in images:
                utility.check(interrupted is None, 'Build interrupted before ' + name)
                roots = [HARNESS, CLI] if name == 'cli' else [HARNESS]
                utility.check(shutil.disk_usage(directory).free >= FLOOR, 'Disk below 10 GiB before ' + name)
                before = {str(owner): utility.source_state(owner) for owner in roots}
                sources = []
                for owner in roots:
                    path = directory / (name + '-' + owner.name + '-before.json')
                    utility.write(path, before[str(owner)])
                    sources.append({'root': str(owner), 'before': utility.receipt(path)})
                command = ['cargo', 'build', '--release', '--locked', '--offline', '--jobs', '2',
                           '--target-dir', str(root / 'target'), '-p', package,
                           selector, target, '--message-format=json']
                out = directory / (name + '.stdout.jsonl')
                err = directory / (name + '.stderr')
                phase = {'command': command, 'cwd': str(root), 'profile': 'release',
                         'target': 'aarch64-apple-darwin', 'started_utc': utility.now()}
                record = {'schema': 1, 'build': phase, 'sources': sources,
                          'rustc': report['rustc'], 'cargo': report['cargo'],
                          'environment_overrides': {'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
                                                    'CARGO_NET_OFFLINE': 'true'}}
                report['images'][name] = record
                utility.write(directory / 'report.json', report)
                process = None
                started = time.monotonic()
                print('START ' + name, flush=True)
                try:
                    with out.open('xb') as stdout, err.open('xb') as stderr:
                        process = subprocess.Popen(command, cwd=root, env=environment, stdin=subprocess.DEVNULL,
                                                   stdout=stdout, stderr=stderr, start_new_session=True)
                        while (exit_state := os.waitid(os.P_PID, process.pid,
                                                       os.WEXITED | os.WNOHANG | os.WNOWAIT)) is None:
                            utility.check(interrupted is None, 'Build interrupted during ' + name)
                            utility.check(time.monotonic() - started < 900, name + ' build deadline exceeded')
                            utility.check(shutil.disk_usage(directory).free >= FLOOR, 'Disk below 10 GiB during ' + name)
                            utility.check(out.stat().st_size + err.stat().st_size < 64 * 1024**2, 'Build logs exceed 64 MiB')
                            time.sleep(0.25)
                        utility.check(exit_state.si_code == os.CLD_EXITED and exit_state.si_status == 0,
                                      name + ' build failed, see ' + str(err))
                        utility.check(interrupted is None, 'Build interrupted at completion of ' + name)
                        phase['returncode'] = process.wait()
                finally:
                    if process is not None and process.returncode is None:
                        utility.stop_group(process, phase)
                    phase.update(finished_utc=utility.now(), elapsed_seconds=time.monotonic() - started,
                                 stdout=utility.receipt(out), stderr=utility.receipt(err))
                utility.check(out.stat().st_size + err.stat().st_size <= 64 * 1024**2,
                              'Final build logs exceed 64 MiB')
                utility.check(interrupted is None, 'Build interrupted after ' + name)
                for entry in sources:
                    owner = Path(entry['root'])
                    after = utility.source_state(owner)
                    path = directory / (name + '-' + owner.name + '-after.json')
                    utility.write(path, after)
                    entry['after'] = utility.receipt(path)
                    entry['excluded_changes'] = scope.excluded_changes(before[str(owner)], after)
                    entry['runtime_source_unchanged'] = scope.source_key(before[str(owner)]) == scope.source_key(after)
                    utility.check(entry['runtime_source_unchanged'], 'Runtime source changed during ' + name + ' build: ' + str(owner))
                artifacts = [value['executable'] for line in out.read_text().splitlines()
                             if (value := json.loads(line)).get('reason') == 'compiler-artifact'
                             and value.get('executable') and value.get('target', {}).get('name') == target]
                utility.check(len(set(artifacts)) == 1, 'Expected one executable for ' + name)
                original = Path(artifacts[0])
                frozen = directory / (name + '.release')
                utility.check(shutil.disk_usage(directory).free >= FLOOR + original.stat().st_size,
                              'Disk cannot retain ' + name + ' above floor')
                shutil.copy2(original, frozen)
                frozen.chmod(0o555)
                phase['output'] = utility.receipt(original)
                record['copied_binary'] = utility.receipt(frozen)
                utility.check(phase['output']['sha256'] == record['copied_binary']['sha256'], 'Frozen binary mismatch')
                utility.write(directory / (name + '-build.json'), record)
                utility.write(directory / 'report.json', report)
                print('END ' + name + ': ' + record['copied_binary']['sha256'], flush=True)
            inputs = {'schema': 1, 'binaries': {
                name: report['images'][name]['copied_binary'] | {
                    'build_receipt': utility.receipt(directory / (name + '-build.json'))}
                for name in ('smoke', 'cli', 'worker')}}
            utility.write(directory / 'calibration-inputs.json', inputs)
            report['status'] = 'passed'
        except BaseException as error:
            report.update(status='failed', error=f'{type(error).__name__}: {error}')
            raise
        finally:
            report['interrupt_signal'] = signal.Signals(interrupted).name if interrupted is not None else None
            report['finished_utc'] = utility.now()
            utility.write(directory / 'report.json', report)
    print(json.dumps({'status': report['status'], 'report': str(directory / 'report.json'),
                      'inputs': str(directory / 'calibration-inputs.json')}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
