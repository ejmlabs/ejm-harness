#!/usr/bin/env python3
"""Prepare the eight-helper pool with a commitment barrier before the ninth."""

from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import shutil
import signal
import stat
import subprocess
import sys
import time
import types
import uuid


BASE = Path('/private/tmp/ejm-capacity-pool-barrier-20261020')
PARENT_ADAPTER = Path('/private/tmp/ejm-capacity-current-image-adapters-20261020/adapt-current.py')
PARENT_ADAPTER_SHA = '2eace295ea09a79f182f998e13f76eb1735e570e0b328379d1c017b4ca33f1d9'
POOL_UTILITY = Path('/private/tmp/ejm-capacity-pool-barrier-20261020/pool-utility.v3.py')
POOL_UTILITY_SHA = '19349f28d68a95a3c12748f8d2521d7c2a277dbc90f8b7c807438908b513e9ac'
HARNESS = Path('/Users/everettmorgan/Desktop/ejm-harness')
UTILITY = Path('/private/tmp/ejm-cli-capacity-fixture-checks-20261020/run.v4.py')
UTILITY_SHA = '732c998103c2c6e8f42245f38e407a438317526c2fb75de75d98f8a3dc21ab8a'
CALIBRATION = Path('/private/tmp/ejm-capacity-real-helper-calibration-20261020.v2.py')
CALIBRATION_SHA = '8e69892479e1967f2c5d9662769463c167964a16142ab60f080ad12e9bf74a5a'
RELEASE_BUILDER = Path('/private/tmp/ejm-capacity-release-images-20261020.v2.py')
RELEASE_BUILDER_SHA = 'd08b686185b9790ddaad1cf2be3708aaab17ca021b89b9df7b517b3f55788735'
FLOOR = 10 * 1024**3
BUILD_COMMAND = ['cargo', 'test', '--release', '--locked', '--offline', '--jobs', '2',
                 '--target-dir', str(HARNESS / 'target'), '-p', 'ejm-harness-exec',
                 '--lib', '--no-run', '--message-format=json']


def check(value, message):
    if not value:
        raise RuntimeError(message)


def receipt(path):
    path = Path(path)
    value = path.lstat()
    check(path.is_absolute() and stat.S_ISREG(value.st_mode) and value.st_uid == os.getuid()
          and value.st_nlink == 1, 'expected an owned regular single-link input: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024**2), b''):
            digest.update(data)
    return {'path': str(path), 'sha256': digest.hexdigest(), 'bytes': value.st_size}


def load(path, expected, name):
    pin = receipt(path)
    check(pin['sha256'] == expected and pin['bytes'] <= 128 * 1024, 'pinned adapter changed: ' + str(path))
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module


def directory(phase):
    metadata = BASE.lstat()
    check(stat.S_ISDIR(metadata.st_mode) and metadata.st_uid == os.getuid()
          and metadata.st_mode & 0o077 == 0, 'adapter evidence base must be private')
    name = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ-') + uuid.uuid4().hex[:8]
    path = BASE / (phase + '-' + name)
    path.mkdir(mode=0o700)
    return path


def verify_inputs(a, inputs):
    for image in inputs['binaries'].values():
        a._pin(image, executable=True)
        a._pin(image['build_receipt'])
    a._pin(inputs['input'])
    for pin in inputs['observer'].values():
        a._pin(pin)
    a._pin({'path': str(CALIBRATION), 'sha256': CALIBRATION_SHA})
    a._pin({'path': str(UTILITY), 'sha256': UTILITY_SHA})
    a._pin({'path': str(RELEASE_BUILDER), 'sha256': RELEASE_BUILDER_SHA})
    a._pin({'path': str(a.SOURCE_SCOPE_PATH), 'sha256': a.SOURCE_SCOPE_SHA})
    a._pin({'path': str(PARENT_ADAPTER), 'sha256': PARENT_ADAPTER_SHA})
    a._pin({'path': str(POOL_UTILITY), 'sha256': POOL_UTILITY_SHA})


def final_audits(a, report, evidence, inputs, states, interrupted):
    errors = []
    audits = [('disk', lambda: a._disk(report, 'after_selected_case_cleanup'))]
    audits.extend(('source:' + root, lambda root=root, state=state:
                   a.record_source_observations(report, evidence, {root: state}))
                  for root, state in states.items())
    audits.append(('input_pins', lambda: verify_inputs(a, inputs)))
    audits.append(('interrupt', lambda: check(interrupted[0] is None, 'interrupted during final audits')))
    for name, audit in audits:
        try:
            audit()
        except BaseException as error:
            errors.append({'phase': name, 'error': f'{type(error).__name__}: {error}'[:4096]})
    if errors:
        report.update(status='failed', final_audit_errors=errors)
        raise RuntimeError('final audits failed; retain evidence and stop')


def bench_input(a, path, inputs, states):
    """Read the fourth existing release-builder image, omitted by its calibration projection."""
    root = path.parent
    build_path, report_path = root / 'bench-build.json', root / 'report.json'
    build_pin, report_pin = receipt(build_path), receipt(report_path)
    build, report = a._json(build_path), a._json(report_path)
    check(report.get('status') == 'passed' and report.get('runner', {}).get('sha256') == RELEASE_BUILDER_SHA,
          'a successful pinned fresh release-builder report is required')
    check(report['images']['bench'] == build and all(report['images'][name]['copied_binary'] ==
          {key: inputs['binaries'][name][key] for key in ('path', 'sha256', 'bytes')}
          for name in ('smoke', 'cli', 'worker')), 'bench and calibration images must share the release build')
    binary = a._pin(build['copied_binary'], executable=True)
    phase = build['build']
    command = phase['command']
    check(build.get('schema') == 1 and phase['returncode'] == 0 and phase['profile'] == 'release'
          and phase['target'] == 'aarch64-apple-darwin' and phase['started_utc'] and phase['finished_utc']
          and command[:2] == ['cargo', 'build'] and all(flag in command for flag in
              ('--release', '--locked', '--offline', 'ejm-harness-bench')),
          'bench needs its successful native offline release build receipt')
    check(phase['output']['sha256'] == binary['sha256'] and phase['output']['bytes'] == binary['bytes']
          and Path(phase['output']['path']).is_absolute(), 'bench output differs from frozen copy')
    for name in ('stdout', 'stderr'):
        a._pin(phase[name])
    check(len(build['sources']) == 1 and build['sources'][0]['root'] == str(HARNESS),
          'bench needs exactly the harness source root')
    source = build['sources'][0]
    before, after = [a._json(a._pin(source[name])['path']) for name in ('before', 'after')]
    check(before['root'] == before['top_level'] == str(HARNESS) and before['files']
          and a._source_key(before) == a._source_key(after) == a._source_key(states[str(HARNESS)]),
          'bench source changed or differs from the fresh calibration images')
    return binary | {'build_receipt': build_pin, 'release_report': report_pin, 'build': phase,
                     'sources': build['sources']}


def build_occupancy(a, inputs_path, inputs, states, evidence, interrupted):
    utility = load(UTILITY, UTILITY_SHA, '_ejm_current_occupancy_build')
    # Run.command resolves its working directory and target cache through this module constant.
    utility.CLI = HARNESS
    run = utility.Run(evidence)
    run.report.update(cwd=str(HARNESS), runner=receipt(Path(__file__)), utility=receipt(UTILITY),
                      inputs=inputs, phase='occupancy-build', limits=[
        'Compile only the existing ordinary release executor libtest; no test is executed.',
        'The pinned source scope excludes site paths and named site guidance only.',
        'No native-test-seams, install, download, source edit, deletion, or default activation.',
    ])
    run.env = {key: value for key, value in os.environ.items()
               if not key.startswith(('EJM_', 'OPENAI_', 'ANTHROPIC_', 'CLAUDE_')) and key != 'CLAUDECODE'}
    for key in ('CARGO_BUILD_TARGET', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
                'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'):
        check(not run.env.get(key), 'unsupported ambient build override: ' + key)
    run.env.update(CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
                   CARGO_TARGET_DIR=str(HARNESS / 'target'), PYTHONDONTWRITEBYTECODE='1',
                   GIT_OPTIONAL_LOCKS='0')
    run.report['environment'] = {key: run.env[key] for key in
        ('CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_NET_OFFLINE', 'CARGO_TARGET_DIR',
         'PYTHONDONTWRITEBYTECODE', 'GIT_OPTIONAL_LOCKS')}
    original_guard = run.guard
    def guard(phase):
        if interrupted[0] is not None:
            run.report['interrupt_signal'] = signal.Signals(interrupted[0]).name
        original_guard(phase)
    run.guard = guard
    source_before = states[str(HARNESS)]
    a._write(evidence / 'source-before.json', source_before)
    run.save()
    try:
        rustc_path = run.command('rustc', ['rustc', '-vV'], timeout=15)
        rustc = rustc_path.read_text()
        check('host: aarch64-apple-darwin' in rustc, 'native arm64 macOS compiler required')
        cargo = run.command('cargo_version', ['cargo', '--version'], timeout=15).read_text().strip()
        output = run.command('release_occupancy_libtest', BUILD_COMMAND, timeout=900)
        phase = dict(run.report['phases'][-1], profile='release', target='aarch64-apple-darwin')
        artifacts = [value for line in output.read_text().splitlines()
                     if (value := json.loads(line)).get('reason') == 'compiler-artifact'
                     and value.get('executable') and value.get('target', {}).get('name') == 'ejm_harness_exec'
                     and value.get('profile', {}).get('test') is True]
        check(len(artifacts) == 1, 'expected exactly one compiler-selected executor libtest')
        artifact = artifacts[0]
        check('native-test-seams' not in artifact['features'] and
              artifact['profile'].get('debug_assertions') is False,
              'ordinary release libtest without native-test-seams is required')
        original = Path(artifact['executable'])
        run.guard('before_freeze')
        check(shutil.disk_usage(evidence).free >= FLOOR + original.stat().st_size,
              'cannot retain libtest above the 10 GiB floor')
        frozen = evidence / 'occupancy.release'
        shutil.copy2(original, frozen)
        frozen.chmod(0o555)
        phase['output'], copied = receipt(original), receipt(frozen)
        phase['elapsed_seconds'] = phase['duration_seconds']
        check(phase['output']['sha256'] == copied['sha256'], 'frozen libtest differs from compiler output')
        source_after = a._source_state(HARNESS)
        a._write(evidence / 'source-after.json', source_after)
        check(a._source_key(source_before) == a._source_key(source_after), 'runtime source changed during build')
        build = {'schema': 1, 'build': phase, 'sources': [{'root': str(HARNESS),
                 'before': receipt(evidence / 'source-before.json'), 'after': receipt(evidence / 'source-after.json')}],
                 'copied_binary': copied, 'rustc': rustc, 'cargo': cargo, 'utility': receipt(UTILITY),
                 'executor_features': artifact['features'], 'executor_profile': artifact['profile']}
        a._write(evidence / 'occupancy-build.json', build)
        value = a._json(inputs_path)
        value['binaries']['occupancy_libtest'] = copied | {'build_receipt': receipt(evidence / 'occupancy-build.json')}
        a._write(evidence / 'occupancy-inputs.json', value)
        run.guard('after_freeze')
        check(not run.report.get('remaining_work_requires_audit') and not run.unreaped,
              'command cleanup is uncertain; stop and audit')
        run.report.update(status='passed', occupancy_inputs=receipt(evidence / 'occupancy-inputs.json'))
    except BaseException as error:
        run.report.update(status='failed', error=f'{type(error).__name__}: {error}'[:4096])
        raise
    finally:
        try:
            final_audits(a, run.report, evidence, inputs, states, interrupted)
        except BaseException as error:
            run.report.update(status='failed', final_audit_error=f'{type(error).__name__}: {error}'[:4096])
            raise
        finally:
            run.report['finished_utc'] = a._now()
            run.report['interrupt_signal'] = interrupted[0]
            if interrupted[0] is not None:
                run.report['status'] = 'failed'
            run.save()
    return run.report


def pool_utility(a):
    """Share the pinned observer ABI without loading its native library."""
    utility = load(POOL_UTILITY, POOL_UTILITY_SHA, '_ejm_pool_commitment_barrier_v3')
    original = a._util()
    check(utility.FIELDS == original.FIELDS
          and utility.Observation._fields_ == original.Observation._fields_
          and utility.ctypes.sizeof(utility.Observation) == original.ctypes.sizeof(original.Observation) == 128,
          'pool clone changed the pinned observer ABI')
    utility.Observation = original.Observation
    original.ctypes.POINTER(original.Observation).from_param(
        original.ctypes.byref(utility.Observation()))
    return utility


def pool(a, inputs_path, inputs, states, evidence, interrupted):
    utility = pool_utility(a)
    bench = bench_input(a, inputs_path, inputs, states)
    utility.BENCH, utility.BENCH_SHA, utility.OUTPUT = Path(bench['path']), bench['sha256'], BASE
    report = {'schema': 1, 'status': 'running', 'started_utc': a._now(), 'phase': 'pool',
              'runner': receipt(Path(__file__)), 'parent_runner': receipt(PARENT_ADAPTER),
              'utility': receipt(POOL_UTILITY), 'utility_parent': receipt(a.UTIL_PATH), 'inputs': inputs,
              'binaries': {'bench': bench}, 'disk': [], 'disk_floor_bytes': FLOOR,
              'observer': inputs['observer'], 'bounds': {'overall_work_seconds': 300,
                  'log_bytes_per_stream': 1024**2, 'sample_scans': 20, 'guard_interval_seconds': 1},
              'limits': ['The pool_trial clone moves ninth startup after the first-eight commitment barrier; all original workloads, scans and cleanup remain.',
                  'This does not measure eight saturated CLI/worker helpers or descendant peaks.',
                  'The retained observer compile receipt lacks full compiler and SDK identity.',
                  'Original cleanup covers discovered helpers only; one client-cleanup error can skip later cleanup. Any failed case requires an audit.',
                  'No Linux, Windows, automatic-default, publication, or release acceptance claim.']}
    report['semantics'] = {
        'rss': 'Helper kernel lifetime RSS maxima and sequential aggregate scan sums are distinct measures.',
        'identity': 'Exact kernel birth, expected parent, endpoint generation, and retained owner.lock witness.',
        'cleanup': 'Every discovered helper must end and release its witness. A timeout does not prove exit.'}
    a._write(evidence / 'pool-inputs.json', {'schema': 1, 'calibration': inputs['input'], 'bench': bench})
    report['pool_input'] = receipt(evidence / 'pool-inputs.json')
    started, next_guard, cleaning = time.monotonic(), [0.0], [False]
    original_check, original_start, original_terminate = utility.check, utility.start, utility.terminate_client
    original_time = utility.time

    def guard(force=False):
        if cleaning[0]:
            return
        original_check(interrupted[0] is None, 'pool interrupted; finish original cleanup before stopping')
        current = time.monotonic()
        original_check(current - started < 300, 'pool overall work deadline exceeded')
        if force or current >= next_guard[0]:
            next_guard[0] = current + 1
            a._disk(report, 'pool_wrapper_guard')
            for path in evidence.glob('pool-client-*/*'):
                if path.name in ('stdout', 'stderr'):
                    original_check(path.stat().st_size <= 1024**2, 'pool log exceeds 1 MiB: ' + str(path))

    def guarded_check(value, message):
        # This pinned check immediately precedes each full participant stdout read.
        guard(force=message == 'pool benchmark participant failed')
        original_check(value, message)

    def guarded_start(*args, **kwargs):
        guard(force=True)
        item = original_start(*args, **kwargs)
        process = item['process']
        original_wait = process.wait
        def guarded_wait(timeout=None):
            if cleaning[0]:
                return original_wait(timeout=timeout)
            deadline = None if timeout is None else time.monotonic() + timeout
            while True:
                guard()
                remaining = None if deadline is None else max(0, deadline - time.monotonic())
                try:
                    result = original_wait(timeout=0.25 if remaining is None else min(0.25, remaining))
                    guard(force=True)  # Check log sizes before pool_trial reads complete output.
                    return result
                except subprocess.TimeoutExpired:
                    if deadline is not None and time.monotonic() >= deadline:
                        raise subprocess.TimeoutExpired(process.args, timeout) from None
        process.wait = guarded_wait
        return item

    def guarded_sleep(seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            guard()
            time.sleep(min(0.25, max(0, end - time.monotonic())))

    def cleanup(item):
        cleaning[0] = True
        return original_terminate(item)

    utility.check, utility.start, utility.terminate_client = guarded_check, guarded_start, cleanup
    utility.time = types.SimpleNamespace(monotonic=time.monotonic, sleep=guarded_sleep)
    try:
        guard(force=True)
        probe = a.load_probe()
        a._write(evidence / 'report.json', report)
        utility.pool_trial(evidence, probe, report)
        shared = report['shared_pool']
        check(shared.get('status') == 'passed' and len(shared.get('samples', [])) == 20
              and len(shared.get('completed_participants', [])) == 8,
              'pool case did not complete its original workload')
        check(shared.get('discovered_helper_cleanup_complete') and len(shared['helper_cleanup']) == 8
              and all(row.get('identity_ended') and row.get('witness_available') for row in shared['helper_cleanup'])
              and all(row.get('reaped') for row in shared['client_cleanup'])
              and shared.get('ninth_cleanup', {}).get('reaped'), 'pool cleanup is uncertain; stop and audit')
        check(not interrupted[0], 'pool interrupted; original cleanup has completed')
        a._pin(bench, executable=True)
        a._pin(bench['build_receipt'])
        a._pin(bench['release_report'])
        report.update(status='passed', audit_required=False)
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}'[:4096],
                      audit_required=True)
        raise
    finally:
        utility.check, utility.start, utility.terminate_client = original_check, original_start, original_terminate
        utility.time = original_time
        try:
            final_audits(a, report, evidence, inputs, states, interrupted)
        except BaseException as error:
            report.update(status='failed', final_audit_error=f'{type(error).__name__}: {error}'[:4096])
            raise
        finally:
            report['finished_utc'] = a._now()
            report['interrupt_signal'] = interrupted[0]
            if interrupted[0] is not None:
                report['status'] = 'failed'
            a._write(evidence / 'report.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('pool',), required=True)
    parser.add_argument('--inputs', type=Path, help='fresh release-builder calibration-inputs.json')
    parser.add_argument('--run', action='store_true', help='start the selected existing case after workload release')
    args = parser.parse_args()
    a = load(CALIBRATION, CALIBRATION_SHA, '_ejm_current_calibration')
    load(UTILITY, UTILITY_SHA, '_ejm_current_utility_preflight')
    check(receipt(RELEASE_BUILDER)['sha256'] == RELEASE_BUILDER_SHA, 'release builder changed')
    check(receipt(PARENT_ADAPTER)['sha256'] == PARENT_ADAPTER_SHA, 'parent adapter changed')
    check(receipt(POOL_UTILITY)['sha256'] == POOL_UTILITY_SHA, 'pool utility changed')
    if not args.run:
        pool_utility(a)
        print(json.dumps({'status': 'prepared_only', 'phase': args.phase, 'native_code_loaded': False,
                          'observer_pointer_from_param': 'passed',
                          'workloads_started': False, 'runner': receipt(Path(__file__)),
                          'next_step': 'Use explicit fresh --inputs and --run only after workload release.'}, indent=2))
        return 0
    if args.inputs is None:
        parser.error('--run requires --inputs')
    check(sys.platform == 'darwin' and platform.machine() == 'arm64', 'native arm64 macOS required')
    for name in ('waitid', 'WNOWAIT', 'CLD_EXITED', 'P_PID', 'WEXITED', 'WNOHANG'):
        check(hasattr(os, name), 'unreaped child cleanup requires os.' + name)
    descriptor = a._lock()
    interrupted, handlers, evidence = [None], {}, None
    def interrupt(number, _frame):
        interrupted[0] = number
    try:
        for number in (signal.SIGINT, signal.SIGTERM):
            handlers[number] = signal.signal(number, interrupt)
        evidence = directory(args.phase)
        print('EVIDENCE_DIRECTORY=' + str(evidence), flush=True)
        inputs, states = a._inputs(args.inputs.absolute())
        a._disk({'disk': []}, 'before_selected_case')
        report = (build_occupancy if args.phase == 'occupancy-build' else pool)(
            a, args.inputs.absolute(), inputs, states, evidence, interrupted)
        print(json.dumps({'status': report['status'], 'report': str(evidence / 'report.json'),
                          'occupancy_inputs': report.get('occupancy_inputs')}, indent=2))
        return 0 if report['status'] == 'passed' else 1
    finally:
        for number, previous in handlers.items():
            signal.signal(number, previous)
        os.close(descriptor)


if __name__ == '__main__':
    raise SystemExit(main())
