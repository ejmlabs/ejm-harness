# Ordered eight-helper pool preparation

Prepared only. Root owns review and execution. No workload, native observer load,
lock acquisition, deletion, signal, or repository source change occurred here.

## Use

The runner is `adapt-pool.v3.py`. `adapt-pool.v2.py` is retained for review and
must not run: it preceded the ctypes identity correction. The v3 runner validates
the clone field layout, shares the original pinned Observation class, then checks
POINTER.from_param with a real byref instance. The dry check loads no native
observer library.

After source freeze and root workload release:

```sh
python3 -B /private/tmp/ejm-capacity-pool-barrier-20261020/adapt-pool.v3.py \
  --phase pool \
  --inputs /private/tmp/ejm-capacity-release-images-20261020/20261021T030431Z-87224631/calibration-inputs.json \
  --run
```

The original release inputs and original runner lineage remain pinned. The new
pool utility changes only ninth startup and adds the observable commitment
barrier. Eight first clients keep 100 agents, eight rounds, one model request,
one job, fixed capacity, descriptor limits and 800 commands each. Ninth keeps
one agent and one round, with zero park after the barrier.

All original 25-second helper discovery, eight committed generations, per-ancestor
32 MiB plus one process commitments, 20 scans over five seconds, ninth refusal,
12-second ninth wait, 180-second participant completion and cleanup checks remain.
The wrapper retains its 300-second work bound, sliced waits, 1 MiB log guards,
10 GiB disk floor, shared lock, input pins, source freeze checks and failure audit
requirement. No observer cap or budget changed.

The first eight must remain alive through sampling. This runner checks that
condition and fails if a straggler consumes the window. It does not pause work,
change command counts, or claim the barrier can guarantee host timing.

## Evidence and limits

`diagnosis.json` joins retained owner PIDs and native domains to helper rows.
Ninth PID 14717 owns the pending eighth row. Client 2 PID 14653 has no helper row
and reports pool full. This proves the setup race. It does not prove which
scheduler or admission delay allowed ninth to overtake client 2.

`pool-utility.diff` and `adapter-v3.diff` show the new sources against their
pinned parents. `adapter-v2-to-v3.diff` isolates the observer ABI fix.
`preparation-checks.json` records the inherited source checks; `prepare-v3.json`
records the no-work dry check with pointer identity validation.

The failed report, its passing cleanup audit, old sources and receipts are
preserved. Cleanup retains the original limitation: it covers discovered helpers
and a cleanup error can stop later cleanup. Every failed case requires audit.
This is scratch measurement tooling and has no public docs or runtime contract
change. Root owns canonical evidence and any later documentation update.
