#!/usr/bin/env python3
"""Assemble an explicit text-only evidence selection without running its sources."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import types


BASE = Path('/private/tmp/ejm-helper-current-memory-evidence-20261021')
PRIOR = Path('/private/tmp/ejm-helper-memory-evidence-20261020')
STEM = 'native-helper-current-image-memory.macos-arm64'
RELEASE = Path('/private/tmp/ejm-capacity-release-images-20261020/20261021T030431Z-87224631')
STARTUP = Path('/private/tmp/ejm-capacity-real-helper-calibration-20261020/20261021T030740Z-0c0e3b9e')
SATURATION = Path('/private/tmp/ejm-native-occupancy-observer-20261020/20261021T030842Z-7cf876ec')
OCCUPANCY = Path('/private/tmp/ejm-capacity-current-image-adapters-20261020/occupancy-build-20261021T030727Z-dc04e234')
FAILED_POOL = Path('/private/tmp/ejm-capacity-current-image-adapters-20261020/pool-20261021T030944Z-1a921553')
AUDIT = Path('/private/tmp/ejm-capacity-pool-failure-audit-20261021.json')
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 24 * 1024 * 1024
MIB = 1024 * 1024
EXCLUSIONS = [
    'Executable images, dynamic libraries and other binary content.',
    'Native/session state, databases and sidecars, lock files, ready markers and endpoint publications.',
    'Credential files, private environment inputs and provider response content.',
    'Runtime and fixture Rust sources. Full source manifests identify their measured bytes.',
    'Unlisted files and corrected pool attempts without an explicit report argument.',
]


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def write_new(path, data):
    require(path.parent == BASE, 'Writes must stay directly inside the new evidence directory')
    with path.open('xb') as stream:
        stream.write(data)


def safe_member(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts


def eligible(path):
    if not path.is_absolute() or not str(path).startswith('/private/tmp/'):
        return False
    if any(part in {'state', 'shared-pool', 'native', '__pycache__'} for part in path.parts):
        return False
    if path.name in {'ready.json', 'endpoint.json', 'owner.lock', 'startup.lock'}:
        return False
    return path.suffix in {'.py', '.c', '.json', '.jsonl', '.stdout', '.stderr'} or path.name in {'stdout', 'stderr'}


def bytes_for(path):
    require(eligible(path), 'Non-allowlisted content class: ' + str(path))
    metadata = path.lstat()
    require(stat.S_ISREG(metadata.st_mode), 'Nonregular source: ' + str(path))
    require(metadata.st_size <= MAX_FILE_BYTES, 'Source exceeds per-file bound: ' + str(path))
    data = path.read_bytes()
    require(b'\0' not in data, 'Binary content selected: ' + str(path))
    data.decode('utf-8')
    return data


def member_for(path):
    if path.parent == BASE:
        return 'assembly/' + path.name
    return 'evidence/' + str(path.relative_to('/private/tmp'))


def add_file(files, path, role, expected=None, pointer=None):
    path = Path(path)
    data = bytes_for(path)
    sha = digest(data)
    if expected:
        require(expected['sha256'] == sha, 'Recorded source hash changed: ' + str(path))
        require('bytes' not in expected or expected['bytes'] == len(data), 'Recorded source size changed: ' + str(path))
    key = str(path)
    if key not in files:
        files[key] = {'member': member_for(path), 'original_path': key, 'sha256': sha,
                      'bytes': len(data), 'roles': [], 'references': []}
    require(files[key]['sha256'] == sha, 'Source changed during selection: ' + key)
    if role not in files[key]['roles']:
        files[key]['roles'].append(role)
    if pointer and pointer not in files[key]['references']:
        files[key]['references'].append(pointer)


def walk_references(value, files, source, pointer=''):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            path = Path(value['path'])
            if eligible(path):
                add_file(files, path, 'referenced_text_receipt_or_source', value, source + pointer)
        for key, item in value.items():
            child = pointer + '/' + str(key)
            if key in {'stdout', 'stderr'} and isinstance(item, str) and eligible(Path(item)):
                add_file(files, item, 'referenced_bounded_log', pointer=source + child)
            walk_references(item, files, source, child)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            walk_references(item, files, source, pointer + '/' + str(index))


def add_run(files, root, label, pool=False):
    for path in sorted(root.iterdir()):
        if path.is_file() and eligible(path):
            add_file(files, path, 'run_text:' + label)
    if pool:
        children = [root / ('pool-client-' + str(i)) for i in range(1, 10)]
    else:
        children = [root / (image + '-' + str(i)) for image in ('cli', 'worker') for i in range(1, 4)]
    for child in children:
        for name in ('stdout', 'stderr'):
            path = child / name
            if path.is_file():
                add_file(files, path, 'bounded_client_log:' + label)


def close_references(files):
    reviewed = set()
    while pending := [name for name in files if name not in reviewed]:
        for name in pending:
            reviewed.add(name)
            if Path(name).suffix == '.json':
                value = json.loads(bytes_for(Path(name)))
                walk_references(value, files, name)
    names = [row['member'] for row in files.values()]
    require(len(names) == len(set(names)) and all(safe_member(name) for name in names), 'Unsafe or duplicate members')
    require(sum(row['bytes'] for row in files.values()) <= MAX_TOTAL_BYTES, 'Selection exceeds total byte bound')


def privacy_scan(files):
    patterns = {
        'private_key': re.compile(r'-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----'),
        'provider_key': re.compile(r'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{24,}'),
        'github_token': re.compile(r'\bgh[pousr]_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{24,}'),
        'aws_access_key': re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
        'url_userinfo': re.compile(r'https?://[^\s/:@]+:[^\s/@]+@'),
        'bearer_value': re.compile(r'(?i)\bBearer [A-Za-z0-9._~+/-]{24,}'),
    }
    sensitive = {'api_key', 'apikey', 'access_token', 'refresh_token', 'authorization', 'password',
                 'secret', 'capability', 'cookie', 'set-cookie', 'credentials', 'endpoint', 'address'}
    findings, strings = [], []

    def walk(value, member, pointer=''):
        if isinstance(value, dict):
            for key, item in value.items():
                child = pointer + '/' + str(key)
                if str(key).lower() in sensitive and isinstance(item, str) and item:
                    strings.append({'member': member, 'pointer': child, 'value_sha256': digest(item.encode()),
                                    'string_bytes': len(item.encode())})
                walk(item, member, child)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, member, pointer + '/' + str(index))

    for row in files.values():
        data = bytes_for(Path(row['original_path']))
        require(digest(data) == row['sha256'], 'Selected source changed before privacy scan')
        text = data.decode()
        for label, pattern in patterns.items():
            for match in pattern.finditer(text):
                findings.append({'member': row['member'], 'pattern': label,
                                 'line': text.count('\n', 0, match.start()) + 1,
                                 'match_sha256': digest(match.group().encode())})
        if Path(row['original_path']).suffix == '.json':
            walk(json.loads(data), row['member'])
    return {'schema': 1, 'scanned_files': len(files), 'scanned_bytes': sum(r['bytes'] for r in files.values()),
            'pattern_findings': findings, 'nonempty_sensitive_json_strings': strings,
            'limit': 'Pattern and structural review cannot prove the absence of every possible secret.'}


def load_reused():
    source = BASE / 'reused-assemble.py'
    data = source.read_bytes()
    module = types.ModuleType('retained_embedding_assembly')
    exec(compile(data, str(source), 'exec'), module.__dict__)
    module.BASE, module.STEM = BASE, STEM
    return module


def prior_receipts():
    return {name: {'sha256': digest((PRIOR / name).read_bytes()), 'bytes': (PRIOR / name).stat().st_size}
            for name in ('allowlist.json', 'assemble.py', 'native-helper-embedding-memory.macos-arm64.json',
                         'native-helper-embedding-memory.macos-arm64.tar.gz')}


def selection(files, reports):
    return {'schema': 1, 'reports': reports, 'selection': 'Exact files only. No directory recursion during packaging.',
            'exclusions': EXCLUSIONS, 'files': sorted(files.values(), key=lambda row: row['member'])}


def base():
    require(stat.S_ISDIR(BASE.lstat().st_mode), 'Evidence directory is not a real directory')
    original = (PRIOR / 'assemble.py').read_bytes()
    write_new(BASE / 'reused-assemble.py', original)
    files = {}
    reports = {'release_images': str(RELEASE / 'report.json'), 'startup': str(STARTUP / 'report.json'),
               'saturation': str(SATURATION / 'report.json'), 'occupancy_build': str(OCCUPANCY / 'report.json'),
               'failed_pool': str(FAILED_POOL / 'report.json'), 'failed_pool_cleanup_audit': str(AUDIT)}
    for root, label, pool in ((RELEASE, 'release_images', False), (STARTUP, 'startup', False),
                              (SATURATION, 'saturation', False), (OCCUPANCY, 'occupancy_build', False),
                              (FAILED_POOL, 'failed_pool', True)):
        add_run(files, root, label, pool)
    add_file(files, AUDIT, 'read_only_failed_pool_cleanup_audit')
    add_file(files, BASE / 'assemble.py', 'assembly_adapter_source')
    add_file(files, BASE / 'reused-assemble.py', 'retained_stdlib_assembly_source')
    close_references(files)
    chosen = selection(files, reports)
    scan = privacy_scan(files)
    reused = load_reused()
    measured = {'startup': reused.startup(chosen, 'startup'), 'saturation': reused.saturation(chosen, 'saturation')}
    summary = {'schema': 1, 'status': 'prepared_pending_corrected_pool', 'source_member_count': len(files),
               'source_bytes': sum(row['bytes'] for row in files.values()), 'measurements': measured,
               'privacy_pattern_finding_count': len(scan['pattern_findings']),
               'privacy_sensitive_string_count': len(scan['nonempty_sensitive_json_strings']),
               'prior_evidence_receipts': prior_receipts(),
               'corrected_pool': 'Excluded until root supplies its exact report path.'}
    write_new(BASE / 'allowlist.base.json', encoded(chosen))
    write_new(BASE / 'privacy-scan.base.json', encoded(scan))
    write_new(BASE / 'base-review.json', encoded(summary))
    print(json.dumps({key: value for key, value in summary.items() if key not in {'measurements', 'prior_evidence_receipts'}}))


def package(pool_report):
    chosen = json.loads((BASE / 'allowlist.base.json').read_bytes())
    files = {row['original_path']: row for row in chosen['files']}
    reused = load_reused()
    for row in chosen['files']:
        reused.receipt_file(row)
    root = pool_report.parent
    require(pool_report.name == 'report.json' and root != FAILED_POOL and eligible(pool_report), 'Invalid corrected pool receipt')
    add_run(files, root, 'corrected_pool', True)
    close_references(files)
    chosen['reports']['corrected_pool'] = str(pool_report)
    chosen = selection(files, chosen['reports'])
    scan = privacy_scan(files)
    require(not scan['pattern_findings'] and not scan['nonempty_sensitive_json_strings'], 'Privacy scan requires review')
    startup = reused.startup(chosen, 'startup')
    saturation = reused.saturation(chosen, 'saturation')
    pool = json.loads(pool_report.read_bytes())
    failed = json.loads((FAILED_POOL / 'report.json').read_bytes())
    audit = json.loads(AUDIT.read_bytes())
    require(failed['status'] == 'failed' and audit['status'] == 'passed', 'Failed run or separate audit verdict changed')
    require(pool['status'] == 'passed', 'Corrected pool did not pass')
    prior_before = json.loads((BASE / 'base-review.json').read_bytes())['prior_evidence_receipts']
    require(prior_receipts() == prior_before, 'Prior evidence changed during assembly')
    allowlist_data = encoded(chosen)
    allowlist_sha = digest(allowlist_data)
    write_new(BASE / 'allowlist.json', allowlist_data)
    write_new(BASE / 'privacy-scan.json', encoded(scan))
    manifest = {'schema': 1, 'title': 'Current release helper image memory and pool evidence, macOS arm64',
                'selection': chosen['selection'], 'allowlist_sha256': allowlist_sha,
                'source_member_count': len(files), 'uncompressed_source_bytes': sum(r['bytes'] for r in files.values()),
                'exclusions': EXCLUSIONS, 'files': chosen['files'],
                'self_receipt': 'The external index records this manifest hash; no recursive self hash.'}
    manifest_data = encoded(manifest)
    write_new(BASE / 'manifest.json', manifest_data)
    indexed_reports = {}
    for label, path in chosen['reports'].items():
        row = files[path]
        indexed_reports[label] = {'member': row['member'], 'original_path': path, 'sha256': row['sha256'],
                                  'status': json.loads(reused.receipt_file(row)).get('status')}
    index = {'schema': 1, 'title': manifest['title'],
             'scope': 'Three current release-image startup and control-state saturation trials per CLI/worker, build provenance, corrected pool and retained failed pool/audit.',
             'bundle': {'file': STEM + '.tar.gz', 'status': 'pending_archive_round_trip', 'member_count': len(files) + 1,
                        'manifest_member': 'manifest.json'},
             'manifest': {'sha256': digest(manifest_data), 'bytes': len(manifest_data), 'source_member_count': len(files),
                          'uncompressed_source_bytes': manifest['uncompressed_source_bytes'], 'files': chosen['files']},
             'reports': indexed_reports, 'measurements': {'startup': startup, 'saturation': saturation},
             'release_images': json.loads((RELEASE / 'calibration-inputs.json').read_bytes())['binaries'],
             'pool': {'report_member': indexed_reports['corrected_pool']['member'], 'status': pool['status'],
                      'semantics': pool['semantics'], 'bounds': pool['bounds'], 'limits': pool['limits']},
             'failed_pool': {'report_member': indexed_reports['failed_pool']['member'], 'status': failed['status'],
                             'error': failed['error'], 'audit_required': failed['audit_required'],
                             'separate_cleanup_audit_member': indexed_reports['failed_pool_cleanup_audit']['member'],
                             'separate_cleanup_audit_status': audit['status'],
                             'verdict_policy': 'The later cleanup audit does not rewrite or pass the failed workload.'},
             'privacy_review': {'automated_selected_text_scan': scan,
                                'reviewed_content_classes': 'Original reports and bounded logs, source/build manifests, observer/runners and assembly sources only.',
                                'original_report_bytes': 'Preserved without redaction or rewriting.'},
             'source_scope': {'policy': json.loads((RELEASE / 'report.json').read_bytes())['source_scope']['policy'],
                              'application': 'Full before/after source manifests and recorded source-scope policies remain in the archive. No current checkout equality is inferred.'},
             'exclusions': EXCLUSIONS, 'prior_evidence_integrity': {'unchanged': True, 'receipts': prior_before},
             'verification': {'status': 'draft_pending_archive_round_trip', 'allowlist_sha256': allowlist_sha,
                              'original_report_bytes': 'Preserved without redaction or rewriting.',
                              'no_build_workload_native_load_or_deletion': True},
             'limits': [
                 'Local macOS arm64 evidence for the exact recorded release hashes. No other image or native target is calibrated.',
                 'Kernel lifetime RSS maxima through successful qualifying reads are distinct from physical footprint, plateau occupancy and process-tree peak memory.',
                 'Startup clients were deliberately terminated and reaped. Helper cleanup also requires exact birth identity exit and original witness release.',
                 'Saturation uses the retained test-only unlink-aware witness proof. Unlinking or identity-only proof alone does not pass cleanup.',
                 'Sampling errors and rejected samples remain in the original reports. Startup speed improvement is not established.',
                 'Sequential pool RSS sums are not an instantaneous aggregate peak. Individual lifetime maxima cannot be summed into one.',
                 'Pool work and single-helper control-state saturation are separate workloads. The pool does not establish eight simultaneously saturated helpers.',
                 'The failed pool and its later read-only cleanup audit retain separate verdicts. Neither timeouts nor new lock paths prove exit.',
                 'No broader crash recovery, arbitrary descendant containment, low-resource hardware, safe static sweep, automatic-default, publication or release acceptance follows.',
                 'No runtime binary, dynamic library, state directory, database, ready marker or endpoint publication is packaged.',
             ]}
    write_new(BASE / (STEM + '.draft.json'), encoded(index))
    reused.ALLOWLIST_SHA = allowlist_sha

    def load_selection():
        raw = (BASE / 'allowlist.json').read_bytes()
        require(digest(raw) == allowlist_sha, 'Final allowlist changed')
        value = json.loads(raw)
        require(value == chosen, 'Final allowlist differs from reviewed selection')
        return value

    reused.load_selection = load_selection
    reused.package()
    require(prior_receipts() == prior_before, 'Prior evidence changed after archive round trip')
    write_new(BASE / 'prior-evidence-after.json', encoded({'unchanged': True, 'receipts': prior_receipts()}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('base', 'package'))
    parser.add_argument('--pool-report', type=Path)
    args = parser.parse_args()
    if args.phase == 'base':
        require(args.pool_report is None, 'Base selection excludes the corrected pool')
        base()
    else:
        require(args.pool_report is not None, 'Root must supply the corrected pool report')
        package(args.pool_report)
