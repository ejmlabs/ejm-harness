#!/usr/bin/env python3
"""Package only the frozen, reviewed evidence allowlist. Never execute its sources."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile


BASE = Path('/private/tmp/ejm-helper-memory-evidence-20261020')
ALLOWLIST = BASE / 'allowlist.json'
ALLOWLIST_SHA = 'a6a56054cc39fca987eb7ba3542f15cac2359cc53096c3a6f172db4225b237f4'
STEM = 'native-helper-embedding-memory.macos-arm64'
MIB = 1024 * 1024


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def write_new(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def safe_member(name):
    parts = PurePosixPath(name)
    return bool(name) and not parts.is_absolute() and '..' not in parts.parts


def receipt_file(item):
    path = Path(item['original_path'])
    require(stat.S_ISREG(path.lstat().st_mode), 'Not a regular source file: ' + str(path))
    data = path.read_bytes()
    require(len(data) == item['bytes'] and digest(data) == item['sha256'],
            'Source receipt changed: ' + str(path))
    require(b'\0' not in data, 'Binary content selected: ' + str(path))
    data.decode('utf-8')
    return data


def load_selection():
    data = ALLOWLIST.read_bytes()
    require(digest(data) == ALLOWLIST_SHA, 'Allowlist changed')
    value = json.loads(data)
    names = [item['member'] for item in value['files']]
    require(len(names) == len(set(names)) == 175, 'Unexpected or duplicate members')
    require(all(safe_member(name) for name in names), 'Unsafe archive name')
    return value


def report_ref(selection, label):
    path = selection['reports'][label]
    return next(item for item in selection['files'] if item['original_path'] == path)


def report(selection, label):
    return json.loads(receipt_file(report_ref(selection, label)))


def startup(selection, label):
    value = report(selection, label)
    require(value['status'] == 'passed' and not value['audit_required'], 'Startup trial report failed')
    rows = []
    for i, trial in enumerate(value['trials']):
        client, helper = trial['client_cleanup'], trial['helper_cleanup']
        require(client['reaped'] and client['returncode'] == -15 and not client['errors'],
                'Startup client cleanup differs')
        require(all(helper[key] for key in ('proved', 'identity_ended', 'witness_stable', 'witness_available'))
                and not helper['errors'] and not trial['audit_required'], 'Startup helper cleanup differs')
        peak = trial['counters']['rss_kernel_lifetime_peak_bytes']
        rows.append({
            'image': trial['image'], 'trial': trial['index'], 'pointer': '/trials/' + str(i),
            'rss_kernel_lifetime_peak_bytes': peak, 'rss_kernel_lifetime_peak_mib': peak / MIB,
            'ready_observed_offset_seconds': trial['ready_observed_offset_seconds'],
            'window_seconds': trial['actual_command_free_window_seconds'],
            'client_reaped': True, 'client_returncode': client['returncode'],
            'client_signals': client['signals'], 'helper_exit_proved': True,
            'helper_exit_evidence': helper['exit_evidence'], 'original_witness_stable_and_available': True,
            'cleanup_error_count': 0, 'audit_required': False,
        })
    require(len(rows) == 6, 'Expected three startup trials per embedding')
    return {
        'report_member': report_ref(selection, label)['member'], 'status': value['status'],
        'host': value['host'], 'semantics': value['semantics'], 'bounds': value['bounds'],
        'trials': rows, 'minimum_peak_mib': min(row['rss_kernel_lifetime_peak_mib'] for row in rows),
        'maximum_peak_mib': max(row['rss_kernel_lifetime_peak_mib'] for row in rows),
    }


def saturation(selection, label):
    value = report(selection, label)
    require(value['status'] == 'passed' and not value['audit_required'], 'Saturation report failed')
    rows = []
    for i, trial in enumerate(value['trials']):
        client, helper = trial['client_cleanup'], trial['helper_cleanup']
        require(client['reaped'] and client['returncode'] == 0 and not client['audit_required'],
                'Saturation client cleanup differs')
        require(helper['unlink_aware_test_cleanup_proved'] and helper['witness_state'] == 'unlinked_original'
                and helper['identity_only']['identity_ended'] and not helper['errors']
                and not helper['audit_required'] and not trial['audit_required'], 'Saturation cleanup differs')
        require(len(trial['stages']) == 14 and trial['stages'][-1]['native_owner_occupancy'] == 'helper_exit_proven',
                'Saturation stage contract differs')
        peak = trial['rss_kernel_lifetime_peak_bytes']
        rows.append({
            'image': trial['image'], 'trial': trial['index'], 'pointer': '/trials/' + str(i),
            'rss_kernel_lifetime_peak_bytes': peak, 'rss_kernel_lifetime_peak_mib': peak / MIB,
            'qualifying_mach_reads': trial['qualifying_mach_reads'],
            'validated_stages': [stage['native_owner_occupancy'] for stage in trial['stages']],
            'recorded_sample_error_count': len(trial['sample_errors']),
            'client_reaped': True, 'client_returncode': 0,
            'exact_identity_ended': True, 'exact_identity_exit_evidence': helper['identity_only']['exit_evidence'],
            'identity_only_cleanup_proved': helper['identity_only']['proved'],
            'combined_unlink_aware_test_cleanup_proved': True,
            'original_witness_state': helper['witness_state'],
            'original_retained_witness_stable': helper['witness_stable'],
            'original_retained_witness_unlocked': helper['witness_available'],
            'cleanup_error_count': 0, 'audit_required': False,
        })
    require(len(rows) == 6, 'Expected three saturation trials per embedding')
    return {
        'report_member': report_ref(selection, label)['member'], 'status': value['status'],
        'host': value['host'], 'semantics': value['semantics'], 'bounds': value['bounds'], 'trials': rows,
        'maximum_peak_bytes': max(row['rss_kernel_lifetime_peak_bytes'] for row in rows),
        'maximum_peak_mib': max(row['rss_kernel_lifetime_peak_mib'] for row in rows),
        'per_embedding_maximum_peak_mib': {image: max(row['rss_kernel_lifetime_peak_mib'] for row in rows
                                                       if row['image'] == image) for image in ('cli', 'worker')},
        'all_within_provisional_32_mib_helper_baseline': all(row['rss_kernel_lifetime_peak_bytes'] <= 32 * MIB
                                                          for row in rows),
    }


def failed_attempt(selection, label, image):
    value = report(selection, label)
    root = Path(selection['reports'][label]).parent
    snapshots = []
    for suffix in ('before', 'after'):
        path = root / (image + '-ejm-harness-' + suffix + '.json')
        item = next(row for row in selection['files'] if row['original_path'] == str(path))
        snapshots.append(json.loads(receipt_file(item)))
    before, after = snapshots
    require(value['status'] == 'failed', 'Aborted attempt must remain failed evidence')
    return {
        'report_member': report_ref(selection, label)['member'], 'status': 'failed', 'error': value['error'],
        'category': 'source_freeze_failure_after_successful_compilation',
        'changed_paths': {key: sorted(name for name in before[key].keys() | after[key].keys()
                                     if before[key].get(name) != after[key].get(name)) for key in ('files', 'symlinks')},
        'head_unchanged': before['head'] == after['head'], 'index_unchanged': before['index'] == after['index'],
        'retained': 'Original failed report, compilation logs and both full source manifests.',
    }


def draft():
    selection = load_selection()
    privacy = json.loads((BASE / 'privacy-scan.json').read_bytes())
    require(not privacy['pattern_findings'] and not privacy['nonempty_sensitive_json_strings'],
            'Privacy scan has unreviewed findings')
    post_release = report(selection, 'post_release')
    policy = post_release['source_scope']['policy']
    functional = report(selection, 'functional_gate')
    duplex = report(selection, 'duplex_smoke')
    measurements = {
        'pre_wire_startup': startup(selection, 'pre_startup'),
        'pre_wire_saturation': saturation(selection, 'pre_saturation'),
        'post_wire_startup': startup(selection, 'post_startup'),
        'post_wire_saturation': saturation(selection, 'post_saturation'),
    }
    limits = [
        'Local release-image evidence from one macOS 26.5.2 arm64 host, three fresh trials per embedding and condition.',
        'Mach resident_size_max measures each helper kernel lifetime RSS maximum through a qualifying successful read, including startup. It is not instantaneous plateau RSS or process-tree RSS.',
        'Physical-footprint ledger values remain separate and do not substitute for RSS.',
        'Post-wire startup peaks span 7.375 to 7.546875 MiB. First CLI readiness is 3.3337974589667283 seconds. These observations establish no startup speed improvement.',
        'Original saturation trials 0, 4 and 5 retain a rejected pre-proof invalid physical-footprint maximum sample. Every saturation trial retains an expected teardown observation error after helper_exit_proven. These are not zero-error sampling runs.',
        'Startup clients were deliberately terminated and reaped with returncode -15. Helper exit also required exact birth identity termination and availability of the original stable witness.',
        'Saturation cleanup uses the test-only unlink-aware composite proof: reaped client exit zero, terminal validated helper_exit_proven stage, exact helper identity ended, and original retained witness inode stable, unlocked and unlinked. Unlinking alone proves nothing. Identity-only proof alone is false in these fixtures.',
        'Duplex smoke reports detached_survived_owner_death=true and owner_retained_capacity_saturated=false. It does not establish sandboxing, full descendant containment or saturated helper memory.',
        'The functional gate covers focused executor format, contracts and clippy plus a separate release duplex smoke. It is not the full scripts/check gate.',
        'The observer compilation receipt lacks complete compiler and SDK identity.',
        'This evidence grants no Linux, Windows, low-resource host, automatic-default, deployment or release acceptance.',
        'Runtime and fixture Rust source bytes and binary images are not packaged. Full source manifests, image hashes, build receipts, observer C/Python sources and original logs identify the measured inputs.',
    ]
    manifest = {
        'schema': 1, 'title': 'Native helper embedding memory evidence, macOS arm64',
        'selection': selection['selection'], 'allowlist_sha256': ALLOWLIST_SHA,
        'source_member_count': len(selection['files']),
        'uncompressed_source_bytes': sum(row['bytes'] for row in selection['files']),
        'source_scope': policy, 'exclusions': selection['exclusions'], 'files': selection['files'],
        'self_receipt': 'The external index records this manifest hash; the manifest omits its own recursive hash.',
    }
    manifest_data = encoded(manifest)
    write_new(BASE / 'manifest.json', manifest_data)
    index = {
        'schema': 1, 'title': manifest['title'],
        'scope': 'Original pre-wire and post-wire helper calibration, saturation, focused functional checks and release-image provenance.',
        'bundle': {'file': STEM + '.tar.gz', 'status': 'pending_serialized_matrix_completion',
                   'member_count': len(selection['files']) + 1, 'manifest_member': 'manifest.json'},
        'manifest': {'sha256': digest(manifest_data), 'bytes': len(manifest_data),
                     'source_member_count': manifest['source_member_count'],
                     'uncompressed_source_bytes': manifest['uncompressed_source_bytes'], 'files': selection['files']},
        'reports': {label: {'member': report_ref(selection, label)['member'],
                            'original_path': name, 'status': report(selection, label)['status']}
                    for label, name in selection['reports'].items()},
        'measurements': measurements,
        'functional_checks': {
            'executor_gate': {'report_member': report_ref(selection, 'functional_gate')['member'],
                              'status': functional['status'],
                              'phases': [{key: phase[key] for key in ('name', 'status', 'returncode', 'reaped', 'logs_final')}
                                         for phase in functional['phases']]},
            'duplex_smoke': {'report_member': report_ref(selection, 'duplex_smoke')['member'],
                             'status': duplex['status'], 'fixture_result': duplex['fixture_result'],
                             'phases': [{key: phase[key] for key in ('name', 'status', 'returncode', 'reaped', 'logs_final')}
                                        for phase in duplex['phases']]},
        },
        'failed_attempts': [failed_attempt(selection, 'aborted_release_1', 'worker'),
                            failed_attempt(selection, 'aborted_release_2', 'bench')],
        'source_scope': {
            'policy': policy, 'module': post_release['source_scope']['module'],
            'application': 'Baseline runs and the two aborted image attempts used full source equality. Post-wire calibration, saturation, duplex smoke and final image build used the stated runtime comparison scope.',
            'post_startup_observations': report(selection, 'post_startup')['source_observations'],
            'post_saturation_observations': report(selection, 'post_saturation')['source_observations'],
            'duplex_excluded_changes': duplex['excluded_source_changes'],
            'final_cli_image_source_receipts': post_release['images']['cli']['sources'],
            'full_manifest_policy': 'All full before/after file, symlink, status, HEAD and index receipts are retained. Site changes in the final CLI image build do not establish full source equality.',
        },
        'exclusions': selection['exclusions'],
        'privacy_review': {
            'automated_selected_text_scan': privacy,
            'independent_json_review': {'reports_reviewed': 11, 'accidental_secret_or_live_endpoint_string_candidates': 0,
                                        'numeric_provider_token_debt_fields': 'Quota counters only.'},
            'independent_allowlist_review': '175 unique safe relative names; no binary, dylib, state, readiness, endpoint or database members; failed evidence and both occupancy-libtest receipt sets retained.',
            'limit': 'Pattern and structural review does not prove absence of every possible secret.',
        },
        'verification': {'status': 'draft_pending_archive_round_trip', 'allowlist_sha256': ALLOWLIST_SHA,
                         'original_report_bytes': 'Preserved without redaction or rewriting.',
                         'no_build_workload_native_load_or_deletion': True},
        'limits': limits,
    }
    write_new(BASE / (STEM + '.draft.json'), encoded(index))
    print(json.dumps({'status': 'draft_ready', 'source_members': len(selection['files']),
                      'archive_members_after_packaging': len(selection['files']) + 1,
                      'manifest_sha256': digest(manifest_data)}))


def package():
    selection = load_selection()
    index = json.loads((BASE / (STEM + '.draft.json')).read_bytes())
    manifest_data = (BASE / 'manifest.json').read_bytes()
    require(digest(manifest_data) == index['manifest']['sha256'], 'Manifest changed after review')
    require(json.loads(manifest_data)['files'] == selection['files'], 'Manifest differs from allowlist')
    output = BASE / (STEM + '.tar.gz')
    with output.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for name, data in [('manifest.json', manifest_data)] + [
                    (item['member'], receipt_file(item)) for item in selection['files']
                ]:
                    member = tarfile.TarInfo(name)
                    member.size = len(data)
                    member.mode = 0o644
                    member.mtime = 0
                    archive.addfile(member, io.BytesIO(data))
    expected = {'manifest.json': {'sha256': digest(manifest_data), 'bytes': len(manifest_data)},
                **{row['member']: row for row in selection['files']}}
    with tarfile.open(output, 'r:gz') as archive:
        members = archive.getmembers()
        require(len(members) == len(expected) and len({member.name for member in members}) == len(expected),
                'Archive member count differs')
        require(set(expected) == {member.name for member in members}, 'Archive membership differs')
        for member in members:
            require(member.isfile() and not member.issym() and member.mode == 0o644
                    and safe_member(member.name), 'Archive contains a nonregular or unsafe member')
            data = archive.extractfile(member).read()
            require(len(data) == expected[member.name]['bytes']
                    and digest(data) == expected[member.name]['sha256'], 'Archive content differs')
    for item in selection['files']:
        receipt_file(item)
    output_data = output.read_bytes()
    index['bundle'].update(status='verified', sha256=digest(output_data), bytes=len(output_data))
    index['verification'].update(status='passed', exact_allowlist_membership=True,
                                 regular_safe_nonexecutable_member_modes=True, all_member_hashes_match=True,
                                 all_original_hashes_unchanged_after_packaging=True,
                                 archive_read_without_extraction=True)
    index_path = BASE / (STEM + '.json')
    index_data = encoded(index)
    write_new(index_path, index_data)
    verification = {
        'schema': 1, 'status': 'passed', 'index': {'path': str(index_path), 'sha256': digest(index_data),
                                                  'bytes': len(index_data)},
        'bundle': {'path': str(output), 'sha256': digest(output_data), 'bytes': len(output_data)},
        'manifest': {'path': str(BASE / 'manifest.json'), 'sha256': digest(manifest_data), 'bytes': len(manifest_data)},
        'archive_members': len(expected), 'source_members': len(selection['files']),
        'uncompressed_source_bytes': sum(item['bytes'] for item in selection['files']),
        'verification': index['verification'],
    }
    write_new(BASE / 'verification.json', encoded(verification))
    print(json.dumps(verification))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('draft', 'package'))
    arguments = parser.parse_args()
    {'draft': draft, 'package': package}[arguments.phase]()
