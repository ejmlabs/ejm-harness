#!/usr/bin/env python3
"""Extend the frozen base selection with explicit pool and provenance receipts."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import types


BASE = Path('/private/tmp/ejm-helper-current-memory-evidence-20261021')
POOL_ROOT = Path('/private/tmp/ejm-capacity-pool-barrier-20261020')
POOL = POOL_ROOT / 'pool-20261021T032656Z-6acbb99d'
PREFLIGHT = POOL_ROOT / 'pool-20261021T032520Z-d690452a/preflight-failure.json'
RELEASE = Path('/private/tmp/ejm-capacity-release-images-20261020/20261021T032639Z-5a86fa96')
STEM = 'native-helper-current-image-memory.macos-arm64'
POOL_SHA = 'ca520a09b6b91965e9ebc5ce8009878df2c9d8d0fed390ed8dcfc1c2e1a56514'
PREFLIGHT_SHA = '2bde5f783ba42e0b31ccdae19e61a43f9a2e956b029800c6bc3a429d35d9c6ed'
EXTRA_NAMES = ('README.md', 'adapt-pool.v2.py', 'adapt-pool.v3.py', 'adapter-v2-to-v3.diff',
               'adapter-v3.diff', 'adapter.diff', 'diagnosis.json', 'pool-utility.diff',
               'pool-utility.v3.py', 'preparation-checks.json', 'prepare-v3.json', 'ready-v3.json')


def load_adapter():
    path = BASE / 'assemble.py'
    module = types.ModuleType('retained_current_evidence_adapter')
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    original = module.eligible
    extra = {POOL_ROOT / name for name in EXTRA_NAMES}
    module.eligible = lambda candidate: original(candidate) or candidate in extra
    return module


def broad_review(adapter, chosen):
    pattern = re.compile(r'(?i)token|secret|credential|password|api.?key|authoriz|cookie|capabil|endpoint|address|(^|_)port$')
    classified = 0
    candidates = []

    def walk(value, member, pointer=''):
        nonlocal classified
        if isinstance(value, dict):
            for key, item in value.items():
                child = pointer + '/' + str(key)
                if pattern.search(str(key)) and isinstance(item, str) and item:
                    if pointer == '/files' and re.fullmatch('[0-9a-f]{64}', item):
                        classified += 1
                    else:
                        candidates.append({'member': member, 'pointer': child,
                                           'value_sha256': adapter.digest(item.encode())})
                walk(item, member, child)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, member, pointer + '/' + str(index))

    for row in chosen['files']:
        if Path(row['original_path']).suffix == '.json':
            walk(json.loads(adapter.bytes_for(Path(row['original_path']))), row['member'])
    return {'schema': 1, 'status': 'passed' if not candidates else 'review_required',
            'matching_source_manifest_hashes': classified, 'other_nonempty_strings': candidates,
            'review': 'Matching file-map values are source SHA-256 receipts, including credential-handling source filenames.',
            'limit': 'Pattern and structural review cannot prove absence of every possible secret.'}


def verify_pool(adapter, report):
    adapter.require(report['status'] == 'passed' and not report['audit_required'], 'Pool verdict differs')
    pool = report['shared_pool']
    adapter.require(pool['status'] == 'passed' and len(pool['clients']) == 8 and len(pool['samples']) == 20,
                    'Pool workload bounds differ')
    barrier = pool['first_eight_commitment_barrier']
    adapter.require(barrier['all_witnesses_held'] and len(barrier['helpers']) == 8
                    and barrier['registry']['occupied'] == barrier['registry']['committed'] == 8,
                    'First-eight commitment barrier differs')
    adapter.require(pool['ninth']['started_after_commitment_barrier'] and pool['ninth']['returncode'] == 1,
                    'Ninth admission verdict differs')
    adapter.require(pool['coarse_commitments_per_ancestor']['host'] == {
        'generations': 8, 'memory_bytes': 268435456, 'processes': 8}, 'Host charges differ')
    completed = pool['completed_participants']
    adapter.require(len(completed) == 8 and all(row['status'] == 'completed'
                    and row['commands_completed'] == 800 and row['remote_api_calls'] == 0 for row in completed),
                    'Completed native workload differs')
    adapter.require(len(pool['client_cleanup']) == 8 and all(row['reaped'] and row['returncode'] == 0
                    and not row['sigterm_requested'] and not row['sigkill_required'] for row in pool['client_cleanup']),
                    'Pool client cleanup differs')
    ninth = pool['ninth_cleanup']
    adapter.require(ninth['reaped'] and ninth['returncode'] == 1 and not ninth['sigterm_requested']
                    and not ninth['sigkill_required'], 'Ninth cleanup differs')
    adapter.require(len(pool['helper_cleanup']) == 8 and all(row['identity_ended'] and row['witness_available']
                    for row in pool['helper_cleanup']) and pool['discovered_helper_cleanup_complete'],
                    'Pool helper cleanup differs')
    return {'status': 'passed', 'participants': 8, 'native_commands_completed': 6400,
            'sample_scans': 20, 'sample_window_seconds': pool['actual_window_seconds'],
            'ninth_started_after_first_eight_commitment_barrier': True, 'ninth_returncode': 1,
            'coarse_commitments_per_ancestor': pool['coarse_commitments_per_ancestor'],
            'sampled_helper_aggregate_high_water_rss_bytes': pool['sampled_helper_aggregate_high_water_rss_bytes'],
            'sampled_client_aggregate_high_water_rss_bytes': pool['sampled_client_aggregate_high_water_rss_bytes'],
            'sampled_combined_aggregate_high_water_rss_bytes': pool['sampled_combined_aggregate_high_water_rss_bytes'],
            'per_helper_kernel_lifetime_peak_rss_bytes': pool['per_helper_kernel_lifetime_peak_rss_bytes'],
            'clients_reaped': 9, 'helpers_identity_ended_and_witness_available': 8,
            'cleanup_signals_requested': False, 'semantics': report['semantics'], 'limits': report['limits']}


def draft(adapter):
    base_raw = (BASE / 'allowlist.base.json').read_bytes()
    adapter.require(adapter.digest(base_raw) == '88ed735be09daaf3dc2bebff4a52e409a9acc335ea1cb82eae0329eeba1bafde',
                    'Frozen base allowlist changed')
    chosen = json.loads(base_raw)
    reused = adapter.load_reused()
    files = {row['original_path']: row for row in chosen['files']}
    for row in chosen['files']:
        reused.receipt_file(row)
    adapter.require(adapter.digest((POOL / 'report.json').read_bytes()) == POOL_SHA, 'Pool receipt hash differs')
    adapter.require(adapter.digest(PREFLIGHT.read_bytes()) == PREFLIGHT_SHA, 'Preflight receipt hash differs')
    adapter.add_run(files, RELEASE, 'fresh_pool_release_images')
    adapter.add_run(files, POOL, 'corrected_pool', pool=True)
    adapter.add_file(files, PREFLIGHT, 'retained_failed_preflight_and_source_bridge')
    for name in EXTRA_NAMES:
        adapter.add_file(files, POOL_ROOT / name, 'pool_diagnosis_adapter_and_diff')
    adapter.add_file(files, BASE / 'finalize.v2.py', 'versioned_final_assembly_source')
    adapter.add_file(files, BASE / 'privacy-review.base.json', 'base_sensitive_key_review')
    adapter.close_references(files)
    chosen['reports'].update(corrected_pool=str(POOL / 'report.json'), fresh_pool_release_images=str(RELEASE / 'report.json'),
                             failed_pool_preflight=str(PREFLIGHT), pool_diagnosis=str(POOL_ROOT / 'diagnosis.json'),
                             pool_adapter_ready=str(POOL_ROOT / 'ready-v3.json'))
    chosen = adapter.selection(files, chosen['reports'])
    scan = adapter.privacy_scan(files)
    review = broad_review(adapter, chosen)
    adapter.require(not scan['pattern_findings'] and not scan['nonempty_sensitive_json_strings']
                    and not review['other_nonempty_strings'], 'Privacy review has unresolved candidates')
    original_release = json.loads((adapter.RELEASE / 'report.json').read_bytes())
    fresh_release = json.loads((RELEASE / 'report.json').read_bytes())
    adapter.require(original_release['status'] == fresh_release['status'] == 'passed', 'Release build failed')
    equality = []
    for image in ('smoke', 'worker', 'bench', 'cli'):
        old = original_release['images'][image]['copied_binary']
        new = fresh_release['images'][image]['copied_binary']
        adapter.require(old['sha256'] == new['sha256'] and old['bytes'] == new['bytes'], 'Image bytes differ: ' + image)
        equality.append({'image': image, 'sha256': old['sha256'], 'bytes': old['bytes'],
                         'memory_series_image_path': old['path'], 'fresh_pool_image_path': new['path']})
    startup = reused.startup(chosen, 'startup')
    saturation = reused.saturation(chosen, 'saturation')
    pool_report = json.loads((POOL / 'report.json').read_bytes())
    pool_summary = verify_pool(adapter, pool_report)
    preflight = json.loads(PREFLIGHT.read_bytes())
    adapter.require(preflight['status'] == 'failed_preflight_before_fixture_launch'
                    and preflight['fixture_clients_started'] == preflight['native_helpers_started'] == 0
                    and not preflight['native_observer_loaded'], 'Preflight failure scope differs')
    failed = json.loads((adapter.FAILED_POOL / 'report.json').read_bytes())
    audit = json.loads(adapter.AUDIT.read_bytes())
    adapter.require(failed['status'] == 'failed' and audit['status'] == 'passed', 'Earlier verdicts changed')
    prior = json.loads((BASE / 'base-review.json').read_bytes())['prior_evidence_receipts']
    adapter.require(adapter.prior_receipts() == prior, 'Earlier index/archive changed')
    allowlist_data = adapter.encoded(chosen)
    allowlist_sha = adapter.digest(allowlist_data)
    adapter.write_new(BASE / 'allowlist.json', allowlist_data)
    adapter.write_new(BASE / 'privacy-scan.json', adapter.encoded(scan))
    adapter.write_new(BASE / 'privacy-review.json', adapter.encoded(review))
    manifest = {'schema': 1, 'title': 'Current release helper image memory and pool evidence, macOS arm64',
                'selection': chosen['selection'], 'allowlist_sha256': allowlist_sha,
                'source_member_count': len(files), 'uncompressed_source_bytes': sum(r['bytes'] for r in files.values()),
                'exclusions': chosen['exclusions'], 'files': chosen['files'],
                'self_receipt': 'The external index records this manifest hash; no recursive self hash.'}
    manifest_raw = adapter.encoded(manifest)
    adapter.write_new(BASE / 'manifest.json', manifest_raw)
    reports = {label: {'member': files[path]['member'], 'original_path': path,
                        'sha256': files[path]['sha256'], 'status': json.loads(reused.receipt_file(files[path])).get('status')}
               for label, path in chosen['reports'].items()}
    index = {'schema': 1, 'title': manifest['title'],
             'scope': 'Three exact-image startup and control-state saturation trials per CLI/worker, separate fresh pool build provenance, a corrected pool run and retained failed pool/preflight evidence.',
             'bundle': {'file': STEM + '.tar.gz', 'status': 'pending_archive_round_trip',
                        'member_count': len(files) + 1, 'manifest_member': 'manifest.json'},
             'manifest': {'sha256': adapter.digest(manifest_raw), 'bytes': len(manifest_raw),
                          'source_member_count': len(files), 'uncompressed_source_bytes': manifest['uncompressed_source_bytes'],
                          'files': chosen['files']},
             'reports': reports, 'measurements': {'startup': startup, 'saturation': saturation},
             'image_identity_bridge': {'all_four_images_have_identical_recorded_sha256_and_byte_lengths': True,
                                       'memory_build_report': reports['release_images'],
                                       'fresh_pool_build_report': reports['fresh_pool_release_images'], 'images': equality,
                                       'meaning': 'The fresh build preserves the measured image bytes. It adds provenance, not new memory trials or source equality.'},
             'pool': {'report_member': reports['corrected_pool']['member'], **pool_summary},
             'failed_pool': {'report_member': reports['failed_pool']['member'], 'status': failed['status'],
                             'error': failed['error'], 'audit_required': failed['audit_required'],
                             'separate_cleanup_audit': reports['failed_pool_cleanup_audit'],
                             'verdict_policy': 'The later cleanup audit does not rewrite or pass the failed workload.'},
             'failed_pool_preflight': {'report_member': reports['failed_pool_preflight']['member'], 'status': preflight['status'],
                                       'error': preflight['error'], 'fixture_clients_started': 0, 'native_helpers_started': 0,
                                       'native_observer_loaded': False, 'source_bridge': preflight['source_bridge']},
             'source_scope': {'memory_source_policy': original_release['source_scope']['policy'],
                              'fresh_pool_build_source_policy': fresh_release['source_scope']['policy'],
                              'pool_source_policy': pool_report['source_scope']['policy'],
                              'pool_source_observations': pool_report['source_observations'],
                              'application': 'Full before/after manifests, source bridges and excluded path deltas remain in original receipts. No all-source-stable claim is made.'},
             'privacy_review': {'automated_selected_text_scan': scan, 'broader_sensitive_key_review': review,
                                'original_report_bytes': 'Preserved without redaction or rewriting.'},
             'exclusions': chosen['exclusions'], 'prior_evidence_integrity': {'unchanged': True, 'receipts': prior},
             'verification': {'status': 'draft_pending_archive_round_trip', 'allowlist_sha256': allowlist_sha,
                              'original_report_bytes': 'Preserved without redaction or rewriting.',
                              'no_build_workload_native_load_or_deletion': True},
             'limits': [
                 'Local macOS arm64 evidence applies to exact recorded image hashes only. Other targets and images remain uncalibrated.',
                 'Kernel lifetime RSS maxima through qualifying successful reads differ from physical footprint, plateau occupancy and process-tree peaks.',
                 'Startup clients were deliberately terminated and reaped. Helper exit also requires exact birth identity exit and original witness release.',
                 'Control-state saturation uses the retained test-only unlink-aware witness proof. Unlinking or identity-only proof alone does not pass cleanup.',
                 'Sampling errors and rejected samples remain in the raw reports. No startup speed improvement is established.',
                 'Sequential pool RSS sums do not establish simultaneous aggregate peak memory. Individual lifetime maxima cannot be summed into one.',
                 'The pool uses benchmark fixture images and does not establish eight simultaneously saturated CLI/worker helpers or descendant peaks.',
                 'The retained observer compilation receipt lacks full compiler and SDK identity.',
                 'The failed pool, its later cleanup audit and the preflight failure retain separate verdicts. A timeout or new lock path does not prove exit.',
                 'Broader crash recovery, arbitrary descendant containment, low-resource hardware, safe static sweeps, automatic defaults and publication remain gated.',
                 'No runtime executable, dynamic library, state directory, database, ready marker or endpoint publication is packaged.',
             ]}
    adapter.write_new(BASE / (STEM + '.draft.json'), adapter.encoded(index))
    print(json.dumps({'status': 'draft_ready', 'source_members': len(files), 'source_bytes': manifest['uncompressed_source_bytes'],
                      'allowlist_sha256': allowlist_sha, 'manifest_sha256': adapter.digest(manifest_raw),
                      'privacy_pattern_findings': len(scan['pattern_findings']),
                      'privacy_sensitive_string_candidates': len(scan['nonempty_sensitive_json_strings']),
                      'broader_unclassified_candidates': len(review['other_nonempty_strings']),
                      'pool': {key: pool_summary[key] for key in ('participants', 'native_commands_completed', 'clients_reaped', 'helpers_identity_ended_and_witness_available')}}))


def package(adapter):
    chosen_raw = (BASE / 'allowlist.json').read_bytes()
    chosen = json.loads(chosen_raw)
    reused = adapter.load_reused()
    reused.ALLOWLIST_SHA = adapter.digest(chosen_raw)

    def load_selection():
        raw = (BASE / 'allowlist.json').read_bytes()
        adapter.require(adapter.digest(raw) == reused.ALLOWLIST_SHA and json.loads(raw) == chosen, 'Allowlist changed')
        return chosen

    reused.load_selection = load_selection
    reused.package()
    prior = json.loads((BASE / 'base-review.json').read_bytes())['prior_evidence_receipts']
    adapter.require(adapter.prior_receipts() == prior, 'Earlier index/archive changed after packaging')
    adapter.write_new(BASE / 'prior-evidence-after.json', adapter.encoded({'unchanged': True, 'receipts': adapter.prior_receipts()}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('draft', 'package'))
    args = parser.parse_args()
    current = load_adapter()
    {'draft': draft, 'package': package}[args.phase](current)
