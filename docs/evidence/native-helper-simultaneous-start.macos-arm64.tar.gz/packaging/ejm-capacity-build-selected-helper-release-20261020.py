import datetime,fcntl,hashlib,json,os,pathlib,shutil,subprocess,sys,time
root=pathlib.Path('/Users/everettmorgan/Desktop/ejm-harness')
base=pathlib.Path('/private/tmp/ejm-capacity-selected-helper-release-20261020')
base.mkdir()

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
    paths=[p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in {'.rs','.toml','.json','.mjs','.py'}]
    paths += [root/n for n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml') if (root/n).is_file()]
    return {str(p.relative_to(root)):digest(p) for p in sorted(paths)}
command=['cargo','build','--release','--offline','--locked','-p','ejm-harness-bench','--bin','ejm-harness-bench','--target-dir',str(root/'target'),'--message-format=json']
record={'state':'waiting','command':command,'environment':{k:os.environ.get(k) for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','CARGO_TARGET_DIR')},'rustc':subprocess.check_output(['rustc','-vV'],text=True),'cargo':subprocess.check_output(['cargo','--version'],text=True),'profile':{'release':True,'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0'},'limits':['Workspace source and build-input hashes do not hash cached registry dependencies or compiler internals.','The retained executable is this checkpoint; later source changes need a new build before current-source claims.']}
provenance=base/'build-provenance.json'
provenance.write_text(json.dumps(record,indent=2)+'\n')
with open('/tmp/ejm-capacity-cargo.lock','a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    assert shutil.disk_usage(root).free >= 10*1024*1024*1024
    before=snapshot();record.update(state='started',source_sha256_before=before,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),git_status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True))
    provenance.write_text(json.dumps(record,indent=2)+'\n')
    started=time.perf_counter()
    completed=subprocess.run(command,cwd=root,env=dict(os.environ,CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0'),capture_output=True)
    (base/'build.stdout.jsonl').write_bytes(completed.stdout);(base/'build.stderr.log').write_bytes(completed.stderr)
    record.update(returncode=completed.returncode,elapsed_seconds=time.perf_counter()-started,source_sha256_after=snapshot(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if completed.returncode:
        record['state']='failed';provenance.write_text(json.dumps(record,indent=2)+'\n');sys.stdout.buffer.write(completed.stderr);sys.exit(completed.returncode)
    matches=[m['executable'] for line in completed.stdout.splitlines() if (m:=json.loads(line)).get('reason')=='compiler-artifact' and m['target']['name']=='ejm-harness-bench' and m.get('executable')]
    assert len(matches)==1,matches
    original=pathlib.Path(matches[0]);copy=base/'ejm-harness-bench';shutil.copy2(original,copy);copy.chmod(0o555)
    record['binary']={'path':str(copy),'cargo_path':str(original),'sha256':digest(copy),'bytes':copy.stat().st_size}
    record['state']='finished' if before==record['source_sha256_after'] else 'source-changed'
    provenance.write_text(json.dumps(record,indent=2)+'\n')
    assert record['state']=='finished','source changed during build'
    assert record['binary']['sha256'] not in {'66618eed04f6887b2c4eba21ed85401130936a47ef7891bf4c58a36458ad2f22', '6cf88a35fd0d112c9f8ad92760edaad03efea8f5c9ef7fcfcf0b6dd28536843a'},'earlier frozen binary'
print(json.dumps({'provenance':str(provenance),'binary':record['binary'],'elapsed_seconds':record['elapsed_seconds']},indent=2))
