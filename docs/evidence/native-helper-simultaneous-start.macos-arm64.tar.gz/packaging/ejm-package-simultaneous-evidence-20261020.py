"""Retain exact startup observations with a compact, deterministic evidence bundle."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


ROOT = Path('/Users/everettmorgan/Desktop/ejm-harness')
DEST = ROOT / 'docs/evidence/native-helper-simultaneous-start.macos-arm64'
ATTEMPTS = [
    ('startup-floor-observer-v1', Path('/private/tmp/ejm-capacity-startup-floor-simultaneous-20261020/20261020T203342Z-68a7caaa')),
    ('startup-floor-observer-v2', Path('/private/tmp/ejm-capacity-startup-floor-simultaneous-20261020/20261020T204431Z-fd3f9196')),
    ('selected-helper-final', Path('/private/tmp/ejm-capacity-selected-helper-simultaneous-20261020/20261020T205819Z-fc42a16d')),
]
EXPECTED_REPORTS = [
    'd3f86150f1da7818d707fc749d4075db1e014a8d7cbdba2b922c7e4c5338f39e',
    '576fb7ec72a880c2d98bd456957612391a565c52201e3ab8bd2a4544ac7dcd89',
    '32323000480ab32796f24d633a04ab8c144edbad98aef9aa27db36a101261b28',
]
BUILD = Path('/private/tmp/ejm-capacity-selected-helper-release-20261020')
FOCUSED = Path('/private/tmp/ejm-capacity-selected-helper-gate-20261020')
payloads = {}
manifest = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def retain(path, member, expected=None):
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f'Expected a regular evidence file: {path}')
    data = path.read_bytes()
    digest = sha(data)
    if expected is not None and expected != digest:
        raise RuntimeError(f'Evidence hash changed: {path}')
    if member in payloads:
        raise RuntimeError(f'Duplicate member: {member}')
    payloads[member] = data
    manifest[member] = {'source': str(path), 'bytes': len(data), 'sha256': digest}
    return data


def summarize_case(case):
    # Recompute completions from every retained client log. The first observer
    # stopped populating its aggregate list after the first invalid participant.
    clients = []
    for client in case.get('clients', []):
        raw = Path(client['stdout']).read_text()
        try:
            result = json.loads(raw)
        except json.JSONDecodeError:
            result = {}
        clients.append({
            'pid': client['pid'], 'status': result.get('status'),
            'commands_completed': result.get('commands_completed', 0),
            'recorded_returncode': client.get('returncode'),
        })
    completed = [c for c in clients if c['status'] == 'completed' and c['commands_completed'] == 800]
    cleanup = case.get('client_cleanup', [])
    helpers = case.get('helper_cleanup', [])
    witnesses = case.get('participant_witness_cleanup', [])
    return {
        'mode': case['mode'], 'status': case['status'],
        'launched': len(clients), 'completed_participants_from_logs': len(completed),
        'successful_commands_from_completed_logs': sum(c['commands_completed'] for c in completed),
        'clients': clients,
        'launch_span_seconds': case.get('launch_span_seconds'),
        'completion_elapsed_seconds': case.get('completion_elapsed_seconds'),
        'helper_cleanup_elapsed_seconds': case.get('helper_cleanup_elapsed_seconds'),
        'validation_error': case.get('validation_error', case.get('error')),
        'client_identities_ended_and_reaped': sum(c.get('identity_ended', False) and c.get('reaped', False) for c in cleanup),
        'client_signals_requested': sum(c.get('sigterm_requested', False) or c.get('sigkill_required', False) for c in cleanup),
        'observed_helper_identities': len(helpers),
        'observed_helper_identities_ended_and_witnesses_released': sum(c.get('identity_ended', False) and c.get('witness_available', False) for c in helpers),
        'participant_witnesses_observed': len(witnesses),
        'participant_witnesses_released': sum(c.get('available', False) for c in witnesses),
        'raw_cleanup_verdict': case.get('all_cleanup_proved'),
        'cleanup_errors': case.get('cleanup_errors', []),
    }


summaries = []
for (label, directory), expected in zip(ATTEMPTS, EXPECTED_REPORTS, strict=True):
    report = json.loads(retain(directory / 'report.json', label + '/report.json', expected))
    for path in sorted(directory.iterdir()):
        if path.name != 'report.json' and path.suffix in ('.py', '.c', '.json'):
            retain(path, label + '/' + path.name)
    for path in sorted(directory.glob('*/client-*/std*')):
        if path.name in ('stdout', 'stderr'):
            retain(path, label + '/' + path.relative_to(directory).as_posix())
    for info in report['source_files'].values():
        retained = Path(info['retained_copy'])
        if sha(retained.read_bytes()) != info['sha256']:
            raise RuntimeError(f'Retained source changed: {retained}')
    for case in report['cases']:
        for relative, expected_log in case.get('logs_sha256', {}).items():
            if sha((directory / relative).read_bytes()) != expected_log:
                raise RuntimeError(f'Retained client log changed: {relative}')
    summaries.append({
        'label': label, 'status': report['status'], 'report_sha256': expected,
        'report_member': label + '/report.json', 'binary': report['binary'],
        'source_verification_before': report['source_verification_before'],
        'source_verification_after': report['source_verification_after'],
        'cases': [summarize_case(c) for c in report['cases']],
    })

build = json.loads((BUILD / 'build-provenance.json').read_text())
if build['source_sha256_before'] != build['source_sha256_after'] or build['returncode'] != 0:
    raise RuntimeError('Release build did not retain a stable successful checkpoint')
for relative, expected in sorted(build['source_sha256_after'].items()):
    path = ROOT / relative
    path.relative_to(ROOT)
    retain(path, 'source/' + relative, expected)
for path in sorted(BUILD.iterdir()):
    if path.suffix in ('.json', '.jsonl', '.log'):
        retain(path, 'release/' + path.name)
for directory in sorted(FOCUSED.iterdir()):
    if directory.is_dir():
        for path in sorted(directory.iterdir()):
            if path.suffix in ('.py', '.json', '.log'):
                retain(path, 'focused/' + directory.name + '/' + path.name)
for path in (Path('/private/tmp/ejm-capacity-build-selected-helper-release-20261020.py'), Path(__file__)):
    retain(path, 'packaging/' + path.name)

final = summaries[-1]
if final['status'] != 'passed' or len(final['cases']) != 2:
    raise RuntimeError('Final two-case run did not pass')
for case in final['cases']:
    if not (case['completed_participants_from_logs'] == 8
            and case['successful_commands_from_completed_logs'] == 6400
            and case['client_identities_ended_and_reaped'] == 8
            and case['observed_helper_identities_ended_and_witnesses_released'] == 8
            and case['participant_witnesses_released'] == 8
            and case['client_signals_requested'] == 0
            and not case['cleanup_errors']):
        raise RuntimeError('Final completion or cleanup evidence is incomplete')

payloads['manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
def bundle_bytes():
    result = io.BytesIO()
    with gzip.GzipFile(fileobj=result, mode='wb', filename='', mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(payloads.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
    return result.getvalue()

bundle = bundle_bytes()
if bundle != bundle_bytes():
    raise RuntimeError('Evidence bundle is not deterministic')
with tarfile.open(fileobj=io.BytesIO(bundle), mode='r:gz') as archive:
    names = archive.getnames()
    if len(names) != len(payloads) or set(names) != set(payloads):
        raise RuntimeError('Archive members differ')
    for member in archive:
        if not member.isfile() or archive.extractfile(member).read() != payloads[member.name]:
            raise RuntimeError(f'Archived member differs: {member.name}')

index = {
    'schema': 'ejm-harness.native-helper-simultaneous-start.v1',
    'status': 'targeted_final_pass_with_prior_failures_retained',
    'platform': 'macOS arm64', 'date': '2026-10-20',
    'host': json.loads((ATTEMPTS[-1][1] / 'report.json').read_text())['host'],
    'final_build_inputs': len(build['source_sha256_after']),
    'build_provenance_sha256': sha((BUILD / 'build-provenance.json').read_bytes()),
    'workload': {'participants_per_mode': 8, 'managed_agents_per_participant': 100,
                 'rounds': 8, 'park_ms': 500, 'model_requests': 1, 'jobs': 1,
                 'nofile_soft': [4096 + 128 * i for i in range(8)],
                 'intentional_launch_stagger_seconds': 0,
                 'command_overall_deadline_seconds': 5,
                 'case_completion_deadline_seconds': 180,
                 'helper_cleanup_deadline_seconds': 12},
    'attempts': summaries,
    'bundle': {'file': DEST.name + '.tar.gz', 'sha256': sha(bundle),
               'bytes': len(bundle), 'uncompressed_payload_bytes': sum(map(len, payloads.values())),
               'member_count': len(payloads), 'manifest_member': 'manifest.json',
               'every_member_verified': True, 'deterministic_bytes_verified': True,
               'contents': ['Exact raw attempt reports', 'Retained runners and identity probe source',
                            'All launched client stdout and stderr', 'Release build receipt and logs',
                            'All 130 recorded final build inputs', 'Focused checks including failed attempts',
                            'Evidence packaging source'],
               'excluded': ['Session databases', 'Capacity databases', 'Executables and compiled probes']},
    'interpretation': [
        'The final run supports simultaneous first-start progress for this exact workload and checkpoint.',
        'The first observer recorded an SQLite busy rejection before it added diagnostic context; the failing SQL call is unproven.',
        'The first observer also aborted automatic launch at two clients on an unrelated probe assertion; this is not eight-client cleanup evidence.',
        'The corrected prior observer completed seven automatic participants; the eighth missed its existing command deadline before useful execution.',
        'The selected-helper correction preserves still-valid sibling selections while retaining transactional checks.',
        'Final helper discovery and identity checks are sampled; no simultaneous eight-helper lifetime is required.',
        'General host activity was uncontrolled. These two cases do not establish performance improvement or automatic-default acceptance.',
        'Startup/retained-state calibration, consumer costs, broad scale, Linux and Windows acceptance remain open.',
        'Witness release does not certify arbitrary detached descendant cleanup.',
    ],
}
Path(str(DEST) + '.tar.gz').write_bytes(bundle)
Path(str(DEST) + '.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'index': str(DEST) + '.json', 'bundle': index['bundle'],
                  'final_cases': final['cases']}, separators=(',', ':')))
