//! Private native files. The vault supplies encrypted bytes and owns transactions.

#[cfg(unix)]
mod unix;
#[cfg(windows)]
mod windows;

#[cfg(unix)]
pub(super) use unix::{PrivateDirectory, RawTransaction};
#[cfg(windows)]
pub(super) use windows::{PrivateDirectory, RawTransaction};

#[cfg(test)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum IoOperation {
    Read,
    Write,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum IoBoundary {
    Before,
    After,
}

#[cfg(test)]
#[derive(Clone, Copy)]
struct IoFault {
    name: &'static str,
    operation: IoOperation,
    boundary: IoBoundary,
    remaining: usize,
}

#[cfg(test)]
#[derive(Default)]
struct IoFaultPlan(std::cell::Cell<Option<IoFault>>);

#[cfg(test)]
#[derive(Debug)]
pub(super) struct InjectedIoFailure;

#[cfg(test)]
impl std::fmt::Display for InjectedIoFailure {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("injected credential file I/O failure")
    }
}

#[cfg(test)]
impl std::error::Error for InjectedIoFailure {}

#[cfg(test)]
impl IoFaultPlan {
    fn check(
        &self,
        name: &str,
        operation: IoOperation,
        boundary: IoBoundary,
    ) -> anyhow::Result<()> {
        let Some(mut fault) = self.0.get() else {
            return Ok(());
        };
        if fault.name != name || fault.operation != operation || fault.boundary != boundary {
            return Ok(());
        }
        fault.remaining -= 1;
        self.0.set((fault.remaining > 0).then_some(fault));
        if fault.remaining == 0 {
            return Err(InjectedIoFailure.into());
        }
        Ok(())
    }
}

#[cfg(test)]
impl RawTransaction {
    pub(super) fn inject_io_failure(
        &self,
        name: &'static str,
        operation: IoOperation,
        boundary: IoBoundary,
        occurrence: usize,
    ) {
        assert!(occurrence > 0);
        self.faults.0.set(Some(IoFault {
            name,
            operation,
            boundary,
            remaining: occurrence,
        }));
    }
}
