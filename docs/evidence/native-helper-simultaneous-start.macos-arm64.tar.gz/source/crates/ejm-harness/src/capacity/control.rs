//! Bounded feedback from ordinary work. No synthetic work or per-agent history.

use std::time::Duration;

use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

const BINS: usize = 32;
const CLASSES: usize = 8;
const MIN_SAMPLES: u64 = 8;
const HEALTHY_WINDOWS: u8 = 3;
const COOLDOWN_WINDOWS: u8 = 5;

#[derive(Debug, Default, Clone, Serialize, Deserialize, JsonSchema)]
pub struct TimingSummary {
    pub samples: u64,
    pub p50_micros: u64,
    pub p95_micros: u64,
}

#[derive(Debug, Default, Clone, Serialize, Deserialize, JsonSchema)]
pub struct LaneSnapshot {
    pub successful: u64,
    pub failed: u64,
    pub cancelled: u64,
    pub queue: TimingSummary,
    pub preparation: TimingSummary,
    pub provider_wait: TimingSummary,
    pub service: TimingSummary,
    pub successful_per_second: f64,
}

#[derive(Debug, Default, Clone)]
struct Histogram {
    bins: [u64; BINS],
    samples: u64,
}

impl Histogram {
    fn record(&mut self, elapsed: Duration) {
        let micros = u64::try_from(elapsed.as_micros()).unwrap_or(u64::MAX);
        let index = usize::try_from(64 - micros.leading_zeros())
            .unwrap_or(BINS - 1)
            .min(BINS - 1);
        self.bins[index] = self.bins[index].saturating_add(1);
        self.samples = self.samples.saturating_add(1);
    }

    fn percentile(&self, percent: u64) -> u64 {
        if self.samples == 0 {
            return 0;
        }
        let threshold = self.samples.saturating_mul(percent).div_ceil(100);
        let mut count = 0_u64;
        for (index, samples) in self.bins.iter().enumerate() {
            count = count.saturating_add(*samples);
            if count >= threshold {
                return (1_u64 << index).saturating_sub(1);
            }
        }
        u64::MAX
    }

    fn snapshot(&self) -> TimingSummary {
        TimingSummary {
            samples: self.samples,
            p50_micros: self.percentile(50),
            p95_micros: self.percentile(95),
        }
    }
}

#[derive(Clone, Copy)]
pub(super) enum Outcome {
    Successful,
    Failed,
    Cancelled,
}

#[derive(Default, Clone)]
pub(super) struct Timings {
    pub queue: Duration,
    pub preparation: Duration,
    pub provider_wait: Duration,
    pub service: Duration,
}

/// Numeric cost buckets contain no tool names, model names, or request text.
pub(super) fn workload_class(bytes: u64) -> usize {
    match bytes {
        0..=4_096 => 0,
        4_097..=16_384 => 1,
        16_385..=65_536 => 2,
        65_537..=262_144 => 3,
        262_145..=1_048_576 => 4,
        1_048_577..=16_777_216 => 5,
        16_777_217..=268_435_456 => 6,
        _ => 7,
    }
}

#[derive(Default)]
struct Window {
    successes: u64,
    failures: u64,
    classes: [u64; CLASSES],
    service: Histogram,
    elapsed: Duration,
    healthy: u8,
}

#[derive(Clone, Copy)]
struct Point {
    target: usize,
    rate: f64,
    p95: u64,
    class: usize,
}

/// Only stable, validated evidence is persisted. An unaccepted probe is a hint
/// about nothing and must never become the next process's starting target.
#[derive(Clone, Serialize, Deserialize)]
pub(super) struct Evidence {
    pub samples: u64,
    pub target: usize,
    pub rate: f64,
    pub p95_micros: u64,
    pub class: usize,
}

struct Lane {
    target: usize,
    totals: LaneSnapshot,
    queue: Histogram,
    preparation: Histogram,
    provider_wait: Histogram,
    service: Histogram,
    window: Window,
    class_totals: [u64; CLASSES],
    stable: Option<Point>,
    probe: Option<Point>,
    cooldown: u8,
}

impl Lane {
    fn new(target: usize) -> Self {
        Self {
            target,
            totals: LaneSnapshot::default(),
            queue: Histogram::default(),
            preparation: Histogram::default(),
            provider_wait: Histogram::default(),
            service: Histogram::default(),
            window: Window::default(),
            class_totals: [0; CLASSES],
            stable: None,
            probe: None,
            cooldown: 0,
        }
    }

    fn record(&mut self, outcome: Outcome, timing: &Timings, class: usize) {
        self.queue.record(timing.queue);
        self.preparation.record(timing.preparation);
        self.provider_wait.record(timing.provider_wait);
        self.service.record(timing.service);
        match outcome {
            Outcome::Successful => {
                self.totals.successful = self.totals.successful.saturating_add(1);
                self.window.successes = self.window.successes.saturating_add(1);
                self.window.classes[class.min(CLASSES - 1)] =
                    self.window.classes[class.min(CLASSES - 1)].saturating_add(1);
                self.class_totals[class.min(CLASSES - 1)] =
                    self.class_totals[class.min(CLASSES - 1)].saturating_add(1);
                self.window.service.record(timing.service);
            }
            Outcome::Failed => {
                self.totals.failed = self.totals.failed.saturating_add(1);
                self.window.failures = self.window.failures.saturating_add(1);
            }
            Outcome::Cancelled => self.totals.cancelled = self.totals.cancelled.saturating_add(1),
        }
    }

    fn snapshot(&self) -> LaneSnapshot {
        LaneSnapshot {
            queue: self.queue.snapshot(),
            preparation: self.preparation.snapshot(),
            provider_wait: self.provider_wait.snapshot(),
            service: self.service.snapshot(),
            ..self.totals.clone()
        }
    }

    fn reduce(&mut self) {
        self.target = self.target.div_ceil(2).max(1);
        self.reset_evidence();
        self.cooldown = COOLDOWN_WINDOWS;
    }

    fn reset_evidence(&mut self) {
        self.stable = None;
        self.probe = None;
        self.window = Window::default();
    }

    fn tick(
        &mut self,
        elapsed: Duration,
        demand: bool,
        clear: bool,
        granted: usize,
        ceiling: usize,
        can_probe: bool,
    ) -> bool {
        self.target = self.target.min(ceiling).max(1);
        self.cooldown = self.cooldown.saturating_sub(1);
        if !demand || !clear || granted < self.target {
            // Idle or donor-limited windows cannot establish a throughput curve.
            self.window = Window::default();
            if granted < self.target {
                self.probe = None;
                self.stable = None;
            }
            return false;
        }
        self.window.elapsed = self.window.elapsed.saturating_add(elapsed);
        self.window.healthy = self.window.healthy.saturating_add(1);
        if self.window.healthy < HEALTHY_WINDOWS || self.window.successes < MIN_SAMPLES {
            return false;
        }
        let window = std::mem::take(&mut self.window);
        let (class, count) = window
            .classes
            .iter()
            .enumerate()
            .max_by_key(|(_, count)| **count)
            .map_or((0, 0), |(index, count)| (index, *count));
        if count.saturating_mul(5) < window.successes.saturating_mul(4) || window.failures != 0 {
            if let Some(baseline) = self.probe.take() {
                self.target = baseline.target;
            }
            self.stable = None;
            self.cooldown = COOLDOWN_WINDOWS;
            return true;
        }
        let rate = f64::from(u32::try_from(window.successes).unwrap_or(u32::MAX))
            / window.elapsed.as_secs_f64().max(0.001);
        self.totals.successful_per_second = rate;
        let point = Point {
            target: self.target,
            rate,
            p95: window.service.percentile(95),
            class,
        };
        if let Some(baseline) = self.probe.take() {
            if baseline.class != class {
                self.target = baseline.target;
                self.stable = None;
            } else if rate <= baseline.rate * 1.10 || point.p95 > baseline.p95.saturating_mul(5) / 4
            {
                self.target = baseline.target;
                self.stable = Some(baseline);
            } else {
                self.stable = Some(point);
            }
            self.cooldown = COOLDOWN_WINDOWS;
            return true;
        }
        if self.stable.is_some_and(|stable| stable.class != class) {
            self.stable = Some(point);
            self.cooldown = COOLDOWN_WINDOWS;
            return false;
        }
        self.stable = Some(point);
        if can_probe && self.cooldown == 0 && self.target < ceiling {
            self.probe = Some(point);
            self.target = self
                .target
                .saturating_add((self.target / 4).clamp(1, 8))
                .min(ceiling);
            return true;
        }
        false
    }

    fn evidence(&self) -> Option<Evidence> {
        self.stable.map(|point| Evidence {
            samples: self.class_totals[point.class],
            target: point.target,
            rate: point.rate,
            p95_micros: point.p95,
            class: point.class,
        })
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum Pressure {
    Clear,
    Unknown,
    Busy,
}

pub(super) struct Tuner {
    model: Lane,
    tool: Lane,
    next_model: bool,
}

impl Tuner {
    pub fn new(models: usize, jobs: usize) -> Self {
        Self {
            model: Lane::new(models),
            tool: Lane::new(jobs),
            next_model: true,
        }
    }
    pub fn models(&self) -> usize {
        self.model.target
    }
    pub fn jobs(&self) -> usize {
        self.tool.target
    }
    pub fn model_snapshot(&self) -> LaneSnapshot {
        self.model.snapshot()
    }
    pub fn tool_snapshot(&self) -> LaneSnapshot {
        self.tool.snapshot()
    }
    pub fn record_model(&mut self, outcome: Outcome, timing: &Timings, class: usize) {
        self.model.record(outcome, timing, class);
    }
    pub fn record_tool(&mut self, outcome: Outcome, timing: &Timings, class: usize) {
        self.tool.record(outcome, timing, class);
    }
    pub fn evidence(&self) -> [Option<Evidence>; 2] {
        [self.model.evidence(), self.tool.evidence()]
    }
    pub fn class_samples(&self) -> [[u64; CLASSES]; 2] {
        [self.model.class_totals, self.tool.class_totals]
    }
    pub fn reset_evidence(&mut self) {
        self.model.reset_evidence();
        self.tool.reset_evidence();
    }

    pub fn apply_hint(&mut self, lane: usize, target: usize) {
        let lane = if lane == 0 {
            &mut self.model
        } else {
            &mut self.tool
        };
        lane.target = target.max(1);
        lane.reset_evidence();
        lane.cooldown = COOLDOWN_WINDOWS;
    }

    pub fn tick(
        &mut self,
        elapsed: Duration,
        demand: [bool; 2],
        pressure: Pressure,
        granted: [usize; 2],
        ceilings: [usize; 2],
    ) {
        if pressure == Pressure::Busy {
            self.model.reduce();
            self.tool.reduce();
            return;
        }
        let clear = pressure == Pressure::Clear;
        let mut changed = false;
        if self.next_model {
            changed |= self.model.tick(
                elapsed,
                demand[0],
                clear,
                granted[0],
                ceilings[0],
                self.tool.probe.is_none(),
            );
            changed |= self.tool.tick(
                elapsed,
                demand[1],
                clear,
                granted[1],
                ceilings[1],
                !changed && self.model.probe.is_none(),
            );
        } else {
            changed |= self.tool.tick(
                elapsed,
                demand[1],
                clear,
                granted[1],
                ceilings[1],
                self.model.probe.is_none(),
            );
            changed |= self.model.tick(
                elapsed,
                demand[0],
                clear,
                granted[0],
                ceilings[0],
                !changed && self.tool.probe.is_none(),
            );
        }
        if changed {
            self.next_model = !self.next_model;
        }
    }
}

#[cfg(test)]
#[allow(
    clippy::unwrap_used,
    clippy::expect_used,
    reason = "Deterministic controller fixtures use direct assertions."
)]
mod tests {
    use super::*;

    fn window(tuner: &mut Tuner, successes: usize, service: Duration, class: usize) {
        for _ in 0..3 {
            for _ in 0..successes {
                tuner.record_model(
                    Outcome::Successful,
                    &Timings {
                        service,
                        ..Timings::default()
                    },
                    class,
                );
            }
            tuner.tick(
                Duration::from_secs(2),
                [true, false],
                Pressure::Clear,
                [tuner.models(), tuner.jobs()],
                [32, 8],
            );
        }
    }

    #[test]
    fn probes_require_demand_and_comparable_gain() {
        let mut tuner = Tuner::new(4, 2);
        for _ in 0..20 {
            tuner.tick(
                Duration::from_secs(2),
                [false, false],
                Pressure::Clear,
                [4, 2],
                [32, 8],
            );
        }
        assert_eq!(tuner.models(), 4);
        window(&mut tuner, 8, Duration::from_millis(10), 1);
        assert_eq!(tuner.models(), 5);
        window(&mut tuner, 8, Duration::from_millis(10), 1);
        assert_eq!(
            tuner.models(),
            4,
            "equal throughput must prefer the smaller target"
        );
        assert_eq!(tuner.evidence()[0].as_ref().unwrap().target, 4);
    }

    #[test]
    fn easier_work_does_not_validate_a_probe() {
        let mut tuner = Tuner::new(4, 2);
        window(&mut tuner, 8, Duration::from_millis(10), 5);
        window(&mut tuner, 30, Duration::from_millis(1), 1);
        assert_eq!(tuner.models(), 4);
        assert!(tuner.evidence()[0].is_none());
    }

    #[test]
    fn unknown_samples_block_growth_and_pressure_drains_targets() {
        let mut tuner = Tuner::new(8, 4);
        for _ in 0..10 {
            tuner.record_model(Outcome::Successful, &Timings::default(), 0);
            tuner.tick(
                Duration::from_secs(2),
                [true, true],
                Pressure::Unknown,
                [8, 4],
                [32, 8],
            );
        }
        assert_eq!((tuner.models(), tuner.jobs()), (8, 4));
        tuner.tick(
            Duration::from_secs(2),
            [true, true],
            Pressure::Busy,
            [8, 4],
            [32, 8],
        );
        assert_eq!((tuner.models(), tuner.jobs()), (4, 2));
        assert_eq!(tuner.model_snapshot().successful, 10);
    }
}
