import datetime
import fcntl
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import time
import uuid

ROOT = pathlib.Path('/Users/everettmorgan/Desktop/ejm-harness')
BASE = pathlib.Path('/private/tmp/ejm-capacity-selected-helper-gate-20261020')
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
EVIDENCE = BASE / (STAMP + '-' + uuid.uuid4().hex[:8])
FORMATTED = [
    'crates/ejm-harness/src/capacity/registry.rs',
    'crates/ejm-harness/src/capacity/registry/bootstrap.rs',
    'crates/ejm-harness/src/capacity/registry/helpers.rs',
    'crates/ejm-harness/src/capacity/registry/helpers/tests/staged.rs',
]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    paths = [p for p in (ROOT / 'crates').rglob('*') if p.is_file() and p.suffix in {'.rs', '.toml', '.mjs', '.py', '.json'}]
    paths.extend(ROOT / name for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml') if (ROOT / name).is_file())
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}


def main():
    EVIDENCE.mkdir(parents=True)
    shutil.copy2(__file__, EVIDENCE / 'runner.py')
    provenance = EVIDENCE / 'provenance.json'
    record = {'state': 'waiting', 'checks': [], 'disk': [], 'runner_sha256': sha(pathlib.Path(__file__))}
    print('EVIDENCE_DIRECTORY=' + str(EVIDENCE), flush=True)
    with open('/tmp/ejm-capacity-cargo.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        print('GLOBAL_LOCK_ACQUIRED', flush=True)
        record.update(state='running', started_utc=now())
        environment = dict(os.environ, CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true')
        tests = [
            'capacity::registry::bootstrap::tests::wal_setup_retries_read_upgrade_without_extending_the_busy_budget',
            'capacity::registry::tests::validation_and_peer_drop_preserve_cross_process_wal_writer_exclusion',
            'capacity::registry::tests::failed_open_preserves_cross_process_rollback_writer_exclusion',
        ]
        commands = [
            ('format-owned', ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', *FORMATTED], None),
            ('fmt-check', ['cargo', 'fmt', '-p', 'ejm-harness', '--', '--check'], None),
            *[(name.rsplit('::', 1)[-1], ['cargo', 'test', '--offline', '--locked', '-p', 'ejm-harness', '--lib', name, '--', '--exact', '--test-threads=1'], 1) for name in tests],
            ('staged-helper-regressions', ['cargo', 'test', '--offline', '--locked', '-p', 'ejm-harness', '--lib', 'capacity::registry::helpers::tests::staged::', '--', '--test-threads=1'], 6),
            ('clippy', ['cargo', 'clippy', '--offline', '--locked', '-p', 'ejm-harness', '--lib', '--tests', '--', '-D', 'warnings'], None),
        ]
        try:
            for name, command, expected_tests in commands:
                free = shutil.disk_usage(ROOT).free
                record['disk'].append({'phase': name, 'free_bytes': free, 'utc': now()})
                if free < 10 * 1024**3:
                    raise RuntimeError('Free disk below 10 GiB floor')
                if name == 'fmt-check':
                    record['source_before'] = snapshot()
                print('Starting ' + name, flush=True)
                started = time.perf_counter()
                output_path = EVIDENCE / (name + '.stdout.log')
                error_path = EVIDENCE / (name + '.stderr.log')
                with output_path.open('xb') as output, error_path.open('xb') as errors:
                    result = subprocess.run(command, cwd=ROOT, env=environment, stdout=output, stderr=errors, timeout=600)
                check = {'name': name, 'command': command, 'returncode': result.returncode, 'elapsed_seconds': time.perf_counter() - started}
                if expected_tests is not None:
                    summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;', output_path.read_text())
                    check['expected_passed_tests'] = expected_tests
                    check['test_summaries'] = summaries
                    check['test_count_matches'] = summaries == [(str(expected_tests), '0')]
                record['checks'].append(check)
                provenance.write_text(json.dumps(record, indent=2) + '\n')
                print(json.dumps(check), flush=True)
                if result.returncode or check.get('test_count_matches') is False:
                    raise RuntimeError(name + ' failed')
            record['source_after'] = snapshot()
            record['sources_match'] = record['source_before'] == record['source_after']
            if not record['sources_match']:
                raise RuntimeError('Source changed during focused checks')
            record['state'] = 'passed'
        except Exception as error:
            record.update(state='failed', error=str(error))
        finally:
            record['finished_utc'] = now()
            record['log_sha256'] = {p.name: sha(p) for p in EVIDENCE.glob('*.log')}
            provenance.write_text(json.dumps(record, indent=2) + '\n')
            print(json.dumps({'state': record['state'], 'provenance': str(provenance), 'error': record.get('error')}), flush=True)
    print('GLOBAL_LOCK_RELEASED', flush=True)
    return 0 if record['state'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
