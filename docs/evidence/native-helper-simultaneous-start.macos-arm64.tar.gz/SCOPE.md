# Retained evidence scope

This is a revised evidence bundle. Eight package-distribution source files
were omitted during the independent open source scope cleanup because they
contained unrelated proprietary product identity. The remaining 122 of 130
recorded final build inputs are retained. Raw attempt reports, observed
measurements, command results, and their limits have not been changed.

The revised source subset is not byte-identical to the full measured source
and does not establish reproduction of the original full build. The member
manifest describes the retained bytes. Original provenance records remain
historical records of their runs, including their original input hashes.

Omitted source members:

- `source/crates/ejm-harness-package-spec/src/archive.rs`
- `source/crates/ejm-harness-package-spec/src/lib.rs`
- `source/crates/ejm-harness-package-spec/tests/archives.rs`
- `source/crates/ejm-harness-packages/src/registry.rs`
- `source/crates/ejm-harness-packages/src/registry/credentials/tests.rs`
- `source/crates/ejm-harness-packages/src/source/tests.rs`
- `source/crates/ejm-harness-packages/tests/installation.rs`
- `source/crates/ejm-harness-packages/tests/registry_http.rs`
