#!/usr/bin/env python3
"""Two approved simultaneous-start cases against one new frozen checkpoint."""

import ctypes
import datetime
import errno
import fcntl
import importlib.util
import json
import os
import pathlib
import shutil
import sqlite3
import stat
import subprocess
import time
import traceback
import uuid


ROOT = pathlib.Path('/Users/everettmorgan/Desktop/ejm-harness')
BUILD = pathlib.Path('/private/tmp/ejm-capacity-startup-floor-release-20261020')
BENCH = BUILD / 'ejm-harness-bench'
UTIL_PATH = pathlib.Path('/private/tmp/ejm-native-helper-complement-20261020.v2.py')
C_SOURCE = pathlib.Path('/private/tmp/ejm-native-helper-complement-20261020.c')
OUTPUT = pathlib.Path('/private/tmp/ejm-capacity-startup-floor-simultaneous-20261020')
SPEC = importlib.util.spec_from_file_location('retained_fixture_utilities', UTIL_PATH)
UTIL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(UTIL)


def snapshot(root):
    database = root / 'capacity.sqlite3'
    if not database.exists():
        return None
    with sqlite3.connect(f'file:{database}?mode=ro', uri=True, timeout=0.1) as connection:
        connection.execute('BEGIN')
        result = {}
        for table in ('owners', 'domains', 'allocations', 'owner_witnesses', 'native_helpers', 'native_helper_allocations'):
            cursor = connection.execute('SELECT * FROM ' + table)
            names = [column[0] for column in cursor.description]
            rows = []
            for values in cursor:
                row = dict(zip(names, values))
                for name, value in list(row.items()):
                    if isinstance(value, str) and value[:1] in ('{', '['):
                        try:
                            row[name] = json.loads(value)
                        except json.JSONDecodeError:
                            pass
                rows.append(row)
            result[table] = rows
        return result


def identity_ended(probe, pid, birth):
    value = UTIL.Observation()
    code = probe(pid, ctypes.byref(value))
    return (code != 0 and value.sample_errno == errno.ESRCH) or (code == 0 and value.start_abstime != birth)


def open_witness(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        metadata = os.fstat(fd)
        UTIL.check(stat.S_ISREG(metadata.st_mode) and metadata.st_uid == os.getuid() and metadata.st_nlink == 1,
                   'Unsafe witness file')
    except Exception:
        os.close(fd)
        raise
    return fd, {'path': str(path), 'device': metadata.st_dev, 'inode': metadata.st_ino}


def remember_witnesses(root, witnesses):
    for path in root.glob('owner-*.lock'):
        if str(path) not in witnesses:
            fd, record = open_witness(path)
            witnesses[str(path)] = (fd, record)


def discover_helpers(root, helpers, probe, errors):
    for path in root.glob('native/*/endpoint.json'):
        try:
            identity = UTIL.endpoint(path)
            generation = identity['generation']
            if generation in helpers:
                continue
            observed = UTIL.observe(probe, identity['pid'])
            fd, witness = open_witness(path.with_name('owner.lock'))
            helpers[generation] = {'identity': identity, 'helper_birth': observed['start_abstime'],
                                   'parent_pid': observed['parent_pid'], 'witness': fd,
                                   'witness_record': witness, 'first_seen_utc': UTIL.now()}
        except (FileNotFoundError, ProcessLookupError, RuntimeError, json.JSONDecodeError) as error:
            if len(errors) < 64:
                errors.append({'utc': UTIL.now(), 'endpoint_path': str(path), 'error': str(error)})


def save(report, evidence):
    (evidence / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def cleanup_step(result, phase, operation, fallback=None):
    try:
        return operation()
    except Exception as error:
        errors = result.setdefault('cleanup_errors', [])
        if len(errors) < 64:
            errors.append({'phase': phase, 'error': str(error), 'utc': UTIL.now()})
        return fallback


def witness_available(fd, record):
    current = pathlib.Path(record['path']).stat(follow_symlinks=False)
    UTIL.check((current.st_dev, current.st_ino) == (record['device'], record['inode']), 'Witness path identity changed')
    return not UTIL.held(fd)


def cleanup_case(result, clients, helpers, witnesses, root, probe, evidence, directory):
    cleanup_step(result, 'discover_before_cleanup', lambda: discover_helpers(root, helpers, probe, result['discovery_errors']))
    cleanup_step(result, 'witnesses_before_cleanup', lambda: remember_witnesses(root, witnesses))
    result['client_cleanup'] = []
    for item in clients:
        row = cleanup_step(result, 'terminate_client_' + str(item['process'].pid), lambda: UTIL.terminate_client(item),
                           {'pid': item['process'].pid, 'reaped': False})
        row['identity_ended'] = cleanup_step(result, 'client_identity_' + str(item['process'].pid),
                                             lambda: identity_ended(probe, item['process'].pid, item.get('birth')), False)
        result['client_cleanup'].append(row)
    cleanup_started = time.monotonic()
    cleanup_deadline = cleanup_started + 12
    while True:
        cleanup_step(result, 'discover_during_cleanup', lambda: discover_helpers(root, helpers, probe, result['discovery_errors']))
        cleanup_step(result, 'witnesses_during_cleanup', lambda: remember_witnesses(root, witnesses))
        ended = all(cleanup_step(result, 'helper_exit_' + str(item['identity']['pid']),
                                lambda item=item: identity_ended(probe, item['identity']['pid'], item['helper_birth'])
                                and witness_available(item['witness'], item['witness_record']), False)
                    for item in helpers.values())
        released = all(cleanup_step(result, 'participant_witness_' + witness['path'],
                                   lambda fd=fd, witness=witness: witness_available(fd, witness), False)
                       for fd, witness in witnesses.values())
        if ended and released or time.monotonic() >= cleanup_deadline:
            break
        time.sleep(0.025)
    result['helper_cleanup_elapsed_seconds'] = time.monotonic() - cleanup_started
    result['helper_cleanup'] = []
    for generation, item in helpers.items():
        row = {key: value for key, value in item.items() if key != 'witness'}
        row.update(generation=generation,
                   identity_ended=cleanup_step(result, 'final_helper_identity_' + generation,
                                              lambda: identity_ended(probe, item['identity']['pid'], item['helper_birth']), False),
                   witness_available=cleanup_step(result, 'final_helper_witness_' + generation,
                                                 lambda: witness_available(item['witness'], item['witness_record']), False))
        result['helper_cleanup'].append(row)
        cleanup_step(result, 'close_helper_witness_' + generation, lambda: os.close(item['witness']))
    result['participant_witness_cleanup'] = []
    for fd, witness in witnesses.values():
        available = cleanup_step(result, 'final_participant_witness_' + witness['path'],
                                 lambda: witness_available(fd, witness), False)
        result['participant_witness_cleanup'].append(dict(witness, available=available))
        cleanup_step(result, 'close_participant_witness_' + witness['path'], lambda: os.close(fd))
    result['discovered_helper_generations'] = len(helpers)
    result['discovered_helper_domains'] = sorted({item['identity']['domain'] for item in helpers.values()})
    result['sampled_committed_generations'] = sorted({
        row['generation'] for sample in result['registry_snapshots']
        for row in sample['state']['native_helpers'] if row['committed']
    })
    result['helper_membership_proved'] = (
        len(result['discovered_helper_domains']) == 8
        and set(result['sampled_committed_generations']).issubset(helpers)
        and all(item['identity']['accounted'] and item['parent_pid'] in {client['process'].pid for client in clients}
                for item in helpers.values())
    )
    result['all_cleanup_proved'] = (
        len(clients) == 8 and all(row['identity_ended'] and row['reaped'] for row in result['client_cleanup'])
        and all(row['identity_ended'] and row['witness_available'] for row in result['helper_cleanup'])
        and all(row['available'] for row in result['participant_witness_cleanup'])
        and not result.get('cleanup_errors')
    )
    if not result['all_cleanup_proved']:
        result['cleanup_error'] = 'A client/helper identity or lifetime witness did not release within the cleanup bound'
        result.setdefault('error', result['cleanup_error'])
        result['status'] = 'failed'
    if result.get('status') == 'passed' and not result['helper_membership_proved']:
        result.update(status='failed', error='Eight created execution domains or sampled committed generations were not fully observed')
    result['logs_sha256'] = cleanup_step(result, 'hash_logs', lambda: {
        str(p.relative_to(evidence)): UTIL.sha(p) for p in directory.rglob('*')
        if p.is_file() and p.name in ('stdout', 'stderr')}, {})
    if result.get('cleanup_errors'):
        result.update(status='failed', all_cleanup_proved=False)
        result.setdefault('error', 'Cleanup or evidence collection raised an error')


def run_mode(mode, evidence, probe, report):
    directory = evidence / mode
    directory.mkdir(mode=0o700)
    root = directory / 'shared-capacity'
    result = {'mode': mode, 'started_utc': UTIL.now(), 'clients': [], 'registry_snapshots': [],
              'discovery_errors': [], 'launch_stagger_seconds': 0, 'completion_deadline_seconds': 180,
              'helper_cleanup_deadline_seconds': 12, 'expected_commands_per_participant': 800,
              'expected_total_commands': 6400, 'requires_eight_simultaneously_live_helpers': False}
    report['cases'].append(result)
    clients, helpers, witnesses = [], {}, {}
    start_time = time.monotonic()
    try:
        for index in range(8):
            client_directory = directory / f'client-{index + 1}'
            command = [str(BENCH), '--agents', '100', '--rounds', '8', '--park-ms', '500',
                       '--model-requests', '1', '--jobs', '1', '--capacity', mode,
                       '--capacity-root', str(root), '--state-dir', str(client_directory / 'state')]
            item = UTIL.start(command, client_directory, nofile=4096 + 128 * index)
            clients.append(item)
            row = UTIL.command_record(item)
            row['launched_seconds'] = time.monotonic() - start_time
            result['clients'].append(row)
            observed = UTIL.observe(probe, item['process'].pid, parent=os.getpid())
            item['birth'] = observed['start_abstime']
            row['birth'] = item['birth']
        result['launch_span_seconds'] = time.monotonic() - start_time
        deadline = start_time + 180
        next_snapshot, next_disk = time.monotonic(), time.monotonic()
        while True:
            discover_helpers(root, helpers, probe, result['discovery_errors'])
            remember_witnesses(root, witnesses)
            current = time.monotonic()
            if current >= next_snapshot:
                try:
                    state = snapshot(root)
                    if state is not None:
                        result['registry_snapshots'].append({'elapsed_seconds': current - start_time, 'state': state})
                except sqlite3.OperationalError as error:
                    result.setdefault('snapshot_errors', []).append(str(error))
                next_snapshot = current + 0.25
            if current >= next_disk:
                UTIL.disk(report, 'waiting_' + mode)
                next_disk = current + 10
            if all(item['process'].poll() is not None for item in clients):
                break
            UTIL.check(current < deadline, mode + ' exceeded 180 second completion bound')
            time.sleep(0.02)
        result['completion_elapsed_seconds'] = time.monotonic() - start_time
        result['completed_participants'] = []
        for item, row in zip(clients, result['clients']):
            row['returncode'] = item['process'].returncode
            try:
                data = json.loads((item['directory'] / 'stdout').read_text())
            except json.JSONDecodeError:
                data = None
            row['parsed_status'] = data.get('status') if isinstance(data, dict) else None
            row['commands_completed'] = data.get('commands_completed') if isinstance(data, dict) else None
            if not (row['returncode'] == 0 and row['parsed_status'] == 'completed' and row['commands_completed'] == 800):
                result['validation_error'] = mode + ' participant failed complete 800-command JSON check: PID ' + str(row['pid'])
                try:
                    result['rejection_registry_snapshot'] = snapshot(root)
                except Exception as snapshot_error:
                    result['rejection_snapshot_error'] = str(snapshot_error)
                raise RuntimeError(result['validation_error'])
            result['completed_participants'].append(data)
        result['commands_completed_total'] = sum(row['commands_completed'] for row in result['clients'])
        UTIL.check(result['commands_completed_total'] == 6400, 'Incomplete total')
        result['status'] = 'passed'
    except Exception as error:
        result.update(status='failed', error=str(error), traceback=traceback.format_exc())
        try:
            result['failure_registry_snapshot'] = snapshot(root)
        except Exception as snapshot_error:
            result['failure_snapshot_error'] = str(snapshot_error)
    finally:
        try:
            cleanup_case(result, clients, helpers, witnesses, root, probe, evidence, directory)
        except Exception as cleanup_error:
            result.update(status='failed', all_cleanup_proved=False)
            result.setdefault('error', str(cleanup_error))
            result['unexpected_cleanup_error'] = str(cleanup_error)
        finally:
            result['finished_utc'] = UTIL.now()
            save(report, evidence)
    return result['status'] == 'passed' and result['all_cleanup_proved']


def verify_sources(provenance):
    expected = provenance['source_sha256_after']
    mismatches = [name for name, digest in expected.items() if UTIL.sha(ROOT / name) != digest]
    UTIL.check(not mismatches, 'Frozen build inputs differ: ' + repr(mismatches))
    return {'checked_inputs': len(expected), 'mismatches': mismatches}


def main():
    OUTPUT.mkdir(exist_ok=True)
    evidence = OUTPUT / (datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8])
    evidence.mkdir(mode=0o700)
    report = {'schema': 1, 'status': 'waiting', 'started_utc': UTIL.now(), 'disk': [], 'cases': [],
              'disk_floor_bytes': 10 * 1024**3, 'source_files': {},
              'limits': ['Two targeted local macOS startup cases only. No broad capacity or cross-platform claim.',
                         'The eight launches have no intentional stagger; process creation and identity sampling still take measurable time.',
                         'The tests require completed JSON and 800 commands per participant. Exit status alone is insufficient.',
                         'Helper discovery is sampled and does not require all eight helpers to be live simultaneously.',
                         'Participant and helper lifetime witnesses are retained and checked without deleting shared state.',
                         'No automatic-default activation or task3.11 completion is claimed.']}
    for path in (pathlib.Path(__file__), UTIL_PATH, C_SOURCE, BUILD / 'build-provenance.json'):
        target = evidence / path.name
        shutil.copy2(path, target)
        report['source_files'][str(path)] = {'sha256': UTIL.sha(path), 'retained_copy': str(target)}
    print('EVIDENCE_DIRECTORY=' + str(evidence), flush=True)
    with open('/tmp/ejm-capacity-cargo.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        print('GLOBAL_LOCK_ACQUIRED', flush=True)
        try:
            UTIL.disk(report, 'before_cases')
            provenance = json.loads((BUILD / 'build-provenance.json').read_text())
            UTIL.check(provenance['state'] == 'finished', 'Build provenance is incomplete')
            UTIL.check(UTIL.sha(BENCH) == provenance['binary']['sha256'], 'Frozen binary changed')
            report['binary'] = provenance['binary']
            report['source_verification_before'] = verify_sources(provenance)
            report['host'] = {name: subprocess.check_output(command, text=True).strip() for name, command in [
                ('sw_vers', ['sw_vers']), ('uname', ['uname', '-a']), ('hardware', ['sysctl', '-n', 'hw.model', 'hw.ncpu', 'hw.memsize'])]}
            dylib = evidence / 'observe.dylib'
            command = ['cc', '-dynamiclib', '-O2', '-Wall', '-Wextra', '-Werror', str(C_SOURCE), '-o', str(dylib)]
            compiled = subprocess.run(command, capture_output=True, text=True, timeout=30)
            report['counter_adapter_compile'] = {'command': command, 'returncode': compiled.returncode,
                                                 'stdout': compiled.stdout, 'stderr': compiled.stderr}
            UTIL.check(compiled.returncode == 0, 'Counter adapter failed to compile')
            report['counter_adapter_binary_sha256'] = UTIL.sha(dylib)
            library = ctypes.CDLL(str(dylib))
            probe = library.ejm_observe
            probe.argtypes = [ctypes.c_int, ctypes.POINTER(UTIL.Observation)]
            probe.restype = ctypes.c_int
            outcomes = []
            for mode in ('fixed', 'auto'):
                UTIL.disk(report, 'before_' + mode)
                print('Starting simultaneous8 ' + mode, flush=True)
                outcome = run_mode(mode, evidence, probe, report)
                outcomes.append(outcome)
                print(json.dumps({'mode': mode, 'passed': outcome, 'error': report['cases'][-1].get('error')}), flush=True)
                if not report['cases'][-1]['all_cleanup_proved']:
                    break
            report['source_verification_after'] = verify_sources(provenance)
            UTIL.check(UTIL.sha(BENCH) == provenance['binary']['sha256'], 'Frozen binary changed after cases')
            UTIL.disk(report, 'after_cases')
            report['status'] = 'passed' if len(outcomes) == 2 and all(outcomes) else 'failed'
        except Exception as error:
            report.update(status='failed', error=str(error), traceback=traceback.format_exc())
        finally:
            report['finished_utc'] = UTIL.now()
            save(report, evidence)
            print(json.dumps({'status': report['status'], 'error': report.get('error'), 'report': str(evidence / 'report.json')}), flush=True)
    print('GLOBAL_LOCK_RELEASED', flush=True)
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
